const { __ } = window.wp.i18n;
const { getSetting } = window.wc.wcSettings;
const { decodeEntities } = window.wp.htmlEntities;
const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { createElement, useEffect, useState, useCallback } = window.wp.element;

const config = window.axepta_blocks_params || {};
const settings = getSetting('axepta_blocks_params', {
    title: config.axepta_settings?.axepta_payment_label || __('Paiement avec Axepta BNP Paribas We+', 'axepta-bnp-paribas'),
    supports: ['products'],
});

// Utility functions
const fetchData = async (url, setLoading) => {
    try {
        setLoading(true);
        const response = await fetch(url);
        return await response.json();
    } finally {
        setLoading(false);
    }
};

const filterPaymentMethodsByCountry = (methods, country) => {
    const list = Array.isArray(methods) ? [...methods] : [];
    const hasCardGroup = list.includes('cvm') || list.includes('cb') || list.includes('vim');
    let filtered = list.filter(m => m !== 'cvm' && m !== 'cb' && m !== 'vim');

    if (hasCardGroup) {
        const brands = [];
        if (country === 'FR') {
            brands.push('CB');
        }
        brands.push('VISA', 'MASTERCARD');

        const existingLower = new Set(filtered.map(m => String(m).toLowerCase()));
        const toPrepend = brands.filter(b => !existingLower.has(b.toLowerCase()));

        filtered = [...toPrepend, ...filtered];
    }

    return filtered;
};

// Components
const PaymentMethodLabel = (props) => {
    const { PaymentMethodLabel } = props.components;
    return createElement(PaymentMethodLabel, {
        text: decodeEntities(settings.title),
        onClick: props.onClick,
    });
};

const DemoBanner = ({ message, onDemoClick }) => createElement(
    'div',
    { className: 'axepta-banner-demo' },
    createElement('div', null, message),
    createElement(
        'button',
        { className: 'axepta-demo-button', onClick: (e) => { e.preventDefault(); onDemoClick(); } },
        __('Voir les cartes de test', 'axepta-bnp-paribas')
    )
);

const PaymentDescription = ({ message, imageUrl, imageAlt }) => createElement(
    'div',
    { className: 'axepta-payment-description' },
    createElement('img', {
        src: imageUrl || `${config.site_url}/wp-content/plugins/axepta-bnp-paribas/assets/img/icon-bnp.jpg`,
        alt: imageAlt || `Icon Logo Axepta BNP Paribas`,
    }),
    createElement('p', null, message)
);

const Modal = ({ isOpen, onClose, cards }) => {
    if (!isOpen) return null;
    return createElement(
        'div',
        { className: 'axepta-modal-overlay' },
        createElement(
            'div',
            { className: 'axepta-modal-content' },
            createElement(
                'button',
                { className: 'axepta-modal-close', onClick: onClose },
                '×'
            ),
            createElement(
                'table',
                { className: 'axepta-test-cards-table' },
                createElement(
                    'thead',
                    null,
                    createElement(
                        'tr',
                        null,
                        createElement('th', null, __('Type', 'axepta-bnp-paribas')),
                        createElement('th', null, __('Numéro', 'axepta-bnp-paribas')),
                        createElement('th', null, __('Réponse', 'axepta-bnp-paribas')),
                        createElement('th', null, __('Description', 'axepta-bnp-paribas'))
                    )
                ),
                createElement(
                    'tbody',
                    null,
                    [
                        { type: 'Visa', number: '4111 1111 1111 1111', response: '0000', desc: 'succès' },
                        { type: 'Visa', number: '4012 8888 8888 1881', response: '0100', desc: 'échec' },
                        { type: 'Visa', number: '4200 0000 0000 0000', response: '0305', desc: 'échec' },
                        { type: 'Mastercard', number: '5555 5555 5555 4444', response: '0000', desc: 'succès' },
                        { type: 'Mastercard', number: '5105 1051 0510 5100', response: '0100', desc: 'échec' },
                        { type: 'Mastercard', number: '5200 0000 0000 0007', response: '0305', desc: 'échec' },
                        { type: 'AMEX', number: '3750 0000 0000 007', response: '0000', desc: 'succès' },
                        { type: 'AMEX', number: '3714 4963 5398 431', response: '0100', desc: 'échec' },
                        { type: 'AMEX', number: '3782 8246 6310 005', response: '0305', desc: 'échec' }
                    ].map(card => createElement(
                        'tr',
                        { key: card.number },
                        createElement('td', null, createElement('img', {
                            src: `${config.site_url}/wp-content/plugins/axepta-bnp-paribas/assets/img/${card.type.toUpperCase()}.png`,
                            alt: card.type,
                            className: 'axepta-test-card-logo'
                        })),
                        createElement('td', null, card.number),
                        createElement('td', null, card.response),
                        createElement('td', { style: { color: card.desc === 'succès' ? '#28a745' : '#dc3545' } }, card.desc)
                    ))
                )
            )
        )
    );
};

const SavedCardOption = ({ card, isSelected, onSelect }) => (
    createElement(
        'label',
        { className: `axepta-radio-option${isSelected ? ' active' : ''}` },
        createElement('input', {
            type: 'radio',
            name: 'axepta_saved_payment_method',
            value: card.id,
            onChange: () => onSelect(card.id),
            className: 'axepta-radio-input',
            checked: isSelected,
        }),
        createElement(
            'div',
            { className: 'axepta-saved-card-label-container' },
            createElement(
                'div',
                { className: 'axepta-saved-card-radio-logo-container' },
                createElement('img', {
                    src: `${config.site_url}/wp-content/plugins/axepta-bnp-paribas/assets/img/${card.ccbrand.toUpperCase()}.png`,
                    className: 'axepta-saved-card-radio-logo',
                    alt: `${card.ccbrand} logo`,
                })
            ),
            createElement(
                'div',
                { className: 'axepta-saved-card-radio-label-container' },
                createElement(
                    'div',
                    { className: 'axepta-saved-card-radio-label' },
                    card.ccbrand.charAt(0).toUpperCase() + card.ccbrand.slice(1)
                ),
                createElement(
                    'div',
                    { className: 'axepta-saved-card-radio-last4Digits' },
                    createElement(
                        'span',
                        { className: 'axepta-saved-card-radio-label axepta-method-last4Digits' },
                        card.pcnr
                    )
                )
            )
        )
    )
);

const PaymentOption = ({ method, isSelected, onSelect }) => {
    const methodRaw = String(method || '');
    const methodLower = methodRaw.toLowerCase();
    const isPaypal = methodLower === 'paypal' || methodLower === 'payPal';
    const inputId = `axepta_payment_${methodLower.replace(/[^a-z0-9_-]/g, '_')}`;

    const logoPath = `${config.site_url}/wp-content/plugins/axepta-bnp-paribas/assets/img`;

    const sizeMap = {
        visa: '26px',
        mastercard: '48px',
        amex: '38px',
        default: '38px',
    };

    const logoStyle = { maxHeight: sizeMap[methodLower] || sizeMap.default };

    return createElement(
        'div',
        { className: `axepta-payment-card ${isSelected ? 'selected' : ''} ${isPaypal ? 'axepta-payment-card--paypal' : ''}` },
        createElement(
            'label',
            { htmlFor: inputId, className: `axepta-payment-option` },
            createElement('input', {
                id: inputId,
                type: 'radio',
                name: 'axepta_payment_method',
                value: methodRaw,
                onChange: () => onSelect(methodRaw),
                className: 'axepta-radio-input',
                checked: isSelected,
            }),
            createElement('img', {
                    src: `${logoPath}/${methodRaw.toUpperCase()}.png`,
                    alt: `${methodRaw} logo`,
                    className: 'axepta-method-logo',
                    style: logoStyle,
                })
            )
    );
};

const SaveCardCheckbox = ({ checked, onChange }) => createElement(
    'label',
    { className: 'axepta-save-card-checkbox' },
    createElement('input', {
        type: 'checkbox',
        checked,
        onChange: e => onChange(e.target.checked),
    }),
    __('Enregistrer ma carte pour mes futurs paiements', 'axepta-bnp-paribas')
);

const AxeptaPaymentComponent = ({ eventRegistration, emitResponse }) => {
    const { onPaymentSetup } = eventRegistration;
    const [loading, setLoading] = useState(false);
    const [selectedPaygate, setSelectedPaygate] = useState('');
    const [availablePaymentMethods, setAvailablePaymentMethods] = useState([]);
    const [saveCardChecked, setSaveCardChecked] = useState(false);
    const [savedCards, setSavedCards] = useState([]);
    const [billingCountry, setBillingCountry] = useState('FR');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const fetchPaymentMethods = useCallback(async () => {
        const data = await fetchData(`${config.rest_url}settings`, setLoading);
        const methods = data?.payment_methods ? Object.keys(data.payment_methods) : [];
        setAvailablePaymentMethods(filterPaymentMethodsByCountry(methods, billingCountry));
    }, [billingCountry]);

    const fetchSavedCards = useCallback(async () => {
        if (config.current_user_id > 0) {
            const endpoint = (config.rest_url.includes('?') ? 'saved-cards&user_id=' : 'saved-cards?user_id=');
            const $url = config.rest_url + endpoint + config.current_user_id;
            const data = await fetchData($url, setLoading);
            const cards = data?.cards || [];
            setSavedCards(cards);
            // Select the first saved card by default if available and one-click is enabled
            if (cards.length > 0 && config.axepta_settings?.axepta_oneclick_enabled === '1') {
                setSelectedPaygate(cards[0].id);
            }
        }
    }, []);

    useEffect(() => {
        const unsubscribe = onPaymentSetup(() => ({
            type: emitResponse.responseTypes.SUCCESS,
            meta: {
                paymentMethodData: {
                    axepta_bnpp_selected_gateway: selectedPaygate,
                    is_saved_card: savedCards.some(card => card.id === selectedPaygate),
                    save_card: saveCardChecked ? 'on' : 'off',
                },
            },
        }));
        return () => unsubscribe();
    }, [onPaymentSetup, emitResponse, selectedPaygate, saveCardChecked]);

    useEffect(() => {
        // Only set the first available payment method if no saved cards are selected
        if (availablePaymentMethods.length > 0 && !selectedPaygate && (!savedCards.length || config.axepta_settings?.axepta_oneclick_enabled !== '1')) {
            setSelectedPaygate(availablePaymentMethods[0]);
        }
    }, [availablePaymentMethods, selectedPaygate, savedCards]);

    useEffect(() => {
        const countryElement = document.getElementById('billing-country');
        if (countryElement) {
            setBillingCountry(countryElement.value || 'FR');
            const handleCountryChange = () => setBillingCountry(countryElement.value || 'FR');
            countryElement.addEventListener('change', handleCountryChange);
            return () => countryElement.removeEventListener('change', handleCountryChange);
        }
    }, []);

    useEffect(() => {
        const handleRefresh = () => {
            fetchPaymentMethods();
            fetchSavedCards();
        };
        document.addEventListener('axeptaRefreshPaymentMethods', handleRefresh);
        fetchPaymentMethods();
        fetchSavedCards();
        return () => document.removeEventListener('axeptaRefreshPaymentMethods', handleRefresh);
    }, [fetchPaymentMethods, fetchSavedCards]);

    const renderContent = () => {
        const elements = [];
        const isDemoMode = config.axepta_settings?.axepta_mode === 'demo' || config.axepta_settings?.axepta_mode === 'test';
        const paymentLayout = config.axepta_settings?.axepta_payment_layout || 'hpp';

        if (isDemoMode) {
            elements.push(createElement(DemoBanner, {
                key: 'demo-banner',
                message: config.demo_message || __('Mode démo', 'axepta-bnp-paribas'),
                onDemoClick: () => setIsModalOpen(true)
            }));
        }

        if (loading) {
            elements.push(createElement(
                'div',
                { key: 'loader', className: 'axepta-spinner-container' },
                createElement('div', { className: 'axepta-spinner' })
            ));
        } else {
            const paymentBlock = [];
            if (config.current_user_id > 0 && savedCards.length > 0 && config.axepta_settings?.axepta_oneclick_enabled === '1') {
                paymentBlock.push(
                    createElement(
                        'div',
                        { key: 'saved-cards-title', className: 'axepta-saved-cards-title' },
                        __("Payer avec mes cartes", 'axepta-bnp-paribas') + ` (${savedCards.length})`
                    ),
                    createElement(
                        'div',
                        { key: 'saved-cards-options', className: 'axepta-saved-cards-options' },
                        savedCards.map(card => createElement(SavedCardOption, {
                            key: `radio-${card.id}`,
                            card,
                            isSelected: selectedPaygate === card.id,
                            onSelect: setSelectedPaygate,
                        }))
                    ),
                    createElement(
                        'div',
                        { key: 'other-options-title', className: 'axepta-saved-cards-title' },
                        __("Autres options de paiement", 'axepta-bnp-paribas')
                    )
                );
            }

            if (paymentLayout === 'regroupe' && availablePaymentMethods.length > 0) {
                const normalizedMethods = availablePaymentMethods.map(m => String(m || ''));
                const payPalMethods = normalizedMethods.filter(m => m.toLowerCase() === 'paypal');
                const cardMethods = normalizedMethods.filter(m => m.toLowerCase() !== 'paypal');

                paymentBlock.push(
                    createElement(
                        'div',
                        { key: 'payment-options-container', className: 'axepta-payment-options-container' },
                        createElement(
                            'div',
                            { key: 'card-options-header', className: 'axepta-payment-options-header' },
                            createElement('h3', { className: 'axepta-payment-title' }, __('Payer avec carte', 'axepta-bnp-paribas')),
                            createElement(
                                'div',
                                { key: 'payment-options-cards', className: 'axepta-payment-options' },
                                cardMethods.map((method, idx) => createElement(PaymentOption, {
                                    key: `axepta-method-${String(method).toLowerCase()}-${idx}`,
                                    method,
                                    isSelected: selectedPaygate === method,
                                    onSelect: setSelectedPaygate,
                                }))
                            )
                        ),
                        payPalMethods.length > 0 && createElement(
                            'div',
                            { key: 'paypal-options-header', className: 'axepta-payment-options-header' },
                            createElement('h3', { className: 'axepta-payment-title' }, __('Payer avec PayPal', 'axepta-bnp-paribas')),
                            createElement(
                                'div',
                                { key: 'payment-options-paypal', className: 'axepta-payment-options' },
                                payPalMethods.map((method, idx) => createElement(PaymentOption, {
                                    key: `axepta-method-paypal-${idx}`,
                                    method,
                                    isSelected: selectedPaygate === method,
                                    onSelect: setSelectedPaygate,
                                }))
                            )
                        ),
                        config.current_user_id > 0 && config.axepta_settings?.axepta_oneclick_enabled === '1' && createElement(SaveCardCheckbox, {
                            key: 'save-card',
                            checked: saveCardChecked,
                            onChange: setSaveCardChecked,
                        })
                    )
                );
            } else {
                paymentBlock.push(PaymentDescription({
                    key: 'hpp-description',
                    message: __('Vous serez redirigé vers la page de paiement sécurisée.!!!', 'axepta-bnp-paribas'),
                    imageUrl: `${config.site_url}/wp-content/plugins/axepta-bnp-paribas/assets/img/icon-bnp.jpg`,
                    imageAlt: 'Icon Logo Axepta BNP Paribas'
                }));
            }

            elements.push(createElement(
                'div',
                { key: 'axepta-payment-block', className: 'axepta-payment-block' },
                paymentBlock
            ));
        }

        elements.push(createElement(Modal, {
            key: 'modal',
            isOpen: isModalOpen,
            onClose: () => setIsModalOpen(false),
            cards: []
        }));

        return elements;
    };

    return createElement('div', { className: 'axepta-payment-method' }, renderContent());
};

// Register payment method
registerPaymentMethod({
    name: 'axepta_bnpp_gateway',
    label: createElement(props => createElement(PaymentMethodLabel, {
        ...props,
        onClick: () => document.dispatchEvent(new Event('axeptaRefreshPaymentMethods')),
    })),
    content: createElement(AxeptaPaymentComponent),
    edit: createElement(AxeptaPaymentComponent),
    canMakePayment: () => true,
    ariaLabel: decodeEntities(settings.title),
    supports: { features: settings.supports },
});
