jQuery(document).ready(function($) {
    const { __ } = window.wp.i18n;
    const accountSettings = window.axeptaAccount;
    const axeptaPaymentLabel = accountSettings.axepta_payment_label ?? __('Paiement par carte bancaire', 'axepta-bnp-paribas');
    const axeptaPaymentMethods = accountSettings.axepta_payment_methods ?? [];
    const $firstHeader = $('.axepta-accordion-header').first();
    const $firstTarget = $($firstHeader.data('target'));
    const $firstIcon = $firstHeader.find('.toggle-icon');
    const $configBtn = $('#open-config-modal');

    function updateConfigBtnVisibility() {
        if ($firstTarget.is(':visible')) {
            $configBtn.hide();
        } else {
            $configBtn.show();
        }
    }

    $firstTarget.show();
    $firstIcon.removeClass('dashicons-arrow-right-alt2').addClass('dashicons-arrow-down-alt2');
    // updateConfigBtnVisibility();

    $('.axepta-accordion-header').on('click', function() {
        var target = $($(this).data('target'));
        var icon = $(this).find('.toggle-icon');

        // close all other accordion if one activated
        $('.axepta-accordion-content').not(target).slideUp();
        $('.axepta-accordion-header .toggle-icon').removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-right-alt2');

        var isOpen = target.is(':visible');
        target.slideToggle(200, function () {
            // Toggle icon
            if (isOpen) {
                icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-right-alt2');
            } else {
                icon.removeClass('dashicons-arrow-right-alt2').addClass('dashicons-arrow-down-alt2');
            }
            // updateConfigBtnVisibility();
        });
    });

    // Generic modal handler
    function setupModal(openSelector, modalSelector, closeSelector) {
        $(openSelector).on('click', function(e) {
            e.preventDefault();
            $(modalSelector).show();
            
            if (openSelector === '#open-support-form') {
                handleSupportFormValidation();
            }
            if(openSelector === "#open-config-modal") {
                verifyMerchantSetup();
            }
        });
        $(closeSelector).on('click', function() {
            $(modalSelector).hide();
        });
        $(window).on('click', function(e) {
            if ($(e.target).is(modalSelector)) {
                $(modalSelector).hide();
            }
        });
    }
    
    function handleSupportFormValidation() {
        const supportForm = $('#axeptaSupportForm');
        const responseDiv = $('#axepta-support-response');
        const submitBtn = supportForm.find('button[type="submit"]');

        const spinnerIcon = $('#submitBtn .spinner-icon');
        const spinnerLabel = $('#submitBtn .spinner-label');

        submitBtn.off('click').on('click', function (e) {
            e.preventDefault();
            submitBtn.prop('disabled', true);
            spinnerLabel.text(__('Envoi en cours...', 'axepta-bnp-paribas'));
            spinnerIcon.show();

            const formData = new FormData();
            let isValid = true;

            const allowedFileTypes = [
                'image/png', 
                'image/jpeg', 
                'application/pdf', 
                'application/msword', 
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel', 
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            ];

            supportForm.find('[name]').each(function () {
                const $field = $(this);
                const fieldType = $field.attr('type');
                const isRequired = $field.is('[data-required]');
                $field.removeClass('error');
                $field.next('.field-error-message').remove();

                if (fieldType === 'file') {
                    const file = $field[0].files[0];
                    if (file) {
                        if (!allowedFileTypes.includes(file.type)) {
                            $field.addClass('error');
                            isValid = false;
                            $('<div class="field-error-message"><span class="dashicons dashicons-info-outline"></span>' + __('Type de fichier non autorisé', 'axepta-bnp-paribas') + '</div>').insertAfter($field);
                        } else {
                            formData.append($field.attr('name'), file);
                        }
                    } else if (isRequired) {
                        $field.addClass('error');
                        isValid = false;
                        $('<div class="field-error-message"><span class="dashicons dashicons-info-outline"></span>' + __('Veuillez choisir un fichier', 'axepta-bnp-paribas') + '</div>').insertAfter($field);
                    }
                } else {
                    const value = $.trim($field.val());
                    if (isRequired && value === '') {
                        $field.addClass('error');
                        isValid = false;
                        $('<div class="field-error-message"><span class="dashicons dashicons-info-outline"></span>' + __('Ce champ est requis', 'axepta-bnp-paribas') + '</div>').insertAfter($field);
                    } else if (fieldType === 'email') {
                        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                        if (!emailPattern.test(value)) {
                            $field.addClass('error');
                            isValid = false;
                            $('<div class="field-error-message"><span class="dashicons dashicons-info-outline"></span>' + __('Adresse e-mail invalide', 'axepta-bnp-paribas') + '</div>').insertAfter($field);
                        } else {
                            formData.append($field.attr('name'), value);
                        }
                    } else {
                        formData.append($field.attr('name'), value);
                    }
                }
            });

            if (!isValid) {
                submitBtn.prop('disabled', false);
                spinnerLabel.text(__('Envoyer', 'axepta-bnp-paribas'));
                spinnerIcon.hide();
                return;
            } else {
                $(window).off('beforeunload');
                window.onbeforeunload = null;
                $('form.woocommerce').trigger('reset');
            }

            formData.append('action', 'axepta_send_support_form');
            formData.append('enctype', 'multipart/form-data');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    submitBtn.prop('disabled', false);
                    spinnerLabel.text(__('Envoyer', 'axepta-bnp-paribas'));
                    spinnerIcon.hide();
                    if (response.success) {
                        responseDiv.fadeOut(200, function () {
                            $(this).html('<div class="notice notice-success is-dismissible"><p style="font-size: 14px; color: green; font-family: inter; font-weight: 500;">' + __('Votre message a été envoyé avec succès.', 'axepta-bnp-paribas') + '</p></div>').fadeIn(300);
                        });
                        supportForm.find('[name]').val('');
                    } else {
                        responseDiv.fadeOut(200, function () {
                            $(this).html('<div class="notice notice-error is-dismissible"><p style="font-size: 14px; color: red; font-family: inter; font-weight: 500;">' + __('Erreur : ', 'axepta-bnp-paribas') + (response.data || __('erreur inconnue.', 'axepta-bnp-paribas')) + '</p></div>').fadeIn(300);
                        });
                    }
                },
                error: function () {
                    submitBtn.prop('disabled', false);
                    spinnerLabel.text(__('Envoyer', 'axepta-bnp-paribas'));
                    spinnerIcon.hide();
                    responseDiv.fadeOut(200, function () {
                        $(this).html('<div class="notice notice-error is-dismissible"><p style="font-size: 14px; color: red; font-family: inter; font-weight: 500;">' + __('Erreur technique. Veuillez réessayer plus tard.', 'axepta-bnp-paribas') + '</p></div>').fadeIn(300);
                    });
                }
            });
            formData: null;
        });
    }

    function verifyMerchantSetup() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'axepta_verify_merchant_setup',
            },
            success: function(response) {
                $('#axepta-valid-api-keys').html( response.success ? '<span class="dashicons dashicons-saved" style="color: green;"></span>' : '<span class="dashicons dashicons-no" style="color: #d93025;"></span>');
            },
            error: function(response) {
                $('#axepta-valid-api-keys').html('<span class="dashicons dashicons-no" style="color: #d93025;"></span>');
            }
        });
    }

    setupModal('#open-support-form', '#axepta-contact-form', '.axepta-close');
    setupModal('#open-versionning-modal', '#axepta-versionning-modal', '.axepta-close');
    setupModal('#open-config-modal', '#axepta-config-modal', '.axepta-close');

    // Account config (Mode => demo, test, production)
    var $select = $('#axepta_mode');
    var $container = $('#axepta-mode-fields');
    var $configId = $('#axepta-account-configId');
    var $testModeContainer = $('#axepta-mode-test-field');
    var $bannerDemo = $('#axepta-banner-demo');

    if ($configId.length) {
        $configId.on('click', function () {
            $('#configBtn').hide();
        });
    }

    function renderFields() {
        var mode = $select.val();
        $container.empty();

        var axepta_test_key = $('#axepta_test_key').val() || (accountSettings && accountSettings.axepta_test_key ? accountSettings.axepta_test_key : '');
        var axepta_private_key = $('#axepta_private_key').val() || (accountSettings && accountSettings.axepta_private_key ? accountSettings.axepta_private_key : '');
        var axepta_merchant_id = $('#axepta_merchant_id').val() || (accountSettings && accountSettings.axepta_merchant_id ? accountSettings.axepta_merchant_id : '');
        var axepta_test_merchant_id = $('#axepta_test_merchant_id').val() || (accountSettings && accountSettings.axepta_test_merchant_id ? accountSettings.axepta_test_merchant_id : '');

        if (mode === 'demo') {
            $testModeContainer.show();
            $bannerDemo.html(__("VOUS ÊTES EN MODE DÉMO", 'axepta-bnp-paribas')).show();
        } else if (mode === 'test') {
            $container.html(`
                <div class="axepta-form-group">
                    <label for="axepta_test_key" class="axepta_label">${__('Clé de test', 'axepta-bnp-paribas')} <span class="dashicons dashicons-info-outline" title="${__('Insérer la clé de test fournie par Axepta BNP Paribas', 'axepta-bnp-paribas')}"></span></label>
                    <input type="password" name="axepta_test_key" id="axepta_test_key" value="${axepta_test_key}" placeholder="${__('Votre clé de test', 'axepta-bnp-paribas')}" />
                    <span class="axepta-help">${__('Caractères alphanumériques sans espace', 'axepta-bnp-paribas')}</span>
                </div>
                <div class="axepta-form-group">
                    <label for="axepta_test_merchant_id" class="axepta_label">${__('ID du marchand', 'axepta-bnp-paribas')} <span class="dashicons dashicons-info-outline" title="${__('Insérer votre ID fournie par Axepta BNP Paribas', 'axepta-bnp-paribas')}"></span></label>
                    <input type="text" name="axepta_test_merchant_id" id="axepta_test_merchant_id" value="${axepta_test_merchant_id}" placeholder="${__('ID du marchand', 'axepta-bnp-paribas')}" />
                    <span class="axepta-help">${__('Reçue lors de votre inscription', 'axepta-bnp-paribas')}</span>
                </div>
            `);
            $testModeContainer.hide();
            $bannerDemo.html(__("VOUS ÊTES EN MODE TEST", 'axepta-bnp-paribas')).show();
        } else if (mode === 'production') {
            $container.html(`
                <div class="axepta-form-group">
                    <label for="axepta_private_key" class="axepta_label">${__('Clé API', 'axepta-bnp-paribas')} <span class="dashicons dashicons-info-outline" title="${__('Insérer la clé privée fournie par Axepta BNP Paribas', 'axepta-bnp-paribas')}"></span></label>
                    <input type="password" name="axepta_private_key" id="axepta_private_key" value="${axepta_private_key}" placeholder="${__('Votre clé privée', 'axepta-bnp-paribas')}" />
                    <span class="axepta-help">${__('Reçue lors de votre inscription', 'axepta-bnp-paribas')}</span>
                </div>
                <div class="axepta-form-group">
                    <label for="axepta_merchant_id" class="axepta_label">${__('ID du marchand', 'axepta-bnp-paribas')} <span class="dashicons dashicons-info-outline" title="${__('Insérer votre ID fournie par Axepta BNP Paribas', 'axepta-bnp-paribas')}"></span></label>
                    <input type="text" name="axepta_merchant_id" id="axepta_merchant_id" value="${axepta_merchant_id}" placeholder="${__('ID du marchand', 'axepta-bnp-paribas')}" />
                    <span class="axepta-help">${__('Reçue lors de votre inscription', 'axepta-bnp-paribas')}</span>
                </div>
            `);
            $testModeContainer.hide();
            $bannerDemo.hide();
        }
    }
    $select.on('change', renderFields);
    renderFields();

    // Custom title and text
    window.axeptaToggleSwitch = function(checkbox, key) {
        var $customTitle = $('#custom_title');
        var $customText = $('#custom_text');
        var $logoUrl = $('#logo_url');

        if (key === 'logo' && $logoUrl.length) {
            if (checkbox.checked) {
                // Retrieve value from existing input or set to empty string
                var currentLogo = $('#axepta_custom_logo_url').val() || (accountSettings && accountSettings.axepta_custom_logo_url ? accountSettings.axepta_custom_logo_url : window.siteLogo);
                $logoUrl.html(`
                    <input type="text" name="axepta_custom_logo_url" id="axepta_custom_logo_url" value="${currentLogo}" placeholder="${__('URL du logo', 'axepta-bnp-paribas')}">
                `);
            } else {
                $logoUrl.empty();
            }
        } else if (key === 'title' && $customTitle.length) {
            if (checkbox.checked) {
                // Retrieve value from existing input or set to empty string
                var currentTitle = $('#axepta_custom_title').val() || (accountSettings && accountSettings.axepta_custom_title ? accountSettings.axepta_custom_title : '');
                $customTitle.html(`
                    <input type="text" name="axepta_custom_title" id="axepta_custom_title" value="${currentTitle}" placeholder="${__('Titre à afficher', 'axepta-bnp-paribas')}">
                `);
            } else {
                $customTitle.empty();
            }
        } else if (key === 'text' && $customText.length) {
            if (checkbox.checked) {
                // Retrieve value from existing input or set to empty string
                var currentText = $('#axepta_custom_text').val() || (accountSettings && accountSettings.axepta_custom_text ? accountSettings.axepta_custom_text : '');
                $customText.html(`
                    <input type="text" name="axepta_custom_text" id="axepta_custom_text" value="${currentText}" placeholder="${__('Texte personnalisé', 'axepta-bnp-paribas')}">
                `);
            } else {
                $customText.empty();
            }
        }
    };

    $('#download-logs').on('click', function(e) {
        e.preventDefault();

        const button = $(this);
        const originalText = button.text();

        button.prop('disabled', true);
        button.html('<span class="dashicons dashicons-update spin-loader"></span> ' + originalText);

        $.post(ajaxurl, {
            action: 'axepta_download_logs',
            nonce: axeptaConfig.downloadLogsNonce
        })
        .done(function(response) {
            if (response.success) {
                const data = response.data;

                const byteCharacters = atob(data.content);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: 'text/plain' });

                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = data.filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);

                $('#axepta-landing-page').prepend(response.data.notice || '<div class="notice notice-success is-dismissible"><p>Les journaux ont été téléchargés avec succès.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignorer cette notice.</span></button></div>');
            } else {
                $('#axepta-landing-page').prepend(response.data.notice || '<div class="notice notice-warning is-dismissible"><p> Une erreur est survenue lors du téléchargement.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignorer cette notice.</span></button></div>');
            }
        })
        .fail(function() {
            $('#axepta-landing-page').prepend('<div class="notice notice-error is-dismissible"><p>Erreur de communication avec le serveur.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignorer cette notice.</span></button></div>');
        })
        .always(function() {
            setTimeout(() => {
                button.prop('disabled', false);
                button.html(originalText);
            }, 500);

            setTimeout(function() {
                $('#axepta-landing-page').find('.notice.is-dismissible .notice-dismiss').off('click').on('click', function() {
                    $(this).closest('.notice').fadeOut(300, function() { $(this).remove(); });
                });

                $(document).trigger('wp-updates-notice-added');
            }, 50);
        });
    });

    if(accountSettings && accountSettings.axepta_oneclick_enabled && accountSettings.axepta_oneclick_enabled === "1") {
        window.axeptaOneClickDeleteTokens = function() {
            if (confirm(__('Êtes-vous sûr de vouloir supprimer tous les tokens ?', 'axepta-bnp-paribas'))) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'axepta_delete_tokens',
                    },
                    beforeSend: function() {
                        $('#axeptaOneClickDeleteToken').prop('disabled', true);
                        $('#axeptaOneClickDeleteToken').addClass('is-loading');
                    },
                    complete: function() {
                        $('#axeptaOneClickDeleteToken').prop('disabled', false);
                        $('#axeptaOneClickDeleteToken').removeClass('is-loading');
                    },
                    success: function(response) {
                        $('#axeptaOneClickDeleteToken').siblings('.notice').remove();
                        var responseDiv = $('<div/>', {
                            class: 'notice notice-success is-dismissible',
                            style: 'margin-top: 10px;',
                            text: response.data
                        }).insertAfter('#axeptaOneClickDeleteToken');
                        setTimeout(function() {
                            responseDiv.fadeOut(200, function() {
                                $(this).remove();
                            });
                        }, 5000);
                    },
                    error: function(response) {
                        var responseDiv = $('<div/>', {
                            class: 'notice notice-error is-dismissible',
                            style: 'margin-top: 10px;',
                            text: __("Erreur lors de la suppression des tokens", 'axepta-bnp-paribas')
                        }).insertAfter('#axeptaOneClickDeleteToken');
                        setTimeout(function() {
                            responseDiv.fadeOut(200, function() {
                                $(this).remove();
                            });
                        }, 5000);
                    }
                });
            }
        };
    }

    if(accountSettings && accountSettings.axepta_subscription_enabled && accountSettings.axepta_subscription_enabled === "1") {
        window.axeptaToggleSubscriptionFields = function(isChecked) {
            document.getElementById('subscriptionFields').style.display = isChecked ? 'block' : 'none';
        };
    }

    // Payment Config
    var $layoutSelect = $('#axepta_payment_layout');
    var $layoutFieldsContainer = $('#axepta-payment-front-label');
    var $axeptaPaymentGroupFields = $('#axepta-payment-group-fields');

    function renderLayoutFields() {
        var layout = $layoutSelect.val();
        var payment_methods = window.payment_methods || ['vim', 'amex', 'payPal', 'applePay', 'gpay'];
        
        $layoutFieldsContainer.empty();
        $axeptaPaymentGroupFields.empty();

        if (layout === 'hpp') {
            $layoutFieldsContainer.html(`
                <label for="axepta_libelle_hpp" class="axepta-label">${__('Libellé de paiement', 'axepta-bnp-paribas')}</label>
                <input type="text" name="axepta_payment_label" id="axepta_libelle_hpp"
                    value="${axeptaPaymentLabel}"
                    placeholder="${__('Paiement par carte bancaire', 'axepta-bnp-paribas')}">
                <p class="axepta-help">${__('Redirection vers BNPP avec choix des cartes suivant le panier et contrat du marchand.', 'axepta-bnp-paribas')}</p>
            `);
        } else if (layout === 'regroupe') {
            var axepta_display_mode = accountSettings.axepta_display_mode;
            $layoutFieldsContainer.html(`
                <label for="axepta_libelle_regroupe" class="axepta-label">${__('Libellé de paiement', 'axepta-bnp-paribas')}</label>
                <input type="text" name="axepta_payment_label" id="axepta_libelle_regroupe"
                    value="${axeptaPaymentLabel}"
                    placeholder="${__('Paiement par carte bancaire', 'axepta-bnp-paribas')}"><br><br>
            `);

            $axeptaPaymentGroupFields.html(`
                <div>
                    <label for="axepta_display_mode">${__("Choisir le mode d'affichage", 'axepta-bnp-paribas')}</label>
                    <select name="axepta_display_mode" id="axepta_display_mode">
                        <option value="redirect" ${axepta_display_mode === 'redirect' ? 'selected' : ''}>${__('Redirection', 'axepta-bnp-paribas')}</option>
                    </select><br><br>
                </div>
                <div class="axepta-subtitle">${__('Liste des moyens de paiement', 'axepta-bnp-paribas')}</div>
                <div class="payment-method-list">
                    ${payment_methods.map(function(method) {
                        var id = "axepta_payment_" + method;
                        var checked = axeptaPaymentMethods && axeptaPaymentMethods[method] === '1' ? 'checked' : '';
                        pluginImgPath = window.pluginPath + "assets/img/";

                        var labelText = method.charAt(0).toUpperCase() + method.slice(1);
                        var cbImg = `<div><img src="${pluginImgPath + method.toUpperCase()}.png" alt="Logo ${method}"></div>`;
                        
                        if(method === 'cb' || method === 'vim') {
                            labelText = 'CB/Visa/Mastercard';
                            cbImg = `<div style="display: flex; gap: 4px; align-items: center;">
                                <img src="${pluginImgPath}CB.png" alt="Logo CB">
                                <img src="${pluginImgPath}VISA.png" alt="Logo VISA">
                                <img src="${pluginImgPath}MASTERCARD.png" alt="Logo MASTERCARD" style="height: 54px">
                            </div>`;
                        }

                        return `
                            <label for="${id}" class="switch payment-method-switch">
                                <span class="switch-label">
                                    ${cbImg}
                                    <span class="switch-text" style="display: none;"> ${labelText} </span>
                                </span>
                                <input type="checkbox" name="${id}" id="${id}" value="1" ${checked}>
                                <span class="slider"></span>
                            </label>
                        `;
                    }).join('')}
                </div>
            `);
        }
    }

    $layoutSelect.on('change', renderLayoutFields);
    renderLayoutFields();

    // Capture mode
    window.axeptaCaptureModeChanged = function(val) {
        var $notice = $('#axepta_manual_capture_notice');
        var $hours = $('#axepta_capture_hours');
        $notice.toggle(val === 'manuel');
        if ($hours.length) {
            $hours.toggle(val === 'deferred');
        }
    };

    window.axeptaToggleManualCaptureEmail = function(checked) {
        var $wrap = $('#axepta_manual_capture_email_wrap');
        if ($wrap.length) {
            $wrap.toggle(!!checked);
        }
    };

    // Capture mode/email display initialization
    axeptaCaptureModeChanged($('#axepta_capture_mode').val());
    axeptaToggleManualCaptureEmail($('#axepta_manual_capture_notify').is(':checked'));

    // Email validation
    var $emailInput = $('#axepta_manual_capture_email');
    if ($emailInput.length) {
        $emailInput.on('input', function() {
            var value = $emailInput.val();
            var regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (value && !regex.test(value)) {
                $emailInput[0].setCustomValidity(__("Veuillez saisir une adresse e-mail valide (exemple@domaine.com, sans caractères spéciaux).", 'axepta-bnp-paribas'));
            } else {
                $emailInput[0].setCustomValidity("");
            }
        });
    }

    // More/Less Releases
    const $toggleBtn = $('#axepta-toggle-releases');
    const $hiddenReleases = $('.hidden-release');
    $toggleBtn.on('click', function(e) {
        e.preventDefault();

        if ($hiddenReleases.is(':visible')) {
            $hiddenReleases.slideUp(300);
            $toggleBtn.text(__('Voir plus', 'axepta-bnp-paribas'));
        } else {
            $hiddenReleases.slideDown(300);
            $toggleBtn.text(__('Voir moins', 'axepta-bnp-paribas'));
        }
    });

    // Download CHANGELOG.md
    $('#axepta-download-all-releases').on('click', function(e) {
        e.preventDefault();
        const changelogUrl = window.pluginPath + 'CHANGELOG.md';
        const $btn = $(this);
        let message = '';

        $btn.prop('disabled', true).addClass('is-loading');

        fetch(changelogUrl)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob();
            })
            .then(function(blob) {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = 'CHANGELOG.md';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);

                message = '<div class="notice notice-success is-dismissible"><p style="font-size:14px;color:green;font-family:inter;font-weight:500;">' + __('Le CHANGELOG a été téléchargé avec succès.', 'axepta-bnp-paribas') + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignorer cette notice.</span></button></div>';
            })
            .catch(function() {
                message = '<div class="notice notice-error is-dismissible"><p style="font-size:14px;color:red;font-family:inter;font-weight:500;">' + __('Impossible de télécharger le CHANGELOG.', 'axepta-bnp-paribas') + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Ignorer cette notice.</span></button></div>';
            })
            .finally(function() {
                setTimeout(function() {
                    $('.axepta-close').click();
                    if (message) {
                        $('#axepta-landing-page').prepend(message);
                    }
                }, 500);
            });
    });

    // Display custom title and text on load if option checked
    ['logo', 'title', 'text'].forEach(function (key) {
        const checkbox = document.getElementById('axepta_display_' + key);
        if (checkbox && checkbox.checked) {
            window.axeptaToggleSwitch(checkbox, key);
        }
    });
});
