document.addEventListener('DOMContentLoaded', () => {
    const { __ } = window.wp.i18n;
    document.querySelectorAll('.axepta-subscription-action').forEach(select => {
        select.addEventListener('change', e => {
            const el = e.target;
            const id = el.dataset.id;
            const action = el.value;

            if (!id || !action) return;

            fetch(axeptaAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'axepta_subscription_action',
                    subscription_id: id,
                    subscription_action: action,
                    nonce: axeptaAjax.nonce
                })
            })
            .then(r => r.json())
            .then(res => {
                alert(res.message || __('Mise à jour effectuée', 'axepta-bnp-paribas'));
                if (res.success) location.reload();
            });
        });
    });
});
