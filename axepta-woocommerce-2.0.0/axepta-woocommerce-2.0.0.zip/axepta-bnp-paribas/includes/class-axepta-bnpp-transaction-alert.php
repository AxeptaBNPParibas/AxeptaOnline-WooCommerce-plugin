<?php
if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Transaction_Alert {
    
    # Custom hook name
    const CRON_HOOK = 'axepta_bnpp_check_missing_transactions';
    
    # Minimum delay after the order to trigger the alert (in hours)
    const ALERT_THRESHOLD_HOURS = 2;
    
    # Initialize the alert system
    public function __construct() {
        add_action('init', [$this, 'schedule_cron']);
        add_action(self::CRON_HOOK, [$this, 'check_missing_transactions']);

        add_action('admin_notices', [$this, 'display_admin_notices']);
        register_deactivation_hook(plugin_basename(dirname(__DIR__) . '/axepta-bnp-paribas.php'), [$this, 'clear_schedule']);
    }
    
    # Schedule cron execution
    public static function schedule_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
            Axepta_Bnpp_Log::info('Cron planifié pour la vérification des transactions manquantes');
        }
    }
    
    # Clear cron schedule on plugin deactivation
    public static function clear_schedule() {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }
    
    # Check for orders without associated transaction
    public static function check_missing_transactions() {
        global $wpdb;
        
        $threshold_date = date('Y-m-d H:i:s', strtotime('-' . self::ALERT_THRESHOLD_HOURS . ' hours'));
        $orders = wc_get_orders([
            'status'        => ['wc-processing', 'wc-completed'],
            'payment_method' => 'axepta_bnpp_gateway',
            'date_created'  => '<' . $threshold_date,
            'limit'         => 50,
            'return'        => 'ids',
        ]);
        
        if (empty($orders)) {
            Axepta_Bnpp_Log::info('Aucune commande à vérifier pour les transactions manquantes');
            return;
        }
        
        $alerts = [];
        
        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            
            if (!$order) {
                continue;
            }
            
            $transaction = Axepta_BNPP_Transaction::get_order_transaction($order_id);
            if (empty($transaction)) {
                $alerts[] = [
                    'order_id' => $order_id,
                    'order_date' => $order->get_date_created()->date('Y-m-d H:i:s'),
                    'order_status' => $order->get_status(),
                    'amount' => $order->get_total(),
                    'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'email' => $order->get_billing_email()
                ];
                
                $order->add_order_note(
                    __('Alerte : Aucune transaction trouvée pour cette commande payée via Axepta.', 'axepta-bnp-paribas')
                );
            }
        }
        
        # Save alerts in an option for display in the admin
        if (!empty($alerts)) {
            update_option('axepta_bnpp_missing_transactions_alerts', $alerts, false);
            
            # Send an email notification to the administrator
            self::send_admin_alert_email($alerts);
            
            Axepta_Bnpp_Log::warning(
                sprintf(
                    '%d commande(s) sans transaction trouvée(s)', 
                    count($alerts)
                ),
                ['alerts' => $alerts]
            );
        }
    }
    
    # Display alert notifications in the admin
    public static function display_admin_notices() {
        $alerts = get_option('axepta_bnpp_missing_transactions_alerts', []);
        
        if (empty($alerts) || !current_user_can('manage_woocommerce')) {
            return;
        }
        
        $alert_count = count($alerts);
        $alert_text = sprintf(
            _n(
                'Il y a %d commande sans transaction associée.', 
                'Il y a %d commandes sans transaction associée.', 
                $alert_count
            ),
            $alert_count
        );
        
        echo '<div class="notice notice-error">';
        echo '<p><strong>Axepta BNP Paribas - Transactions manquantes</strong></p>';
        echo '<p>' . esc_html($alert_text) . '</p>';
        
        # Display an overview of the orders concerned
        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
        $displayed = 0;
        foreach ($alerts as $alert) {
            if ($displayed >= 5) {
                echo '<li>... et ' . ($alert_count - 5) . ' autres commandes</li>';
                break;
            }
            
            $order_edit_url = admin_url('post.php?post=' . $alert['order_id'] . '&action=edit');
            echo sprintf(
                '<li><a href="%s" target="_blank">Commande #%s</a> - %s - %s %s</li>',
                esc_url($order_edit_url),
                esc_html($alert['order_id']),
                esc_html($alert['customer']),
                wc_price($alert['amount']),
                esc_html($alert['order_status'])
            );
            
            $displayed++;
        }
        echo '</ul>';
        
        # Link to dismiss alerts
        $dismiss_url = wp_nonce_url(add_query_arg('axepta_dismiss_alerts', '1'), 'axepta_dismiss_alerts_nonce');
        echo '<p><a href="' . esc_url($dismiss_url) . '">' . __('Masquer ces alertes', 'axepta-bnp-paribas') . '</a></p>';
        
        echo '</div>';
    }
    
    # Send an alert email to the administrator
    protected static function send_admin_alert_email($alerts) {
        $to = get_option('admin_email');
        $subject = sprintf(
            __('[%s] %d commande(s) sans transaction Axepta', 'axepta-bnp-paribas'),
            get_bloginfo('name'),
            count($alerts)
        );
        
        $message = 'Bonjour,\n\n';
        $message .= sprintf(
            _n(
                '%d commande payée via Axepta n\'a pas de transaction associée dans le système.\n\n',
                '%d commandes payées via Axepta n\'ont pas de transaction associée dans le système.\n\n',
                count($alerts),
                'axepta-bnp-paribas'
            ),
            count($alerts)
        );
        
        $message .= __('Détails des commandes concernées :', 'axepta-bnp-paribas') . "\n\n";
        
        foreach ($alerts as $alert) {
            $order_edit_url = admin_url('post.php?post=' . $alert['order_id'] . '&action=edit');
            $message .= sprintf(
                "- Commande #%s - %s - %s - %s %s\n   %s\n\n",
                $alert['order_id'],
                $alert['customer'],
                wc_price($alert['amount']),
                $alert['order_status'],
                $alert['order_date'],
                $order_edit_url
            );
        }
        
        $message .= __('Cordialement,\n' . get_bloginfo('name'), 'axepta-bnp-paribas');
        
        # Email headers
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        
        # Send the email
        wp_mail($to, $subject, $message, $headers);
    }
}

# Handle alert dismissal
add_action('admin_init', function() {
    if (isset($_GET['axepta_dismiss_alerts']) && 
        isset($_GET['_wpnonce']) && 
        wp_verify_nonce($_GET['_wpnonce'], 'axepta_dismiss_alerts_nonce')) {
        
        delete_option('axepta_bnpp_missing_transactions_alerts');
        
        # Redirect to avoid page reload
        wp_redirect(remove_query_arg(['axepta_dismiss_alerts', '_wpnonce']));
        exit;
    }
});

# Initialize the alert system
new Axepta_BNPP_Transaction_Alert();