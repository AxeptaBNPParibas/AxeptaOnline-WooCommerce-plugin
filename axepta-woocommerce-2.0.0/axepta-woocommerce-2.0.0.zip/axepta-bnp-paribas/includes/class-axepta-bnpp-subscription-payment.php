<?php

if(!defined('ABSPATH')) {
    exit;
}

class Axepta_Bnpp_Subscription_Payment
{
    private $abo_enabled = false;

    const ID_STATUS_ACTIVE = 1;
    const ID_STATUS_PAUSE = 2;
    const ID_STATUS_EXPIRED = 3;

    # Checks if subscriptions are allowed.
    public function __construct() {
        if ($this->is_allowed_abo()) {
            $this->abo_enabled = true;
        }

        add_action('woocommerce_after_register_post_type', [$this, 'action_woocommerce_after_register_post_type'], 10, 1);
        add_action('axepta_bnpp_recurring_cronjob', [$this, 'send_recurring_schedule']);
    }

    # Checks if subscription is allowed.
    private function is_allowed_abo() {
        return true;
    }

    # Get recurring payment list for a user.
    public static function get_recurring_payment_list($user_id)
    {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_subscription_payment WHERE `id_customer` = %d ORDER BY date_add DESC",
                $user_id
            )
        );
    }

    # Get all subscription products.
    public static function get_recurring_products()
    {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}axepta_bnpp_subscription_product ORDER BY id_axepta_bnpp_subscription_product DESC"
        );
    }

    # Get schedules to capture based on dates and occurrences.
    public static function get_schedules_to_capture()
    {
        global $wpdb;
        $sql = "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_subscription_payment 
                WHERE `status` = '1' 
                AND DATEDIFF(NOW(), `next_schedule`) >= 0 
                AND (number_occurences > current_occurence OR number_occurences = 0)
                ORDER BY date_add DESC";
        return $wpdb->get_results($sql);
    }

    # Get schedules to stop when occurrences are finished.
    public static function get_schedules_to_stop()
    {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_subscription_payment 
            WHERE `status` = '1' 
            AND number_occurences <= current_occurence 
            AND number_occurences > 0 
            ORDER BY date_add DESC"
        );
    }

    # Remove a recurring payment by its ID.
    public static function remove_axepta_bnpp_customer_subscription_payment_by_id($id)
    {
        global $wpdb;
        $wpdb->delete(
            $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment',
            ['id_axepta_bnpp_customer_subscription_payment' => $id]
        );
        return empty($wpdb->last_error);
    }

    # Cancel a recurring payment by marking it as expired.
    public static function cancel_axepta_bnpp_customer_subscription_payment_by_id($id)
    {
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment',
            ['status' => self::ID_STATUS_EXPIRED],
            ['id_axepta_bnpp_customer_subscription_payment' => $id],
            ['%d'],
            ['%d']
        );
    }

    # Get subscription information for a product.
    public static function get_subscription_infos($product_id)
    {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_subscription_product WHERE id_product = %d",
                $product_id
            )
        );
    }

    # Action after registering the product type in WooCommerce.
    public function action_woocommerce_after_register_post_type()
    {
        if ($this->abo_enabled) {
            if (!wp_next_scheduled('axepta_bnpp_recurring_cronjob')) {
                wp_schedule_event(time() + 10, "hourly", "axepta_bnpp_recurring_cronjob");
            }
        }
    }

    # Send recurring payments schedules to the API.
    public function send_recurring_schedule()
    {}
}
