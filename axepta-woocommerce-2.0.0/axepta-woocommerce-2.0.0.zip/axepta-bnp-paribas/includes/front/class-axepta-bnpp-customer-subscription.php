<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Axepta_BNPP_Customer_Subscription
 */
class Axepta_BNPP_Customer_Subscription 
{
    public static $endpoint = 'mes-abonnements';

    # Initialize the class
    public function __construct() {
        add_action('init', [$this, 'add_endpoint']);
        add_filter('query_vars', [$this, 'add_query_vars'], 0);
        add_filter('woocommerce_account_menu_items', [$this, 'add_menu_item']);
        add_action('woocommerce_account_' . self::$endpoint . '_endpoint', [$this, 'endpoint_content']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
        add_action('template_redirect', [$this, 'handle_subscription_actions']);
    }
    
    # Handle subscription actions (pause, resume, cancel)
    public function handle_subscription_actions() {
        if (!is_account_page() || !isset($_POST['action']) || !isset($_POST['subscription_id']) || !isset($_POST['subscription_nonce'])) {
            return;
        }
        
        # Verify nonce
        if (!wp_verify_nonce($_POST['subscription_nonce'], 'subscription_actions_nonce')) {
            wc_add_notice(__('Action non autorisée.', 'axepta-bnp-paribas'), 'error');
            return;
        }
        
        $subscription_id = absint($_POST['subscription_id']);
        $action = sanitize_text_field($_POST['action']);
        $user_id = get_current_user_id();
        
        # Check that the subscription belongs to the current user
        $subscription = $this->get_user_subscription($user_id, $subscription_id);
        
        if (!$subscription) {
            wc_add_notice(__('Abonnement introuvable ou accès non autorisé.', 'axepta-bnp-paribas'), 'error');
            return;
        }
        
        # Handle action
        switch ($action) {
            case 'pause_subscription':
                $this->pause_subscription($subscription_id);
                break;
                
            case 'resume_subscription':
                $this->resume_subscription($subscription_id);
                break;
                
            case 'cancel_subscription':
                $this->cancel_subscription($subscription_id);
                break;
            default:
                wc_add_notice(__('Action inconnue.', 'axepta-bnp-paribas'), 'error');
                return;
        }
        
        # Redirect to avoid multiple form submission
        remove_all_actions('wp_loaded');
        wp_redirect(wc_get_account_endpoint_url(self::$endpoint));
        exit;
    }
    
    # Get a single user subscription
    protected function get_user_subscription($user_id, $subscription_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE id_axepta_bnpp_customer_subscription_payment = %d AND id_customer = %d",
                $subscription_id,
                $user_id
            ),
            ARRAY_A
        );
    }
    
    # Pause a subscription
    protected function pause_subscription($subscription_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        
        $result = $wpdb->update(
            $table_name,
            ['status' => 2],
            ['status' => 2],
            ['id_axepta_bnpp_customer_subscription_payment' => $subscription_id],
            ['%d'],
            ['%d']
        );
        
        if ($result !== false) {
            $this->add_subscription_note($subscription_id, __('Abonnement mis en pause par le client', 'axepta-bnp-paribas'));
            wc_add_notice(__('Votre abonnement a été mis en pause avec succès.', 'axepta-bnp-paribas'), 'success');
        } else {
            wc_add_notice(__('Une erreur est survenue lors de la mise en pause de l\'abonnement.', 'axepta-bnp-paribas'), 'error');
        }
        
        return $result !== false;
    }
    
    # Resume a paused subscription
    protected function resume_subscription($subscription_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        
        # Calculate the new next payment date
        $next_payment = current_time('mysql');
        
        $result = $wpdb->update(
            $table_name,
            [
                'status' => 1,
                'next_schedule' => $next_payment
            ],
            ['id_axepta_bnpp_customer_subscription_payment' => $subscription_id],
            ['%d', '%s'],
            ['%d']
        );
        
        if ($result !== false) {
            $this->add_subscription_note($subscription_id, __('Abonnement réactivé par le client', 'axepta-bnp-paribas'));
            wc_add_notice(__('Votre abonnement a été réactivé avec succès.', 'axepta-bnp-paribas'), 'success');
        } else {
            wc_add_notice(__('Une erreur est survenue lors de la réactivation de l\'abonnement.', 'axepta-bnp-paribas'), 'error');
        }
        
        return $result !== false;
    }
    
    # Cancel a subscription
    protected function cancel_subscription($subscription_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        
        $result = $wpdb->update(
            $table_name,
            ['status' => 3],
            ['id_axepta_bnpp_customer_subscription_payment' => $subscription_id],
            ['%d'],
            ['%d']
        );
        
        if ($result !== false) {
            $this->add_subscription_note($subscription_id, __('Abonnement annulé par le client', 'axepta-bnp-paribas'));
            wc_add_notice(__('Votre abonnement a été annulé avec succès.', 'axepta-bnp-paribas'), 'success');
        } else {
            wc_add_notice(__('Une erreur est survenue lors de l\'annulation de l\'abonnement.', 'axepta-bnp-paribas'), 'error');
        }
        
        return $result !== false;
    }
    
    # Add a note to subscription history
    protected function add_subscription_note($subscription_id, $note) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_subscription_notes';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            $this->create_subscription_notes_table();
        }
        
        $wpdb->insert(
            $table_name,
            [
                'id_axepta_bnpp_customer_subscription_payment' => $subscription_id,
                'note' => $note,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s']
        );
    }
    
    # Create subscription notes table if not exists
    protected function create_subscription_notes_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_subscription_notes';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            id_axepta_bnpp_customer_subscription_payment bigint(20) NOT NULL,
            note text NOT NULL,
            created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id),
            KEY id_axepta_bnpp_customer_subscription_payment (id_axepta_bnpp_customer_subscription_payment)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    # Add endpoint for subscriptions page
    public function add_endpoint() {
        add_rewrite_endpoint(self::$endpoint, EP_ROOT | EP_PAGES);
    }

    /**
     * Add new query var
     *
     * @param array $vars Query vars.
     * @return array
     */
    public function add_query_vars($vars) {
        $vars[] = self::$endpoint;
        return $vars;
    }

    /**
     * Add menu item to My Account menu
     *
     * @param array $items Menu items.
     * @return array
     */
    public function add_menu_item($items) {
        $items = array_slice($items, 0, 3, true) +
            [self::$endpoint => __('Mes abonnements', 'axepta-bnp-paribas')] +
            array_slice($items, 3, null, true);
        
        return $items;
    }

    # Endpoint HTML content
    public function endpoint_content() {
        $user_id = get_current_user_id();
        $subscriptions = $this->get_user_subscriptions($user_id);
        
        wc_get_template(
            'myaccount/html-customer-subscriptions.php',
            [
                'subscriptions' => $subscriptions,
                'has_subscriptions' => !empty($subscriptions) && get_current_user_id() > 0,
                'customer_can_suspend' => get_option('axepta_settings')['axepta_subscription_customer_can_suspend'] === '1'
            ],
            '',
            AXEPTA_BNPP_PLUGIN_PATH . 'views/'
        );
    }

    /**
     * Get user subscriptions
     *
     * @param int $user_id User ID.
     * @return array
     */
    protected function get_user_subscriptions($user_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        
        # Verify if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            return [];
        }
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE id_customer = %d ORDER BY date_add DESC",
                absint($user_id)
            ),
            ARRAY_A
        );
        
        if (empty($results)) {
            return [];
        }
        
        $formatted_results = [];
        
        foreach ($results as $subscription) {
            # Ensure that the necessary fields exist
            if (!isset($subscription['id_axepta_bnpp_customer_subscription_payment'], $subscription['id_product'])) {
                continue;
            }
            
            # Get the product and order
            $product = wc_get_product($subscription['id_product']);
            $order = !empty($subscription['id_order']) ? wc_get_order($subscription['id_order']) : null;
            
            # Prepare the formatted data
            $formatted_subscription = array_merge($subscription, [
                'product' => $product,
                'order' => $order,
                'date_add_formatted' => !empty($subscription['date_add']) ? date_i18n(get_option('date_format'), strtotime($subscription['date_add'])) : '',
                'next_payment_formatted' => !empty($subscription['next_schedule']) ? date_i18n(get_option('date_format'), strtotime($subscription['next_schedule'])) : '',
                'amount_formatted' => wc_price(isset($subscription['amount_tax_exclude']) ? $subscription['amount_tax_exclude'] : 0),
                'status_label' => $this->get_status_label(isset($subscription['status']) ? $subscription['status'] : 0)
            ]);
            
            $formatted_results[] = $formatted_subscription;
        }
        
        return $formatted_results;
    }
    
    /**
     * Get status label
     *
     * @param int $status Status code.
     * @return string
     */
    protected function get_status_label($status) {
        $statuses = [
            0 => __('Inactif', 'axepta-bnp-paribas'),
            1 => __('Actif', 'axepta-bnp-paribas'),
            2 => __('En attente', 'axepta-bnp-paribas'),
            3 => __('Annulé', 'axepta-bnp-paribas'),
            4 => __('En erreur', 'axepta-bnp-paribas'),
        ];
        
        return isset($statuses[$status]) ? $statuses[$status] : __('Inconnu', 'axepta-bnp-paribas');
    }

    /**
     * Get periodicity label
     *
     * @param string $periodicity Periodicity code.
     * @return string
     */
    public static function get_periodicity_label($periodicity) {
        $periodicities = [
            'D' => __('jour', 'axepta-bnp-paribas'),
            'W' => __('semaine', 'axepta-bnp-paribas'),
            'M' => __('mois', 'axepta-bnp-paribas'),
            'Y' => __('anné', 'axepta-bnp-paribas'),
        ];
        
        return isset($periodicities[$periodicity]) ? $periodicities[$periodicity] : $periodicity;
    }
    
    # Register and enqueue styles
    public function enqueue_styles() {
        if (is_account_page()) {
            wp_enqueue_style(
                'axepta-bnpp-customer-subscriptions',
                AXEPTA_BNPP_PLUGIN_URL . 'assets/css/front/customer-subscriptions.css',
                [],
                AXEPTA_BNPP_VERSION
            );
        }
    }
}

// Initialize the class
new Axepta_BNPP_Customer_Subscription();
