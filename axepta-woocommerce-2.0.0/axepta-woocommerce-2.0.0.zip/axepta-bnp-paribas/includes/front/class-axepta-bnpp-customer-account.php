<?php

if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Customer_Account {
    /**
     * Endpoint name.
     *
     * @var string
     */
    public static $endpoint = "payment-methods";

    /**
     * Initialize the class
     */
    public function __construct() {
        # Register endpoint
        add_action('init', array($this, 'add_endpoint'));
        
        # Add query vars
        add_filter('query_vars', array($this, 'add_query_vars'), 0);
        
        # Insert the new endpoint into the My Account menu
        add_filter('woocommerce_account_menu_items', array($this, 'add_menu_item'));
        
        # Add content to the new endpoint
        add_action('woocommerce_account_' . self::$endpoint . '_endpoint', array($this, 'endpoint_content'));
        
        # Register styles and scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        # Handle form submissions
        add_action('template_redirect', array($this, 'handle_form_submissions'));
    }

    # Add endpoint for payment methods page
    public function add_endpoint() {
        add_rewrite_endpoint(self::$endpoint, EP_ROOT | EP_PAGES);
    }

    # Add new query var
    public function add_query_vars($vars) {
        $vars[] = self::$endpoint;
        return $vars;
    }

    # Add menu item to My Account menu
    public function add_menu_item($items) {
        # Insert our new endpoint right after dashboard
        $items = array_slice($items, 0, 2, true) +
            [self::$endpoint => __('Cartes de paiement', 'axepta-bnp-paribas')] +
            array_slice($items, 2, null, true);
        
        return $items;
    }

    # Endpoint HTML content
    public function endpoint_content() {
        $user_id = get_current_user_id();
        $card = Axepta_BNPP_OneClick::get_user_cards($user_id);
        
        # Include the template
        wc_get_template(
            'myaccount/html-user-saved-cards.php',
            array('card' => $card),
            '',
            AXEPTA_BNPP_PLUGIN_PATH . 'views/'
        );
    }

    # Register and enqueue scripts and styles
    public function enqueue_scripts() {
        if (is_account_page()) {
            wp_enqueue_style(
                'axepta-bnpp-account',
                AXEPTA_BNPP_PLUGIN_URL . 'assets/css/front/account.css',
                array(),
                AXEPTA_BNPP_VERSION
            );
            
            # Add inline script for better user feedback
            wp_add_inline_script('jquery', '
                jQuery(document).ready(function($) {
                    $(".remove-card-form").on("submit", function(e) {
                        if (!confirm("' . esc_js(__('Êtes-vous sûr de vouloir supprimer cette carte ?', 'axepta-bnp-paribas')) . '")) {
                            e.preventDefault();
                            return false;
                        }
                        $(this).find("button").prop("disabled", true).text("' . esc_js(__('Suppression en cours…', 'axepta-bnp-paribas')) . '");
                    });
                });
            ');
        }
    }
    
    # Handle form submissions
    public function handle_form_submissions() {
        if (!is_account_page() || !is_user_logged_in() || !isset($_POST['action'])) {
            return;
        }
        
        $user_id = get_current_user_id();
        
        # Handle card removal
        if (isset($_POST['action']) && 'remove_card' === $_POST['action'] && isset($_POST['_remove_card_nonce']) && isset($_POST['card_id'])) {
            if (!wp_verify_nonce($_POST['_remove_card_nonce'], 'remove_card_nonce')) {
                wc_add_notice(__('Requête invalide. Veuillez réessayer.', 'axepta-bnp-paribas'), 'error');
                return;
            }
            
            $result = Axepta_BNPP_OneClick::delete_user_card($user_id, $_POST['card_id']);
            
            if ($result) {
                wc_add_notice(__('Votre carte a été supprimée avec succès.', 'axepta-bnp-paribas'), 'success');
            } else {
                wc_add_notice(__('Échec de la suppression de votre carte. Veuillez réessayer.', 'axepta-bnp-paribas'), 'error');
            }
            
            # Redirect to prevent form resubmission
            wp_safe_redirect(wc_get_account_endpoint_url(self::$endpoint));
            exit;
        }
    }
}

# Initialize the class
new Axepta_BNPP_Customer_Account();
