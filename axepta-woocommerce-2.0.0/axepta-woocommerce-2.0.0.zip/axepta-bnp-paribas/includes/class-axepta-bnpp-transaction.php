<?php
use Automattic\WooCommerce\Utilities\OrderUtil;

class Axepta_BNPP_Transaction {

    public static function save($data, $transaction_type, $order, $amount = null) {
        global $wpdb;

        $capture = get_option('axepta_settings')['axepta_capture_mode'];
        $merchant_code = $data['merchant_code'] ?? $data['mid'] ?? null;
        $transaction_reference = $data['transaction_reference'] ?? null;
        $pay_id = $data['pay_id'] ?? null;
        $xid = $data['xid'] ?? null;
        $bid = $data['bid'] ?? null;

        if (is_null($amount)) {
            $amount = (float) $order->get_total();
        }

        $payment_mean_brand = $data['payment_mean_brand'] ?? null;
        $payment_mean_type = $data['payment_mean_type'] ?? null;
        $response_code = $data['response_code'] ?? null;
        $description = $data['description'] ?? null;
        $pcnr = $data['pcnr'] ?? null;
        $ccexpiry = $data['ccexpiry'] ?? null;
        $status = $data['status'] ?? null;
        $transaction_date = isset($data['trx_time']) ? \DateTime::createFromFormat('d.m.Y H:i:su', $data['trx_time']) : new \DateTime();

        $raw_data_filtered = array_filter($data, function ($key) {
            return in_array($key, Axepta_BNPP_Constant::LOG_AUTHORIZED_PARAMS, true);
        }, ARRAY_FILTER_USE_KEY);

        $inserted = $wpdb->insert(
            "{$wpdb->prefix}axepta_bnpp_transactions",
            [
                'transaction_date' => $transaction_date->format('Y-m-d H:i:s'),
                'merchant_id' => $merchant_code,
                'transaction_reference' => $transaction_reference,
                'order_id' => $order->get_id(),
                'pay_id' => $pay_id,
                'bid' => $bid,
                'xid' => $xid,
                'amount' => $amount,
                'transaction_type' => $transaction_type,
                'payment_mean_brand' => $payment_mean_brand,
                'payment_mean_type' => $payment_mean_type,
                'response_code' => $response_code,
                'pcnr' => $pcnr,
                'ccexpiry' => $ccexpiry,
                'status' => $status,
                'description' => $description,
                'capture_mode' => $capture,
                'raw_data' => json_encode($raw_data_filtered),
            ],
            [
                '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%f', '%s',
                '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
            ]
        );

        if (false === $inserted) {
            Axepta_Bnpp_Log::error(__("Échec de l'insertion de la transaction", 'axepta-bnp-paribas'), ['error' => $wpdb->last_error]);
            return false;
        }

        Axepta_Bnpp_Log::info(__('Transaction insérée avec succès', 'axepta-bnp-paribas'), ['transaction_id' => $wpdb->insert_id]);
        return $wpdb->insert_id;
    }

    public static function add_transaction($transaction, $transaction_type) {
        global $wpdb;

        if (!$transaction) {
            return new WP_Error('transaction_not_found', __('Transaction non trouvée', 'axepta-bnp-paribas'));
        }

        $data = [
            'merchant_id' => isset($transaction->merchant_id) ? sanitize_text_field($transaction->merchant_id) : '',
            'transaction_reference' => isset($transaction->transaction_reference) ? sanitize_text_field($transaction->transaction_reference) : null,
            'transaction_date' => current_time('mysql'),
            'order_id' => absint($transaction->order_id),
            'pay_id' => isset($transaction->pay_id) ? sanitize_text_field($transaction->pay_id) : null,
            'xid' => isset($transaction->xid) ? sanitize_text_field($transaction->xid) : null,
            'bid' => isset($transaction->bid) ? sanitize_text_field($transaction->bid) : null,
            'amount' => isset($transaction->amount) ? floatval($transaction->amount) : null,
            'transaction_type' => $transaction_type,
            'scheme_reference_id' => isset($transaction->scheme_reference_id) ? sanitize_text_field($transaction->scheme_reference_id) : null,
            'payment_mean_brand' => isset($transaction->payment_mean_brand) ? sanitize_text_field($transaction->payment_mean_brand) : null,
            'payment_mean_type' => isset($transaction->payment_mean_type) ? sanitize_text_field($transaction->payment_mean_type) : null,
            'response_code' => isset($transaction->response_code) ? sanitize_text_field($transaction->response_code) : null,
            'pcnr' => isset($transaction->pcnr) ? sanitize_text_field($transaction->pcnr) : null,
            'ccexpiry' => isset($transaction->ccexpiry) ? sanitize_text_field($transaction->ccexpiry) : null,
            'status' => isset($transaction->status) ? sanitize_text_field($transaction->status) : null,
            'description' => isset($transaction->description) ? sanitize_text_field($transaction->description) : null,
            'raw_data' => isset($transaction->raw_data) ? $transaction->raw_data : null,
            'ref_nr' => isset($transaction->ref_nr) ? sanitize_text_field($transaction->ref_nr) : null,
            'holder_name' => isset($transaction->holder_name) ? sanitize_text_field($transaction->holder_name) : null,
            'capture_mode' => isset($transaction->capture_mode) ? sanitize_text_field($transaction->capture_mode) : null,
            'captured' => isset($transaction->captured) ? $transaction->captured : null,
        ];


        $format = ['%s', '%s', '%s', '%d', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'];

        $result = $wpdb->insert("{$wpdb->prefix}axepta_bnpp_transactions", $data, $format);

        if ($result === false) {
            return false;
        }

        return $wpdb->insert_id;
    }

    public static function update_transaction_from_api_response($api_response) {
        global $wpdb;

        if (empty($api_response['transId']) || empty($api_response['payId'])) {
            Axepta_BNPP_Log::info(__('Aucune transaction ou paiement trouvé', 'axepta-bnp-paribas'));
            return false;
        }

        $transaction_id = $api_response['transId'];
        $merchant_id = $api_response['merchantId'];
        $pay_id = $api_response['payId'];
        $xid = $api_response['xId'];
        $description = isset($api_response['responseDescription']) ? $api_response['responseDescription'] : 'N/A';
        $amount = isset($api_response['amount']['value']) ? $api_response['amount']['value'] / 100 : 0;
        $card_info = isset($api_response['paymentMethods']['card']) ? $api_response['paymentMethods']['card'] : null;
        $ref_nr = isset($api_response['refNr']) ? $api_response['refNr'] : null;
        $holder_name = isset($card_info['cardHolderName']) ? $card_info['cardHolderName'] : null;
        $ccexpiry = isset($card_info['expiryDate']) ? $card_info['expiryDate'] : null;
        $scheme_reference_id = isset($api_response['metadata']['userdata']) ? $api_response['metadata']['userdata'] : null;
        $response_code = isset($api_response['responseCode']) ? $api_response['responseCode'] : 'N/A';
        $status = Axepta_BNPP_Helper::getTransactionStatus($api_response['status'], $response_code);

        $updated = $wpdb->update(
            "{$wpdb->prefix}axepta_bnpp_transactions",
            [
                'merchant_id' => $merchant_id,
                'transaction_reference' => $transaction_id,
                'pay_id' => $pay_id,
                'bid' => $pay_id,
                'xid' => $xid,
                'amount' => $amount,
                'scheme_reference_id' => $scheme_reference_id,
                'payment_mean_brand' => isset($card_info['brand']) ? $card_info['brand'] : 'N/A',
                'payment_mean_type' => isset($card_info['type']) ? $card_info['type'] : 'N/A',
                'response_code' => strtoupper($response_code),
                'pcnr' => $ref_nr,
                'ccexpiry' => $ccexpiry,
                'status' => strtoupper($status),
                'description' => $description,
                'raw_data' => json_encode($api_response),
                'ref_nr' => $ref_nr,
                'holder_name' => $holder_name
            ],
            ['transaction_id' => $transaction_id],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'],
            ['%d']
        );

        if ($updated !== false) {
            $transaction = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE transaction_id = %d AND pay_id = %s", 
                $transaction_id, 
                $pay_id
            ));
            return $transaction;
        }

        return false;
    }


    /**
     * @param int $transaction_id
     * @param string $capture_mode
     * @param string $captured
     * @return bool
     */
    public static function update_transaction_captured_mode(int $transaction_id, $capture_mode, $captured, $amount = null) {
        global $wpdb;

        $updated = $wpdb->update(
            "{$wpdb->prefix}axepta_bnpp_transactions",
            [ 'capture_mode' => $capture_mode, 'captured' => $captured, 'amount' => $amount !== null ? floatval($amount) : null, ],
            [ 'transaction_id' => $transaction_id, ],
            [ '%s', '%s', '%f', ],
            [ '%d', ]
        );

        if (false === $updated) {
            Axepta_Bnpp_Log::error(__("Échec de la mise à jour du statut et de la description de la transaction", 'axepta-bnp-paribas'), ['error' => $wpdb->last_error]);
            return false;
        }

        Axepta_Bnpp_Log::info(__('Mise à jour du statut et de la description de la transaction réussie', 'axepta-bnp-paribas'), ['transaction_id' => $transaction_id]);
        return true;
    }

    public static function check_already_exists($data, $order) {
        global $wpdb;

        $sql = "
            SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions
            WHERE transaction_reference = %s
              AND order_id = %d
              AND pay_id = %s
              AND xid = %s
              AND amount = %f
        ";

        $params = [
            $data['transaction_reference'] ?? null,
            (int) $order->get_id(),
            $data['pay_id'] ?? null,
            $data['xid'] ?? null,
            (float) $order->get_total(),
        ];

        if (!empty($data['pcnr'])) {
            $sql .= " AND pcnr = %s";
            $params[] = $data['pcnr'];
        }

        $result = $wpdb->get_row($wpdb->prepare($sql, ...$params));
        return !empty($result);
    }

    public static function get_by_trans_id($transaction_reference) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE transaction_reference = %s",
                $transaction_reference
            )
        );
    }

    public static function get_by_id($transaction_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE transaction_id = %d",
                $transaction_id
            )
        );
    }

    # Gets the transaction associated with an order
    public static function get_order_pending_transaction($order_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'axepta_bnpp_transactions';
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE order_id = %d AND status = %s ORDER BY transaction_date DESC LIMIT 1",
                $order_id,
                Axepta_BNPP_Constant::STATUS_PENDING
            ),
            ARRAY_A
        );
    }
        
    # Gets the transaction associated with an order
    public static function get_order_transaction($order_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'axepta_bnpp_transactions';
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE order_id = %d ORDER BY transaction_date DESC LIMIT 1",
                $order_id
            ),
            ARRAY_A
        );
    }

    public static function get_last_transaction_by_customer_id($customer_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE customer_id = %d ORDER BY transaction_id DESC LIMIT 1",
                $customer_id
            )
        );
    }

    public static function get_by_order_id($order_id) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE order_id = %d ORDER BY transaction_id DESC",
                $order_id
            )
        );
    }

    public static function get_successful_transaction_by_order_id($order_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions 
                 WHERE order_id = %d AND response_code = %s 
                 ORDER BY transaction_id DESC LIMIT 1",
                $order_id,
                '00000000'
            )
        );
    }

    public static function get_all() {
        global $wpdb;
        $mode = get_option('axepta_settings')['axepta_mode'];
        
        if ($mode === 'production') {
            return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions ORDER BY transaction_id DESC");
        }

        $statuses = ['AXEPTA DEMO OK', 'AXEPTA TEST OK', 'AXEPTA TEST FAIL'];
        $status_placeholders = implode(',', array_fill(0, count($statuses), '%s'));
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions WHERE status IN ($status_placeholders) ORDER BY transaction_id DESC",
            ...$statuses
        );

        return $wpdb->get_results($query);
    }

    public static function get_all_limit($offset, $limit) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_transactions ORDER BY transaction_id DESC LIMIT %d, %d",
                $offset,
                $limit
            )
        );
    }

    public static function get_count() {
        global $wpdb;
        return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}axepta_bnpp_transactions");
    }

    public static function output($order_or_post=null) {
        $order = ($order_or_post instanceof WP_Post) ? wc_get_order($order_or_post->ID) : $order_or_post;

        if (!$order instanceof WC_Order) {
            echo '<p>' . esc_html__('Objet de commande invalide.', 'axepta-bnp-paribas') . '</p>';
            return;
        }

        $order_id = $order->get_id();
        $transactions = Axepta_BNPP_Transaction::get_by_order_id($order_id);

        if (empty($transactions)) {
            echo '<p>' . esc_html__('Aucune transaction pour cette commande.', 'axepta-bnp-paribas') . '</p>';
            return;
        }

        $payment_mean_brand = $order->get_meta('payment_mean_brand');

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead>
                <tr>
                    <th>' . esc_html__('Date', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Marque', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('ID Transaction', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('ID Commande', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Code Marchand', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Montant', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Type', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Statut', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Réponse', 'axepta-bnp-paribas') . '</th>
                    <th>' . esc_html__('Détails', 'axepta-bnp-paribas') . '</th>
                </tr>
              </thead>';
        echo '<tbody>';

        foreach ($transactions as $transact) {
            $logo = '';
            $brand = $transact->payment_mean_brand ?: $payment_mean_brand;

            if ($brand) {
                $brand_upper = strtoupper($brand);
                $logo_path = plugin_dir_url(__FILE__) . "assets/img/{$brand_upper}.png";
                if (file_exists($logo_path)) {
                    $logo = "<img src='{$logo_path}' alt='{$brand}' style='height: 30px;'>";
                }
            }

            echo "<tr>
                    <td>{$transact->transaction_date}</td>
                    <td>{$logo} {$brand}</td>
                    <td>{$transact->transaction_reference}</td>
                    <td>{$transact->order_id}</td>
                    <td>{$transact->merchant_id}</td>
                    <td>{$transact->amount}</td>
                    <td>{$transact->transaction_type}</td>
                    <td>{$transact->status}</td>
                    <td>{$transact->response_code}</td>
                    <td><a href='" . esc_url(admin_url('admin.php?page=axepta_bnpp_transactions&transaction=' . $transact->transaction_id)) . "'>" . __('Détails', 'axepta-bnp-paribas') . "</a></td>
                </tr>";
        }

        echo '</tbody>';
        echo '</table>';
    }
}
