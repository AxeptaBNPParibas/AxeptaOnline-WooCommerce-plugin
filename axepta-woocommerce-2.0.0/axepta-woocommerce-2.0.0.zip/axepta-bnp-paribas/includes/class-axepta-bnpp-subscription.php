<?php
if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Subscription
{
    public function __construct()
    {
        add_action('add_meta_boxes', [$this, 'axepta_add_subscription_metabox']);
        add_action('woocommerce_process_product_meta', [$this, 'axepta_save_subscription_metabox'], 30, 1);
        add_action('admin_notices', [$this, 'notice_errors']);
    }

    # Add subscription metabox in product page
    public function axepta_add_subscription_metabox()
    {
        add_meta_box(
            'axepta_subscription_metabox',
            __('Options de paramétrage des abonnements par Axepta BNP Paribas', 'axepta-bnp-paribas'),
            [$this, 'axepta_render_subscription_metabox'],
            'product',
            'normal',
            'high'
        );
    }

    # Render subscription metabox
    public function axepta_render_subscription_metabox()
    {
        require_once AXEPTA_BNPP_PLUGIN_PATH . 'views/html-subscription-product-options.php';
    }

    /**
     * Validate subscription fields.
     *
     * @return array Array of errors.
     */
    public static function validate_subscription_fields(): array
    {
        $errors = [];

        $post_id = isset($_POST['post_ID']) ? absint($_POST['post_ID']) : 0;
        if (!$post_id) {
            $errors[] = __('Produit introuvable', 'axepta-bnp-paribas');
        }
        $product_type = isset($_POST['axepta_subscription_type']) ? sanitize_text_field($_POST['axepta_subscription_type']) : '';
        if (!in_array($product_type, ['simple', 'subscription'], true)) {
            $errors[] = __('Le type de produit est invalide', 'axepta-bnp-paribas');
        }

        if ($product_type === 'subscription') {
            $frequency = isset($_POST['axepta_subscription_frequency_text']) ? absint($_POST['axepta_subscription_frequency_text']) : 0;
            if ($frequency < 1 || $frequency > 50) {
                $errors[] = __('Saisissez un nombre entier entre 1 et 50 pour la fréquence', 'axepta-bnp-paribas');
            }

            $periodicity = isset($_POST['axepta_subscription_period']) ? sanitize_text_field($_POST['axepta_subscription_period']) : '';
            if (!in_array($periodicity, ['week', 'month', 'year'], true)) {
                $errors[] = __('Veuillez sélectionner une périodicité valide (semaines, mois, années)', 'axepta-bnp-paribas');
            }

            $expires_after = isset($_POST['axepta_subscription_expires_after']) ? sanitize_text_field($_POST['axepta_subscription_expires_after']) : '';
            $valid_expires = ['never', '2', '3', '4', 'custom'];
            if (!in_array($expires_after, $valid_expires, true)) {
                $errors[] = __('Veuillez sélectionner une option valide pour l\'expiration', 'axepta-bnp-paribas');
            }

            $billing_cycle = 0;
            if ($expires_after === 'custom') {
                $billing_cycle = isset($_POST['axepta_subscription_billing_cycle']) ? absint($_POST['axepta_subscription_billing_cycle']) : 0;
                if ($billing_cycle < 1 || $billing_cycle > 999) {
                    $errors[] = __('Les abonnements peuvent comporter jusqu’à 999 cycles de facturation', 'axepta-bnp-paribas');
                }
            } elseif (in_array($expires_after, ['2', '3', '4'], true)) {
                $billing_cycle = (int) $expires_after;
            }

            $recurring_amount = isset($_POST['axepta_subscription_amount']) ? floatval($_POST['axepta_subscription_amount']) : 0;
            if ($recurring_amount <= 0) {
                $errors[] = __('Le montant récurrent doit être supérieur à 0', 'axepta-bnp-paribas');
            }
        }

        return [
            'is_valid' => empty($errors),
            'errors' => $errors,
        ];
    }

    # Save subscription metabox
    public function axepta_save_subscription_metabox($post_id)
    {
        global $wpdb;

        if (!isset($_POST['axepta_subscription_nonce']) || !wp_verify_nonce($_POST['axepta_subscription_nonce'], 'axepta_subscription_save_' . $post_id)) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        $validation = self::validate_subscription_fields();
        if (!$validation['is_valid']) {
            $user_id = get_current_user_id();
            set_transient("axepta_subscription_post_errors_{$user_id}", json_encode($validation['errors']), 45);
            wp_safe_redirect(add_query_arg('axepta_error', 'validation_failed', wp_get_referer()));
            exit;
        }
        $product_type = sanitize_text_field($_POST['axepta_subscription_type']);
        $recurringData = [
            'id_product' => $post_id,
            'type' => ($product_type === 'subscription') ? 2 : 1,
        ];

        if ($product_type === 'subscription') {
            $recurringData['number_periodicity'] = absint($_POST['axepta_subscription_frequency_text']);
            $recurringData['periodicity'] = sanitize_text_field($_POST['axepta_subscription_period']);
            $expires_after = sanitize_text_field($_POST['axepta_subscription_expires_after']);
            $recurringData['number_occurences'] = ($expires_after === 'never') ? 0 : ($expires_after === 'custom' ? absint($_POST['axepta_subscription_billing_cycle']) : absint($expires_after));
            $recurringData['recurring_amount'] = floatval($_POST['axepta_subscription_amount']);
        } else {
            $recurringData['number_periodicity'] = 0;
            $recurringData['periodicity'] = '';
            $recurringData['number_occurences'] = 0;
            $recurringData['recurring_amount'] = 0.0;
        }

        $existing_record = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}axepta_bnpp_subscription_product WHERE id_product = %d", $post_id)
        );

        if ($existing_record) {
            $result = $wpdb->update(
                "{$wpdb->prefix}axepta_bnpp_subscription_product",
                $recurringData,
                ['id_product' => $post_id],
                ['%d', '%d', '%d', '%s', '%d', '%f'],
                ['%d']
            );
        } else {
            $result = $wpdb->insert(
                "{$wpdb->prefix}axepta_bnpp_subscription_product",
                $recurringData,
                ['%d', '%d', '%d', '%s', '%d', '%f']
            );
        }
        update_post_meta($post_id, '_axepta_product_type', $product_type);
        if ($product_type === 'subscription') {
            $recurring_amount = floatval($_POST['axepta_subscription_amount']);
            $recurringData['recurring_amount'] = $recurring_amount;

            $product = wc_get_product($post_id);
            if ($product) {
                $product->set_regular_price($recurring_amount);
                $product->set_price($recurring_amount);
                $product->save();

                wp_cache_delete($post_id, 'post_meta');
                wp_cache_delete($post_id, 'posts');
            }
        }
    }

    # Notice errors
    public function notice_errors()
    {
        $user_id = get_current_user_id();
        $errors = get_transient("axepta_subscription_post_errors_{$user_id}");
        if ($errors) {
            $errors = json_decode($errors, true);
            foreach ($errors as $error) {
                echo '<div class="error"><p>' . esc_html($error) . '</p></div>';
            }
            delete_transient("axepta_subscription_post_errors_{$user_id}");
        }
    }
}

new Axepta_BNPP_Subscription();