<?php

if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Order_Status {
    public function __construct() {
        add_action('init', [__CLASS__, 'register_custom_order_statuses']);
        add_filter('wc_order_statuses', [$this, 'add_custom_order_statuses_to_dropdown']);

        add_action('admin_head', [$this, 'axepta_custom_order_status_css']);
        add_action('pre_get_posts', [$this, 'filter_orders_legacy'], 20);
        
        # Hook for HPOS (High-Performance Order Storage) filter - new version
        add_filter('woocommerce_order_list_table_prepare_items_query_args', [$this, 'filter_orders_hpos'], 10, 2);

        add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_column' ] );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'render_column' ], 10, 2 );
    }

    public static function register_custom_order_statuses() {
        $mode = get_option('axepta_settings')['axepta_mode'] ?? 'production';

        if ($mode === 'production') {
            register_post_status(Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::CAPTURE_PENDING), [
                'label' => __('Capture paiement en attente', 'axepta-bnp-paribas'),
                'public' => true,
                'exclude_from_search' => false,
                'show_in_admin_all_list' => true,
                'show_in_admin_status_list' => true,
                'label_count' => _n_noop(
                    'Capture paiement en attente <span class="count">(%s)</span>',
                    'Captures paiements en attente <span class="count">(%s)</span>',
                    'axepta-bnp-paribas'
                ),
            ]);
        } else {
            register_post_status(Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::DEMO_OK), [
                'label' => __('DEMO Axepta BNP Paribas (Paiement accepté)', 'axepta-bnp-paribas'),
                'public' => true,
                'exclude_from_search' => false,
                'show_in_admin_all_list' => true,
                'show_in_admin_status_list' => true,
                'label_count' => _n_noop(
                    'Paiement accepté (Axepta DEMO) <span class="count">(%s)</span>',
                    'Paiements acceptés (Axepta DEMO) <span class="count">(%s)</span>',
                    'axepta-bnp-paribas'
                ),
            ]);
            register_post_status(Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_OK), [
                'label' => __('TEST Axepta BNP Paribas (Paiement accepté)', 'axepta-bnp-paribas'),
                'public' => true,
                'exclude_from_search' => false,
                'show_in_admin_all_list' => true,
                'show_in_admin_status_list' => true,
                'label_count' => _n_noop(
                    'TEST Axepta BNP Paribas (Paiement accepté) <span class="count">(%s)</span>',
                    'TEST Axepta BNP Paribas (Paiements acceptés) <span class="count">(%s)</span>',
                    'axepta-bnp-paribas'
                ),
            ]);
            register_post_status(Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_FAIL), [
                'label' => __('TEST Axepta BNP Paribas (Paiement en erreur)', 'axepta-bnp-paribas'),
                'public' => true,
                'exclude_from_search' => false,
                'show_in_admin_all_list' => true,
                'show_in_admin_status_list' => true,
                'label_count' => _n_noop(
                    'TEST Axepta BNP Paribas (Paiement en erreur) <span class="count">(%s)</span>',
                    'TEST Axepta BNP Paribas (Paiements en erreur) <span class="count">(%s)</span>',
                    'axepta-bnp-paribas'
                ),
            ]);
        }
    }

    public function add_custom_order_statuses_to_dropdown($order_statuses) {
        $new_statuses = [];
        $mode = get_option('axepta_settings')['axepta_mode'] ?? 'production';

        foreach ($order_statuses as $key => $status) {
            $new_statuses[$key] = $status;

            if ('wc-processing' === $key) {
                if ($mode === 'production') {
                    $new_statuses[Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::CAPTURE_PENDING)]
                        = __('Capture paiement en attente', 'axepta-bnp-paribas');
                } else {
                    $new_statuses[Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::DEMO_OK)]
                        = __('DEMO Axepta BNP Paribas (Paiement accepté)', 'axepta-bnp-paribas');
                    $new_statuses[Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_OK)]
                        = __('TEST Axepta BNP Paribas (Paiement accepté)', 'axepta-bnp-paribas');
                    $new_statuses[Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_FAIL)]
                        = __('TEST Axepta BNP Paribas (Paiement en erreur)', 'axepta-bnp-paribas');
                }
            }
        }

        return $new_statuses;
    }

    public function axepta_custom_order_status_css() {
        echo '<style>
            .order-status.status-axepta-demo-ok { background: #2993fcff !important; color: #000 !important; }
            .order-status.status-axepta-test-ok { background: #66cc66 !important; color: #000 !important; }
            .order-status.status-axepta-test-fail { background: #FF9330 !important; color: #000 !important; }
        </style>';
    }

    public function filter_orders_hpos($query_args) {
        if (!isset($_GET['status']) || empty($_GET['status'])) {
            if (get_option('axepta_settings')['axepta_mode'] !== 'production') {
                $query_args['status'] = [
                    Axepta_BNPP_Constant::DEMO_OK,
                    Axepta_BNPP_Constant::TEST_OK,
                    Axepta_BNPP_Constant::TEST_FAIL,
                ];
            }
        }

        return $query_args;
    }

    public function filter_orders_legacy($query) {
        global $pagenow, $post_type;

        if (!is_admin() || $pagenow !== 'edit.php' || $post_type !== 'shop_order') {
            return;
        }

        if (!isset($_GET['post_status']) || empty($_GET['post_status'])) {
            if (get_option('axepta_settings')['axepta_mode'] !== 'production') {
                $query->set('post_status', [
                    Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::DEMO_OK),
                    Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_OK),
                    Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::TEST_FAIL),
                ]);
            }
        }
    }

    public function add_column($columns) {
        $new_columns = [];

        foreach ($columns as $key => $label) {
            $new_columns[$key] = $label;

            if ('order_status' === $key) {
                $new_columns['capture_status'] = __('Statut de la capture', 'my-plugin');
            }
        }

        return $new_columns;
    }

    public function render_column($column, $order) {
        if ('capture_status' === $column) {
            echo $this->get_capture_status_and_elapsed_time($order);
        }
    }

    public function get_capture_status_and_elapsed_time($order) {
        $created_time = strtotime($order->get_date_created());
        $days_diff = (time() - $created_time) / (60 * 60 * 24);
        $hours_diff = (time() - $created_time) / (60 * 60);
        
        $capture_status = $order->get_meta('_capture_status');

        if(empty($capture_status)) {
            return '-';
        }
        
        if ($capture_status === 'Capturé' || $capture_status === 'Captured') {
            return esc_html(__('Capturé', 'axepta-bnp-paribas'));
        }

        if ($days_diff >= 2) {
            $time_info = round($days_diff) . ' ' . __('jours', 'axepta-bnp-paribas');
        } elseif ($days_diff >= 1) {
            $time_info = '1 ' . __('jour', 'axepta-bnp-paribas');
            $extra_hours = round($hours_diff - 24);
            if ($extra_hours > 0) {
                $time_info .= ' ' . $extra_hours . 'h';
            }
        } else {
            $time_info = round($hours_diff) . 'h';
        }
        
        return $capture_status ? esc_html($capture_status) . ' (' . $time_info . ')' : '-';
    }
    
}

new Axepta_BNPP_Order_Status();