<?php
defined('ABSPATH') || exit;

class Axepta_BNPP_Transaction_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct([
            'singular' => __('Transaction', 'axepta-bnp-paribas'),
            'plural' => __('Transactions', 'axepta-bnp-paribas'),
            'ajax' => false
        ]);
        
        add_action('admin_notices', [$this, 'display_settings_errors']);
    }

    public function get_columns() {
        return [
            'cb' => '<input type="checkbox" />',
            'transaction_id' => __('ID', 'axepta-bnp-paribas'),
            'payment_mean_brand' => __('Brand', 'axepta-bnp-paribas'),
            'order_id' => __('Commande', 'axepta-bnp-paribas'),
            'transaction_reference' => __('Référence', 'axepta-bnp-paribas'),
            'amount' => __('Montant', 'axepta-bnp-paribas'),
            'status' => __('Statut', 'axepta-bnp-paribas'),
            'transaction_type' => __('Type de transaction', 'axepta-bnp-paribas'),
            'transaction_date' => __('Date', 'axepta-bnp-paribas'),
        ];
    }

    public function get_sortable_columns() {
        return [
            'transaction_id' => ['transaction_id', false],
            'order_id' => ['order_id', false],
            'transaction_reference' => ['transaction_reference', false],
            'amount' => ['amount', false],
            'status' => ['status', false],
            'transaction_date' => ['transaction_date', false],
        ];
    }

    protected function get_bulk_actions() {
        return [
            'delete' => __('Supprimer', 'axepta-bnp-paribas'),
        ];
    }

    protected function extra_tablenav($which) {
        if ($which == "top") {
            global $wpdb;
            $table_name = $wpdb->prefix . 'axepta_bnpp_transactions';
            $statuses = $wpdb->get_col("SELECT DISTINCT status FROM $table_name WHERE status IS NOT NULL AND status != '' ORDER BY status ASC");
            
            if (!empty($statuses)) {
                echo '<div class="alignleft actions">';
                $current_status = $_GET['status_filter'] ?? '';
                echo '<select name="status_filter">';
                echo '<option value="">' . __('Tous les statuts', 'axepta-bnp-paribas') . '</option>';
                foreach ($statuses as $status) {
                    printf(
                        '<option value="%s"%s>%s</option>',
                        esc_attr($status),
                        selected($current_status, $status, false),
                        esc_html(ucfirst($status))
                    );
                }
                echo '</select>';
                submit_button(__('Filtrer'), 'button', 'filter_action', false, ['id' => 'post-query-submit']);
                echo '</div>';
            }
        }
    }

    public function column_cb($item) {
        return sprintf('<input type="checkbox" name="transaction[]" value="%s" />', $item['transaction_id']);
    }

    public function column_default($item, $column_name) {
        return esc_html($item[$column_name] ?? '');
    }

    public function column_order_id($item) {
        if (!empty($item['order_id']) && ($order = wc_get_order($item['order_id']))) {
            return sprintf('<a href="%s">#%s</a>', esc_url($order->get_edit_order_url()), esc_html($order->get_order_number()));
        }
        return '&ndash;';
    }

    public function column_amount($item) {
        $order = wc_get_order($item['order_id']);
        $currency = $order ? $order->get_currency() : get_woocommerce_currency();

        $span = $item['transaction_type'] === Axepta_BNPP_Constant::CAPTURE_PAYMENT || $item['transaction_type'] === Axepta_BNPP_Constant::SIMPLE_PAYMENT 
            ? "<span style='color: green;'> + " : ($item['transaction_type'] === Axepta_BNPP_Constant::PAYMENT_REFUND || $item['transaction_type'] === Axepta_BNPP_Constant::PAYMENT_REVERSAL ? "<span style='color: red;'> - " : "<span>");
        
        return $span . wc_price($item['amount'], ['currency' => $currency]) . "</span>";
    }

    public function column_transaction_id($item) {
        $actions = [];
        $page = esc_attr($_REQUEST['page']);

        # view action
        $view_url = add_query_arg(['action' => 'view', 'transaction' => $item['transaction_id']], menu_page_url($page, false));
        $actions['view'] = sprintf('<a href="%s">' . __('Détails', 'axepta-bnp-paribas') . '</a>', esc_url($view_url));

        # capture action
        if ($item['transaction_reference'] && $item['transaction_type'] === 'SIMPLE_PAYMENT' && $item['capture_mode'] === 'manuel' && $item['captured'] !== 'yes') {
            $capture_nonce = wp_create_nonce('axepta_bnpp_capture_transaction_' . $item['transaction_id']);
            $capture_url = add_query_arg(['action' => 'capture', 'transaction' => $item['transaction_id'], '_wpnonce' => $capture_nonce], menu_page_url($page, false));
            $actions['capture'] = sprintf('<a href="%s" onclick="return confirm(\'' . esc_js(__('Êtes-vous sûr de vouloir capturer cette transaction ?', 'axepta-bnp-paribas')) . '\');" style="background:#135e96; color: #fff; padding: 3px;">' . __('Capture', 'axepta-bnp-paribas') . '</a>', esc_url($capture_url));
        }

        # capture action
        if ($item['transaction_reference'] && $item['transaction_type'] === 'SIMPLE_PAYMENT' && $item['capture_mode'] === 'manuel' && $item['captured'] !== 'yes') {
            $capture_nonce = wp_create_nonce('axepta_bnpp_cancel_capture_transaction_' . $item['transaction_id']);
            $cancel_capture_url = add_query_arg(['action' => 'cancel_capture', 'transaction' => $item['transaction_id'], '_wpnonce' => $capture_nonce], menu_page_url($page, false));
            $actions['cancel_capture'] = sprintf('<a href="%s" onclick="return confirm(\'' . esc_js(__('Êtes-vous sûr de vouloir annuler cette capture ?', 'axepta-bnp-paribas')) . '\');" style="background:#a00; color: #fff; padding: 3px;">' . __('Annulation', 'axepta-bnp-paribas') . '</a>', esc_url($cancel_capture_url));
        }
        
        # delete action
        $delete_nonce = wp_create_nonce('axepta_bnpp_delete_transaction_' . $item['transaction_id']);
        $delete_url = add_query_arg(['action' => 'delete', 'transaction' => $item['transaction_id'], '_wpnonce' => $delete_nonce], menu_page_url($page, false));
        $actions['delete'] = sprintf('<a href="%s" onclick="return confirm(\'' . esc_js(__('Êtes-vous sûr de vouloir supprimer cette transaction ?', 'axepta-bnp-paribas')) . '\');" style="color:#a00;">' . __('Supprimer', 'axepta-bnp-paribas') . '</a>', esc_url($delete_url));

        return sprintf('%1$s %2$s', $item['transaction_id'], $this->row_actions($actions));
    }

    public function column_payment_mean_brand($item) {
        $path = get_site_url() . "/wp-content/plugins/axepta-bnp-paribas/assets/img/" . strtoupper($item['payment_mean_brand'] ?? '') . ".png";
        return '<img src="' . esc_url($path) . '" alt="' . esc_attr($item['payment_mean_brand'] ?? '') . '" style="max-width: 50px; height: auto;" />';
    }

    public function column_transaction_date($item) {
        $date = !empty($item['transaction_date']) ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($item['transaction_date'])) : '';
        return esc_html($date);
    }

    public function prepare_items() {
        global $wpdb;
        $mode = get_option('axepta_settings', [])['axepta_mode'] ?? 'production';

        $this->_column_headers = $this->get_column_info();
        
        $this->process_action();

        $per_page = $this->get_items_per_page('transactions_per_page', 20);
        $current_page = $this->get_pagenum();
        $table_name = $wpdb->prefix . 'axepta_bnpp_transactions';

        $sql_select = "SELECT *";
        $sql_from = "FROM $table_name";
        $where = [];

        $statuses = $mode !== 'production' ? [Axepta_BNPP_Constant::TRANSACTION_DEMO_SUCCESS, Axepta_BNPP_Constant::TRANSACTION_TEST_SUCCESS] 
            : [Axepta_BNPP_Constant::STATUS_SUCCESS, Axepta_BNPP_Constant::STATUS_FAILED, Axepta_BNPP_Constant::STATUS_CANCELED, Axepta_BNPP_Constant::STATUS_PENDING];
        
        $placeholders = implode(',', array_fill(0, count($statuses), '%s'));
        $where[] = $wpdb->prepare("`status` IN ($placeholders)", $statuses);

        if (!empty($_REQUEST['s'])) {
            $search = esc_sql($_REQUEST['s']);
            $where[] = $wpdb->prepare("(`transaction_reference` LIKE %s OR `order_id` LIKE %s)", "%{$search}%", "%{$search}%");
        }

        if (!empty($_REQUEST['status_filter'])) {
            $status_filter = sanitize_text_field($_REQUEST['status_filter']);
            $where[] = $wpdb->prepare("`status` = %s", $status_filter);
        }

        $sql_where = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';

        $orderby = !empty($_GET['orderby']) ? esc_sql($_GET['orderby']) : 'transaction_id';
        $order = !empty($_GET['order']) && in_array(strtoupper($_GET['order']), ['ASC', 'DESC']) ? $_GET['order'] : 'DESC';
        $sql_orderby = "ORDER BY $orderby $order";

        $total_items = $wpdb->get_var("SELECT COUNT(transaction_id) $sql_from $sql_where");

        $sql_limit = $wpdb->prepare("LIMIT %d OFFSET %d", $per_page, ($current_page - 1) * $per_page);

        $this->items = $wpdb->get_results("$sql_select $sql_from $sql_where $sql_orderby $sql_limit", ARRAY_A);

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);
    }

    public function process_action() {
        $action = $this->current_action();

        # single capture action handler
        if ('capture' === $action && isset($_GET['transaction'])) {
            $transaction_id = intval($_GET['transaction']);
            $nonce = $_GET['_wpnonce'] ?? '';

            if (wp_verify_nonce($nonce, 'axepta_bnpp_capture_transaction_' . $transaction_id)) {
                self::capture_payment($transaction_id);
                wp_redirect(
                    remove_query_arg(
                        ['action', '_wpnonce'],
                        wp_get_referer() ?: admin_url('admin.php?page=axepta_bnpp_transactions')
                    )
                );
                exit;
            }
        }

        # single capture action handler
        if ('cancel_capture' === $action && isset($_GET['transaction'])) {
            $transaction_id = intval($_GET['transaction']);
            $nonce = $_GET['_wpnonce'] ?? '';

            if (wp_verify_nonce($nonce, 'axepta_bnpp_cancel_capture_transaction_' . $transaction_id)) {
                self::cancel_capture($transaction_id);
                wp_redirect(
                    remove_query_arg(
                        ['action', '_wpnonce'],
                        wp_get_referer() ?: admin_url('admin.php?page=axepta_bnpp_transactions')
                    )
                );
                exit;
            }
        }

        // Single delete
        if ('delete' === $action && isset($_GET['transaction'])) {
            $transaction_id = intval($_GET['transaction']);
            $nonce = $_GET['_wpnonce'] ?? '';

            if (wp_verify_nonce($nonce, 'axepta_bnpp_delete_transaction_' . $transaction_id)) {
                self::delete_transaction($transaction_id);
                wp_redirect(remove_query_arg(['action', 'transaction', '_wpnonce']));
                exit;
            }
        }

        // Bulk delete
        if ('delete' === $action && isset($_POST['transaction'])) {
            $nonce = $_POST['_wpnonce'] ?? '';
            if (wp_verify_nonce($nonce, 'bulk-transactions')) {
                $ids = array_map('intval', $_POST['transaction']);
                if (count($ids)) {
                    foreach ($ids as $id) {
                        self::delete_transaction($id);
                    }
                }
                wp_redirect(remove_query_arg(['action', 'action2', '_wpnonce', 'transaction']));
                exit;
            }
        }
    }

    public static function delete_transaction($id) {
        global $wpdb;
        $wpdb->delete(
            "{$wpdb->prefix}axepta_bnpp_transactions",
            ['transaction_id' => $id],
            ['%d']
        );
    }

    public function capture_payment($id) {
        $transaction = Axepta_BNPP_Transaction::get_by_id($id);
        $order = wc_get_order($transaction->order_id);

        if ($order) {
            $result = Axepta_BNPP_Handle_Capture::capture_payment(
                $transaction,
                $order->get_currency(),
                $order->get_billing_country()
            );

            if ($result['status'] === 'success') {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_success',
                    $result['message'],
                    'updated'
                );
                $order->set_status('processing', __('Paiement capturé avec succès via Axepta BNP Paribas', 'axepta-bnp-paribas'));
                $order->update_meta_data( '_capture_status', 'Capturé' );
                $order->save();
                $this->store_message_transient($result['message'], 'success');
            } else {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_failed',
                    $result['message'] . 'lll',
                    'error'
                );
                $this->store_message_transient($result['message'], 'error');
            }
        } else {
            add_settings_error(
                'axepta_messages',
                'axepta_order_not_found',
                __("Commande introuvable.", 'axepta-bnp-paribas'),
                'error'
            );
            $this->store_message_transient(__("Commande introuvable.", 'axepta-bnp-paribas'), 'error');
        }
    }
    public function cancel_capture($id) {
        $transaction = Axepta_BNPP_Transaction::get_by_id($id);
        $order = wc_get_order($transaction->order_id);

        if ($order) {
            $result = Axepta_BNPP_Handle_Capture::cancel_capture($transaction);

            if ($result['status'] === 'success') {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_success',
                    $result['message'],
                    'updated'
                );
                $this->store_message_transient($result['message'], 'success');
            } else {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_failed',
                    $result['message'] . 'lll',
                    'error'
                );
                $this->store_message_transient($result['message'], 'error');
            }
        } else {
            add_settings_error(
                'axepta_messages',
                'axepta_order_not_found',
                __("Commande introuvable.", 'axepta-bnp-paribas'),
                'error'
            );
            $this->store_message_transient(__("Commande introuvable.", 'axepta-bnp-paribas'), 'error');
        }
    }

    public function store_message_transient($message, $type = 'success') {
        $messages = get_transient('axepta_messages_transient');
        if (!is_array($messages)) {
            $messages = [];
        }
        $messages[] = [
            'message' => $message,
            'type'    => $type === 'success' ? 'success' : 'error',
        ];
        set_transient('axepta_messages_transient', $messages, 60);
    }

    public function display_settings_errors() {
        settings_errors('axepta_messages');
        if ($messages = get_transient('axepta_messages_transient')) {
            foreach ($messages as $msg) {
                echo '<div class="notice notice-' . esc_attr($msg['type']) . ' is-dismissible"><p>' . esc_html($msg['message']) . '</p></div>';
            }
            delete_transient('axepta_messages_transient');
        }
    }
    
    public function no_items() {
        _e('Aucune transaction trouvée.', 'axepta-bnp-paribas');
    }
}