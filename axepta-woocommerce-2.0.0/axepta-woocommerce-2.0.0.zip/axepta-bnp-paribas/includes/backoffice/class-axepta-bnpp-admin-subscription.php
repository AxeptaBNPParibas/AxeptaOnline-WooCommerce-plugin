<?php
defined('ABSPATH') || exit;

class Axepta_BNPP_Admin_Subscription {

    public function __construct() {
        add_action('admin_menu', [$this, 'register_submenu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_axepta_subscription_action', [$this, 'handle_single_action']);
    }

    public function register_submenu() {
        add_submenu_page(
            'woocommerce',
            __('Abonnements', 'axepta-bnp-paribas'),
            __('Abonnements', 'axepta-bnp-paribas'),
            'manage_woocommerce',
            'axepta-bnpp-subscriptions',
            [$this, 'render_subscriptions_page']
        );
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook === 'woocommerce_page_axepta-bnpp-subscriptions') {
            wp_enqueue_script(
                'axepta-subscription-js',
                AXEPTA_BNPP_PLUGIN_URL . 'assets/js/admin/subscription.js',
                ['jquery'],
                '1.0',
                true
            );

            wp_localize_script('axepta-subscription-js', 'axeptaAjax', [
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('axepta_action_nonce'),
            ]);

		    wp_set_script_translations('axepta-subscription-js', 'axepta-bnp-paribas', AXEPTA_BNPP_PLUGIN_URL . 'languages');
        }
    }

    public function render_subscriptions_page() {
        if (!empty($_GET['action']) && !empty($_GET['subscription'])) {
            global $wpdb;
            $table = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
            $id = intval($_GET['subscription']);
            $action = sanitize_key($_GET['action']);
        
            if (in_array($action, ['enable', 'disable', 'delete'], true)) {
                $status_map = ['enable' => 1, 'disable' => 0, 'delete' => 2];
                $wpdb->update($table, ['status' => $status_map[$action]], ['id_axepta_bnpp_customer_subscription_payment' => $id]);
                wp_redirect(remove_query_arg(['action', 'subscription']));
                exit;
            }
        }
        
        echo '<div class="wrap"><h1>' . __('Liste des Abonnements', 'axepta-bnp-paribas') . '</h1>';
        echo '<form method="post">';
        $table = new Axepta_BNPP_Subscription_Table();
        $table->prepare_items();
        $table->display();
        echo '</form></div>';
    }

    public function handle_single_action() {
        check_ajax_referer('axepta_action_nonce', 'nonce');

        $id = intval($_POST['subscription_id'] ?? 0);
        $action = sanitize_text_field($_POST['subscription_action'] ?? '');

        $status_map = [
            'enable' => 1,
            'disable' => 0,
            'delete' => 2
        ];

        if (!$id || !isset($status_map[$action])) {
            wp_send_json_error(['message' => __('Requête invalide.', 'axepta-bnp-paribas')]);
        }

        global $wpdb;
        $table = "{$wpdb->prefix}axepta_bnpp_customer_subscription_payment";

        $updated = $wpdb->update(
            $table,
            ['status' => $status_map[$action]],
            ['id_axepta_bnpp_customer_subscription_payment' => $id]
        );

        if ($updated !== false) {
            wp_send_json_success(['message' => __('Abonnement mis à jour avec succès.', 'axepta-bnp-paribas')]);
        } else {
            wp_send_json_error(['message' => __('Échec de la mise à jour.', 'axepta-bnp-paribas')]);
        }
    }
}

new Axepta_BNPP_Admin_Subscription();