<?php
defined('ABSPATH') || exit;

if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

require_once(plugin_dir_path(__FILE__) . 'class-axepta-bnpp-transaction-table.php');

class Axepta_BNPP_Admin_Transaction {

    /** @var Axepta_BNPP_Transaction_Table */
    private $list_table;

    public function __construct() {
        add_action('admin_menu', [$this, 'register_submenu']);
    }

    public function register_submenu() {
        $hook = add_submenu_page(
            'woocommerce',
            __('Axepta BNP Paribas : Historique de Transactions', 'axepta-bnp-paribas'),
            __('Transactions', 'axepta-bnp-paribas'),
            'manage_woocommerce',
            'axepta-bnpp-transactions',
            [$this, 'render_transactions_page']
        );
        add_action("load-$hook", [$this, 'screen_options']);
    }

    public function screen_options() {
        $option = 'per_page';
        $args = [
            'label' => __('Transactions', 'axepta-bnp-paribas'),
            'default' => 20,
            'option' => 'transactions_per_page'
        ];
        add_screen_option($option, $args);
        $this->list_table = new Axepta_BNPP_Transaction_Table();
    }

    public function render_transactions_page() {
        echo '<div class="wrap"><h1>' . __('Liste des Transactions', 'axepta-bnp-paribas') . '</h1>';
        if (isset($_GET['action']) && $_GET['action'] == 'view' && isset($_GET['transaction'])) {
            $this->render_transaction_details_page(intval($_GET['transaction']));
            return;
        }
        echo '<form method="post">';
        $this->list_table->prepare_items();
        $this->list_table->search_box(__('Rechercher'), 'transaction');
        $this->list_table->display();
        echo '</form></div>';
    }

    public function render_transaction_details_page($transaction_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'axepta_bnpp_transactions';
        $transaction = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE transaction_id=%d", $transaction_id));

        if (!$transaction) {
            echo '<div class="error"><p>' . __('Transaction non trouvée.', 'axepta-bnp-paribas') . '</p></div>';
            return;
        }

        echo '<h2>' . sprintf(__('Détails de la transaction #%d', 'axepta-bnp-paribas'), $transaction->transaction_id) . '</h2>';
        echo '<a href="' . esc_url(remove_query_arg(['action', 'transaction', '_wpnonce'])) . '" class="page-title-action">' . __('Retour à la liste', 'axepta-bnp-paribas') . '</a>';

        echo '<table class="form-table" style="margin-top: 20px;">';
        foreach ($transaction as $key => $value) {
            echo '<tr>';
            echo '<th scope="row" style="width: 200px;">' . esc_html(ucfirst(str_replace('_', ' ', $key))) . '</th>';
            if ($key === 'raw_data') {
                $data = maybe_unserialize($value);
                echo '<td><pre style="white-space: pre-wrap; word-break: break-all;">' . esc_html(print_r($data, true)) . '</pre></td>';
            } else {
                echo '<td>' . esc_html($value) . '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
new Axepta_BNPP_Admin_Transaction();