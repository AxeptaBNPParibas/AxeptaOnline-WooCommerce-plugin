<?php

class Axepta_BNPP_Admin_Transactions
{
    public function __construct() {
        add_action('admin_menu', [$this, 'register_axepta_bnpp_transactions_submenu_page']);
        add_action('admin_notices', [$this, 'display_settings_errors']);
    }

    public function register_axepta_bnpp_transactions_submenu_page() {
        add_submenu_page(
            'woocommerce',
            __('Axepta BNP Paribas transactions', 'axepta-bnp-paribas'),
            __('Transactions', 'axepta-bnp-paribas'),
            'manage_woocommerce',
            'axepta_bnpp_transactions',
            [$this, 'axepta_bnpp_transactions_page_callback']
        );
    }

    public function axepta_bnpp_transactions_page_callback() {
        if (isset($_GET['transaction'])) {
            $transaction_id = absint($_GET['transaction']);
            $transaction    = Axepta_BNPP_Transaction::get_by_id($transaction_id);

            $title = sprintf(
                __('Détails des données brutes - Transaction n° %d', 'axepta-bnp-paribas'),
                $transaction_id
            );

            if (
                isset($_GET['action']) &&
                $_GET['action'] === 'capture' &&
                check_admin_referer('axepta_capture_' . $transaction_id)
            ) {
                $this->capture_payment($transaction);

                wp_redirect(
                    remove_query_arg(
                        ['action', '_wpnonce'],
                        wp_get_referer() ?: admin_url('admin.php?page=axepta_bnpp_transactions')
                    )
                );
                exit;
            }

            include_once AXEPTA_BNPP_PLUGIN_PATH . 'views/html-axepta-bnpp-transaction.php';

        } else {
            $title        = __('Transactions', 'axepta-bnp-paribas');
            $transactions = Axepta_BNPP_Transaction::get_all();

            include_once AXEPTA_BNPP_PLUGIN_PATH . 'views/html-transactions.php';
        }
    }

    public function display_settings_errors() {
        settings_errors('axepta_messages');
        if ($messages = get_transient('axepta_messages_transient')) {
            foreach ($messages as $msg) {
                echo '<div class="notice notice-' . esc_attr($msg['type']) . ' is-dismissible"><p>' . esc_html($msg['message']) . '</p></div>';
            }
            delete_transient('axepta_messages_transient');
        }
    }

    private function capture_payment($transaction) {
        $order = wc_get_order($transaction->order_id);

        if ($order) {
            $result = Axepta_BNPP_Payment_Process::capture_payment(
                $transaction,
                $order->get_currency(),
                $order->get_billing_country()
            );

            if ($result['status'] === 'success') {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_success',
                    $result['message'],
                    'updated'
                );
                $this->store_message_transient($result['message'], 'success');
            } else {
                add_settings_error(
                    'axepta_messages',
                    'axepta_capture_failed',
                    $result['message'] . 'lll',
                    'error'
                );
                $this->store_message_transient($result['message'], 'error');
            }
        } else {
            add_settings_error(
                'axepta_messages',
                'axepta_order_not_found',
                __("Commande introuvable.", 'axepta-bnp-paribas'),
                'error'
            );
            $this->store_message_transient(__("Commande introuvable.", 'axepta-bnp-paribas'), 'error');
        }
    }

    private function store_message_transient($message, $type = 'success') {
        $messages = get_transient('axepta_messages_transient');
        if (!is_array($messages)) {
            $messages = [];
        }
        $messages[] = [
            'message' => $message,
            'type'    => $type === 'success' ? 'success' : 'error',
        ];
        set_transient('axepta_messages_transient', $messages, 60);
    }
}

new Axepta_BNPP_Admin_Transactions();