<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Axepta_BNPP_Subscription_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct([
            'singular' => __('Abonnement', 'axepta-bnp-paribas'),
            'plural'   => __('Abonnements', 'axepta-bnp-paribas'),
            'ajax'     => false,
        ]);
    }

    public function get_columns() {
        return [
            'cb' => '<input type="checkbox" />',
            'id_axepta_bnpp_customer_subscription_payment' => __('ID', 'axepta-bnp-paribas'),
            'id_order' => __('ID de commande', 'axepta-bnp-paribas'),
            'client' => __('Client', 'axepta-bnp-paribas'),
            'produit' => __('Produit', 'axepta-bnp-paribas'),
            'transaction_status' => __('Statut de transaction', 'axepta-bnp-paribas'),
            'periodicite' => __('Périodicité', 'axepta-bnp-paribas'),
            'last_schedule' => __('Dernière exécution', 'axepta-bnp-paribas'),
            'next_schedule' => __('Prochaine exécution', 'axepta-bnp-paribas'),
            'amount_tax_exclude' => __('Prix (€)', 'axepta-bnp-paribas'),
            'status_label' => __('Statut', 'axepta-bnp-paribas'),
            'actions' => __('Action', 'axepta-bnp-paribas'),
        ];
    }

    public function get_sortable_columns() {
        return [
            'id_axepta_bnpp_customer_subscription_payment' => ['id_axepta_bnpp_customer_subscription_payment', true],
            'id_order' => ['id_order', false],
            'amount_tax_exclude' => ['amount_tax_exclude', false],
            'status' => ['status', false],
            'last_schedule' => ['last_schedule', false],
            'next_schedule' => ['next_schedule', false],
        ];
    }

    public function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="subscription[]" value="%s" />',
            esc_attr($item->id_axepta_bnpp_customer_subscription_payment)
        );
    }

    public function column_actions($item) {
        $id = esc_attr($item->id_axepta_bnpp_customer_subscription_payment);
        $base_url = esc_url(admin_url('admin.php?page=' . $_REQUEST['page']));
    
        $html = '<select style="width:100%;" onchange="if(this.value) { window.location.href=this.value; }">';
        $html .= '<option value="">' . __('-- Sélectionner --', 'axepta-bnp-paribas') . '</option>';
        $html .= '<option value="' . $base_url . '&action=enable&subscription=' . $id . '">' . __('Activer', 'axepta-bnp-paribas') . '</option>';
        $html .= '<option value="' . $base_url . '&action=disable&subscription=' . $id . '">' . __('Désactiver', 'axepta-bnp-paribas') . '</option>';
        $html .= '<option value="' . $base_url . '&action=delete&subscription=' . $id . '" onclick="return confirm(\'' . esc_js(__('Êtes-vous sûr ?', 'axepta-bnp-paribas')) . '\')">' . __('Supprimer', 'axepta-bnp-paribas') . '</option>';
        $html .= '</select>';
    
        return $html;
    }

    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'client':
                return sprintf('#%d - %s', $item->id_customer, esc_html($item->customer_name));
            case 'produit':
                $product_url = get_edit_post_link($item->id_product);
                $name = esc_html($item->product_name);
                return sprintf('<a href="%s" target="_blank">#%d - %s</a>', esc_url($product_url), $item->id_product, $name);
            case 'transaction_status':
                return esc_html($item->status);
            case 'status_label':
                switch ((int)$item->status) {
                    case 0:
                        return __('Désactivé', 'axepta-bnp-paribas');
                    case 1:
                        return __('Actif', 'axepta-bnp-paribas');
                    case 2:
                        return __('Supprimé', 'axepta-bnp-paribas');
                    case 3:
                        return __('Erreur', 'axepta-bnp-paribas');
                    default:
                        return __('Inconnu', 'axepta-bnp-paribas');
                }
            case 'periodicite':
                return esc_html($item->number_periodicity . ' / ' . $item->periodicity);
            default:
                return isset($item->$column_name) ? esc_html($item->$column_name) : '';
        }
    }

    public function get_bulk_actions() {
        return [
            'enable' => __('Activer', 'axepta-bnp-paribas'),
            'disable' => __('Désactiver', 'axepta-bnp-paribas'),
            'delete' => __('Supprimer', 'axepta-bnp-paribas'),
        ];
    }

    public function extra_tablenav($which) {
        if ($which === 'top') {
            $selected_status = $_GET['filter_status'] ?? '';
            $selected_client = $_GET['filter_client'] ?? '';
    
            echo '<div class="alignleft actions">';
    
            // Filtre status
            echo '<select name="filter_status">';
            echo '<option value="">' . __('Tous les statuts', 'axepta-bnp-paribas') . '</option>';
            foreach ([1 => 'Actif', 0 => 'Désactivé', 2 => 'Supprimé', 3 => 'Erreur'] as $value => $label) {
                $selected = selected($selected_status, (string)$value, false);
                echo "<option value=\"$value\" $selected>" . esc_html__($label, 'axepta-bnp-paribas') . "</option>";
            }
            echo '</select>';
    
            // Filtre client
            echo '<input type="text" name="filter_client" placeholder="' . esc_attr__('ID client', 'axepta-bnp-paribas') . '" value="' . esc_attr($selected_client) . '" />';
    
            // Bouton filtrer
            submit_button(__('Filtrer', 'axepta-bnp-paribas'), 'button', false, false, ['id' => 'filter-submit']);
    
            echo '</div>';
        }
    }

    public function process_bulk_action() {
        if (empty($_POST['subscription'])) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';
        $ids = array_map('intval', $_POST['subscription']);

        switch ($this->current_action()) {
            case 'enable':
                $wpdb->query("UPDATE $table SET status = 1 WHERE id_axepta_bnpp_customer_subscription_payment IN (" . implode(',', $ids) . ")");
                break;
            case 'disable':
                $wpdb->query("UPDATE $table SET status = 0 WHERE id_axepta_bnpp_customer_subscription_payment IN (" . implode(',', $ids) . ")");
                break;
            case 'delete':
                $wpdb->query("UPDATE $table SET status = 2 WHERE id_axepta_bnpp_customer_subscription_payment IN (" . implode(',', $ids) . ")");
                break;
            default:
                break;
        }
    }

    public function prepare_items() {
        global $wpdb;
        $table = $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment';

        $per_page = 10;
        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;

        $this->process_bulk_action();

        $where = 'WHERE 1=1';
        $params = [];

        // Filtres
        if (!empty($_GET['filter_status']) && is_numeric($_GET['filter_status'])) {
            $where .= ' AND sub.status = %d';
            $params[] = (int) $_GET['filter_status'];
        }

        if (!empty($_GET['filter_client']) && is_numeric($_GET['filter_client'])) {
            $where .= ' AND sub.id_customer = %d';
            $params[] = (int) $_GET['filter_client'];
        }

        $orderby = in_array($_GET['orderby'] ?? '', ['id_order', 'status', 'last_schedule', 'amount_tax_exclude']) ? $_GET['orderby'] : 'last_schedule';
        $order = in_array(strtoupper($_GET['order'] ?? ''), ['ASC', 'DESC']) ? strtoupper($_GET['order']) : 'DESC';

        // Count total
        $count_query = "SELECT COUNT(*) FROM $table sub $where";
        $total_items = $wpdb->get_var($wpdb->prepare($count_query, ...$params));

        // Fetch items
        $query = "
            SELECT sub.*, 
                   p.post_title AS product_name,
                   u.display_name AS customer_name
            FROM {$table} AS sub
            LEFT JOIN {$wpdb->posts} AS p ON sub.id_product = p.ID
            LEFT JOIN {$wpdb->users} AS u ON sub.id_customer = u.ID
            $where
            ORDER BY {$orderby} {$order}
            LIMIT %d OFFSET %d
        ";

        $params[] = $per_page;
        $params[] = $offset;
        $this->items = $wpdb->get_results($wpdb->prepare($query, ...$params));

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);

        $this->_column_headers = [$this->get_columns(), [], $this->get_sortable_columns()];
    }
}
