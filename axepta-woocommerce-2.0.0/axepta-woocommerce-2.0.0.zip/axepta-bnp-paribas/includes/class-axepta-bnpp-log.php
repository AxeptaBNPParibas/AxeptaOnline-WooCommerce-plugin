<?php

if(!defined('ABSPATH'))exit;

final class Axepta_Bnpp_Log{

    #[\Override]
    protected static ?WC_Logger $logger=null;

    #[\Override]
    protected static string $source='axepta-bnpp';

    /**
     * Initializes the logger if not already loaded
     */
    protected static function init(): void {
        if(self::$logger===null){
            if(!class_exists('WC_Logger')){
                include_once WC()->plugin_path().'/includes/class-wc-logger.php';
            }
            self::$logger=new WC_Logger();
        }
    }

    /**
     * Write a log entry with a specific level
     */
    public static function log(string $level, string $message, array $context=[]): void {
        if($message === '') return;

        self::init();

        $allowed = ['error', 'warning', 'success', 'notice', 'info', 'debug', 'emergency','alert','critical'];
        $level = strtolower($level);
        $level = in_array($level, $allowed, true) ? $level : 'info';

        $context = self::sanitize_context($context);
        $entry = '['.strtoupper($level).'] '.$message;
        
		if(!empty($context)){
            $entry.=' '.json_encode($context,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        }

        self::$logger->log($level, $entry, ['source'=>self::$source]);
    }

    /**
     * Write an info log
     */
    public static function info(string $message, array $context=[]): void {
        self::log('info', $message, $context);
    }

    /**
     * Write a warning log
     */
    public static function warning(string $message, array $context=[]): void {
        self::log('warning', $message, $context);
    }

    /**
     * Write an error log
     */
    public static function error(string $message, array $context=[]): void {
        self::log('error', $message, $context);
    }

    /**
     * Write a debug log only if WP_DEBUG is enabled
     */
    public static function debug(string $message, array $context=[]): void {
        if(defined('WP_DEBUG')&&WP_DEBUG){
            self::log('debug', $message, $context);
        }
    }

    /**
     * Sanitize the context array recursively
     */
    protected static function sanitize_context(array $context): array {
        return array_map(function($value){
            if(is_array($value))return self::sanitize_context($value);
            if(is_scalar($value))return sanitize_text_field((string)$value);
            return '';
        }, $context);
    }
}
