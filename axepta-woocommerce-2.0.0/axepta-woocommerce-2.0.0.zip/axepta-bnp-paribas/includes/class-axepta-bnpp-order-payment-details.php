<?php
if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Order_Payment_Details 
{    
    public function __construct() {
        add_action('woocommerce_order_tabs', [$this, 'add_transaction_tab']);
        add_action('woocommerce_order_data_panels', [$this, 'transaction_tab_content']);
    }
    
    # Displays payment details in the billing section
    public static function display_payment_details($order) {
        if ($order->get_payment_method() !== 'axepta_bnpp_gateway') { 
            return; 
        }
        
        $transaction = Axepta_BNPP_Transaction::get_order_transaction($order->get_id());
        if (empty($transaction)) return;
        ?>
        
        <div class="address">
            <header class="title">
                <h3><?php _e('Détails de paiement Axepta', 'axepta-bnp-paribas'); ?></h3>
            </header>
            <div class="address-wrapper">
                <?php self::render_payment_details($transaction, true); ?>
            </div>
        </div>
        <?php
    }
    
    # Adds a transaction tab in the order page
    public static function add_transaction_tab($tabs) {
        global $post;

        if (!$post) {
            return $tabs;
        }
        
        $order = wc_get_order($post->ID);
        if ($order && $order->get_payment_method() === 'axepta_bnpp_gateway') {
            $tabs['axepta_transaction'] = [
                'label'    => __('Transaction Axepta', 'axepta-bnp-paribas'),
                'target'   => 'axepta_transaction_data',
                'class'    => ['show_if_axepta'],
                'priority' => 35,
            ];
        }
        
        return $tabs;
    }
    
    # Displays the content of the transaction tab
    public static function transaction_tab_content() {
        global $post;

        if (!$post) {
            return;
        }

        $order = wc_get_order($post->ID);
        $transaction = Axepta_BNPP_Transaction::get_order_transaction($order->get_id());

        if (empty($transaction)) {
            return;
        }

        ?>
        <div id="axepta_transaction_data" class="panel woocommerce_options_panel">
            <div class="options_group">
                <?php self::render_payment_details($transaction, true); ?>
            </div>
        </div>
        <?php
    }
    
    # Displays formatted payment details
    protected static function render_payment_details($transaction, $is_tab = false) {
        $status = $transaction['status'] ?? '';
        $status_label = self::get_status_labels()[$status] ?? $status;
        $card_type = $transaction['payment_mean_brand'] ?? '';
        $card_type_label = self::get_card_type_labels()[$card_type] ?? $card_type;
        $card_last4 = !empty($transaction['pcnr']) ? substr($transaction['pcnr'], -4) : '';
        $card_expiry = !empty($transaction['ccexpiry']) ? substr($transaction['ccexpiry'], 0, 2) . '/' . substr($transaction['ccexpiry'], 2, 2) : '';

        $details = [
            'transaction_id' => [
                'label' => __('ID Transaction', 'axepta-bnp-paribas'),
                'value' => $transaction['transaction_reference'] ?? 'N/A',
                'class' => 'transaction-id',
            ],
            'status' => [
                'label' => __('Statut', 'axepta-bnp-paribas'),
                'value' => $status,
                'class' => 'status status-' . strtolower($status),
            ],
            'amount' => [
                'label' => __('Montant', 'axepta-bnp-paribas'),
                'value' => wc_price($transaction['amount'] ?? 0),
                'class' => 'amount',
            ],
            'date' => [
                'label' => __('Date', 'axepta-bnp-paribas'),
                'value' => date_i18n('d/m/Y H:i', strtotime($transaction['transaction_date'])),
                'class' => 'date',
            ],
        ];
        
        # Add card details if available
        if (!empty($card_type) || !empty($card_last4)) {
            $card_details = [
                'card_type' => [
                    'label' => __('Type de carte', 'axepta-bnp-paribas'),
                    'value' => $card_type_label,
                    'class' => 'card-type',
                ],
                'card_last4' => [
                    'label' => __('Derniers 4 chiffres', 'axepta-bnp-paribas'),
                    'value' => $card_last4 ? '•••• •••• •••• ' . $card_last4 : 'N/A',
                    'class' => 'card-last4',
                ],
            ];
            
            if (!empty($card_expiry)) {
                $card_details['card_expiry'] = [
                    'label' => __('Date d\'expiration', 'axepta-bnp-paribas'),
                    'value' => $card_expiry,
                    'class' => 'card-expiry',
                ];
            }
            
            $details = array_merge($details, $card_details);
        }
        
        # Display the details in the appropriate format
        if ($is_tab) {
            echo '<table class="wc-order-data-wide wc-order-totals"  style="margin-top: 0; border-spacing: 20px;"><tbody>';
            
            foreach ($details as $key => $detail) {
                echo '<tr>';
                echo '<td class="label">' . esc_html($detail['label']) . ':</td>';
                echo '<td class="' . esc_attr($detail['class']) . '">' . $detail['value'] . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
            
            # Button to see more details (optional)
            if (!empty($transaction['raw_data'])) {
                $raw_data = maybe_unserialize($transaction['raw_data']);
                if (is_array($raw_data)) {
                    echo '<div class="axepta-raw-data" style="margin-top: 20px; padding: 10px; background: #f8f8f8; border: 1px solid #ddd;">';
                    echo '<h4>' . __('Détails techniques', 'axepta-bnp-paribas') . '</h4>';
                    echo '<pre style="max-height: 200px; overflow: auto;">';
                    echo esc_html(print_r($raw_data, true));
                    echo '</pre>';
                    echo '</div>';
                }
            }
        } else {
            # Format for the billing section
            echo '<p>';
            
            $output = [];
            foreach ($details as $key => $detail) {
                if (in_array($key, ['transaction_id', 'status', 'amount'])) {
                    $output[] = '<strong>' . esc_html($detail['label']) . ':</strong> <span class="' . esc_attr($detail['class']) . '">' . $detail['value'] . '</span>';
                }
            }
            
            echo implode('<br>', $output);
            echo '</p>';
            
            # Link to see more details
            echo '<p><a href="' . admin_url('post.php?post=' . $transaction['order_id'] . '&action=edit#axepta_transaction_data') . '" class="button button-small">';
            _e('Voir les détails de la transaction', 'axepta-bnp-paribas');
            echo '</a></p>';
        }
    }

    # Returns a map of Axepta transaction statuses to readable labels
    protected static function get_status_labels() {
        return [
            'AUTHORISED' => __('Autorisé', 'axepta-bnp-paribas'),
            'AUTHORIZED' => __('Autorisé', 'axepta-bnp-paribas'),
            'PENDING' => __('En attente', 'axepta-bnp-paribas'),
            'FAILED' => __('Echoué', 'axepta-bnp-paribas'),
            'CANCELLED' => __('Annulé', 'axepta-bnp-paribas'),
            'REFUNDED' => __('Remboursé', 'axepta-bnp-paribas'),
            'APPROUVED' => __('Approuvé', 'axepta-bnp-paribas')
        ];
    }
    
    # Returns a map of Axepta card types to readable labels
    protected static function get_card_type_labels() {
        return [
            'VISA' => __('Visa', 'axepta-bnp-paribas'),
            'MASTERCARD' => __('Mastercard', 'axepta-bnp-paribas'),
            'CB' => __('Carte Bancaire', 'axepta-bnp-paribas'),
            'AMEX' => __('American Express', 'axepta-bnp-paribas'),
            'MAESTRO' => __('Maestro', 'axepta-bnp-paribas'),
        ];
    }
}

# Initialize payment details display
new Axepta_BNPP_Order_Payment_Details();