<?php

if (!defined('ABSPATH')) exit;

class Axepta_BNPP_OneClick {

    # save card
    public static function save_card($user_id, $token, $cc_expiry, $cc_brand) {
        global $wpdb;
        return self::insert_card([
            'customer_id' => $user_id,
            'pcnr' => $token,
            'ccexpiry' => $cc_expiry,
            'ccbrand' => $cc_brand,
        ]);
    }

    # insert card
    public static function insert_card(array $data) {
        global $wpdb;

        $wpdb->insert(
            "{$wpdb->prefix}axepta_bnpp_customer_saved_card",
            $data,
        );
        if($wpdb->insert_id) {
            Axepta_Bnpp_Log::info(__('Card saved successfully', 'axepta-bnp-paribas'), ['user_id' => $data['customer_id']]);
            return true;
        }
        return false;
    }

    # update card
    private static function update_card($user_id, $token, $cc_expiry, $cc_brand) {
        global $wpdb;

        $updated = $wpdb->update(
            "{$wpdb->prefix}axepta_bnpp_customer_saved_card",
            [
                'pcnr' => $token,
                'ccexpiry' => $cc_expiry,
                'ccbrand' => $cc_brand,
            ],
            ['customer_id' => $user_id]
        );

        if($updated !== false) {
            Axepta_Bnpp_Log::info(__('Card updated successfully', 'axepta-bnp-paribas'), ['user_id' => $user_id]);
            return true;
        }
        return false;
    }

    # get card by user id
    public static function get_card($user_id) {
        global $wpdb;

        $card = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_saved_card WHERE customer_id = %d LIMIT 1", 
                $user_id
            )
        );

        return $card ? $card : null;
    }

    # get cards by user id
    public static function get_user_cards($user_id) {
        global $wpdb;

        $cards = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_saved_card WHERE customer_id = %d", 
                $user_id
            )
        );

        return $cards;
    }
    
    # delete all cards
    public static function delete_all_cards() {
        global $wpdb;

        $deleted = $wpdb->query(
            "DELETE FROM {$wpdb->prefix}axepta_bnpp_customer_saved_card"
        );

        if($deleted !== false) {
            Axepta_Bnpp_Log::info(__('All cards deleted successfully', 'axepta-bnp-paribas'));
            return true;
        }
        Axepta_Bnpp_Log::error(__('Failed to delete all cards', 'axepta-bnp-paribas'));
        return false;
    }

    # get card by card id
    public static function get_card_by_id($card_id) {
        global $wpdb;

        $card = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}axepta_bnpp_customer_saved_card WHERE id = %d LIMIT 1",
                $card_id
            )
        );

        return $card ? $card : null;
    }

    # delete user id card
    public static function delete_user_card($user_id, $card_id) {
        global $wpdb;

        $deleted = $wpdb->delete(
            "{$wpdb->prefix}axepta_bnpp_customer_saved_card",
            ['customer_id' => $user_id, 'id' => $card_id]
        );

        if($deleted !== false) {
            Axepta_Bnpp_Log::info(__('Card deleted successfully', 'axepta-bnp-paribas'), ['user_id' => $user_id]);
            return true;
        }
        return false;
    }

    # delete user id card
    public static function delete_card($user_id) {
        global $wpdb;

        $deleted = $wpdb->delete(
            "{$wpdb->prefix}axepta_bnpp_customer_saved_card",
            ['customer_id' => $user_id]
        );

        if($deleted !== false) {
            Axepta_Bnpp_Log::info(__('Card deleted successfully', 'axepta-bnp-paribas'), ['user_id' => $user_id]);
            return true;
        }
        return false;
    }
}
