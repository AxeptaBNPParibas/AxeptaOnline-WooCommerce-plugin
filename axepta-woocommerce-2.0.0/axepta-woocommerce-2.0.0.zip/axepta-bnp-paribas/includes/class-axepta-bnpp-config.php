<?php

if (!defined('ABSPATH')) {
    exit;
}

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Exception\ApiCallException;

class Axepta_BNPP_Config
{
    public function __construct()
    {
        add_action('wp_ajax_axepta_send_support_form',  [$this, 'handle_support_form']);
        add_action('wp_ajax_axepta_verify_merchant_setup',  [$this, 'handle_verify_merchant_setup']);
        add_action('wp_ajax_axepta_download_logs',  [$this, 'handle_download_logs']);

        if(get_option('axepta_settings')['axepta_oneclick_enabled'] && get_option('axepta_settings')['axepta_oneclick_enabled'] === '1') {
            add_action('wp_ajax_axepta_delete_tokens',  [$this, 'handle_delete_tokens']);
        }

        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_axepta_bnpp', [$this, 'render_settings_page']);
        add_action('woocommerce_update_options_axepta_bnpp', [$this, 'save_account_settings']);
        
        add_action('admin_notices', [$this, 'maybe_display_notice']);
    }

    public function add_settings_tab($settings_tabs)
    {
        $settings_tabs['axepta_bnpp'] = __('Axepta BNP Paribas 2.0', 'axepta-bnp-paribas');
        return $settings_tabs;
    }

    public function save_account_settings() 
    {
        $response = $this->validate_settings_fields();
        
        update_option('axepta_settings', $response['data']);
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }

        $hasValidToken = $this->getToken()['success'];
        
        if($response['success'] && $hasValidToken === true) {
            update_option('axepta_success_notice', true);
            wp_redirect(admin_url('admin.php?page=wc-settings&tab=axepta_bnpp'));
            exit;
        } elseif($response['success'] && $hasValidToken !== true) {
            WC_Admin_Settings::add_error(__('API Key ou MID invalide. Veuillez vérifier vos identifiants.', 'axepta-bnp-paribas'));
            return;
        } else {
            return;
        }
    }

    public function validate_settings_fields() 
    {
        $validated = [];
        $errors = [];

        // verify true form submitted
        if (!isset($_POST['axepta_custom_form_submitted'])) {
            WC_Admin_Settings::add_error(__('Formulaire non soumis correctement.', 'axepta-bnp-paribas'));
            return;
        }
        
        // verify_nonce
        if (!isset($_POST['axepta_custom_settings_nonce']) || !wp_verify_nonce($_POST['axepta_custom_settings_nonce'], 'axepta_custom_settings_nonce')) {
            WC_Admin_Settings::add_error(__('Erreur de sécurité. Veuillez réessayer.', 'axepta-bnp-paribas'));
            return;
        }

        $this->validate_account_access($validated, $errors);
        $validated['axepta_enabled'] = isset($_POST['axepta_enabled']) ? '1' : '0';

        $this->validate_payment_methods($validated, $errors);
        $this->handle_switches($validated, 'cart', 'saller', 'delivery', 'billing');
        $this->handle_custom_fields($validated, $errors);

        // One Click
        $validated['axepta_oneclick_enabled'] = isset($_POST['axepta_oneclick_enabled']) ? '1' : '0';
        $this->validate_3ds_exemption($validated, $errors);

        $this->validate_capture_mode($validated, $errors);
        $this->validate_subscription($validated);
        $this->persis_smtp($validated);

        $settings = get_option('axepta_settings', []);
        $merged = array_merge($settings, $validated);

        if (!empty($errors)) {
            WC_Admin_Settings::add_error(__('Erreur de validation des paramètres Axepta.', 'axepta-bnp-paribas'));
            foreach ($errors as $error) {
                WC_Admin_Settings::add_error(__($error, 'axepta-bnp-paribas'));
            }
            return ['success' => false, 'data' => $merged];
        }

        return ['success' => true, 'data' => $merged];
    }

    private function validate_account_access(&$validated, &$errors) {
        if (isset($_POST['axepta_mode'])) {
            $mode = sanitize_text_field($_POST['axepta_mode']);
            if (in_array($mode, ['demo', 'test', 'production'])) {
                $validated['axepta_mode'] = $mode;
            } else {
                $errors[] = __('Mode invalide sélectionné.', 'axepta-bnp-paribas');
            }
        }

        switch ($_POST['axepta_mode'] ?? '') {
            case 'test':
                $this->validate_field('axepta_test_key', 'La clé de test est obligatoire en mode test.', $validated, $errors);
                $this->validate_field('axepta_test_merchant_id', 'Le marchand ID est obligatoire en mode test.', $validated, $errors);
                break;
            case 'production':
                $this->validate_field('axepta_private_key', 'La clé privée est obligatoire en mode production.', $validated, $errors);
                $this->validate_field('axepta_merchant_id', 'Le marchand ID est obligatoire en mode production.', $validated, $errors);
                break;
            default:
                break;
        }
    }

    private function validate_payment_methods(&$validated, &$errors) {
        if (!isset($_POST['axepta_payment_layout']) || !in_array($_POST['axepta_payment_layout'], ['hpp', 'regroupe'])) {
            $errors[] = __('Organisation des moyens de paiement invalide.', 'axepta-bnp-paribas');
        } else {
            $validated['axepta_payment_layout'] = sanitize_text_field($_POST['axepta_payment_layout']);
            $validated['axepta_payment_label'] = !empty($_POST['axepta_payment_label']) ? stripslashes(sanitize_text_field($_POST['axepta_payment_label'])) : __('Paiement par carte bancaire', 'axepta-bnp-paribas');
            $validated['axepta_display_mode'] = !empty($_POST['axepta_display_mode']) ? sanitize_text_field($_POST['axepta_display_mode']) : 'redirect';

            if ($validated['axepta_payment_layout'] === 'regroupe') {
                $payment_methods = ['cb', 'vim', 'amex', 'payPal', 'applePay', 'gpay'];
                $at_least_one_checked = false;
                foreach ($payment_methods as $method) {
                    $field = 'axepta_payment_' . $method;
                    if (!empty($_POST[$field])) {
                        $validated['axepta_payment_methods'][$method] = '1';
                        $at_least_one_checked = true;
                    }
                }
                if (!$at_least_one_checked) {
                    $errors[] = __('Au moins un moyen de paiement doit être sélectionné en mode "regroupé".', 'axepta-bnp-paribas');
                }
            }
        }
    }

    private function validate_3ds_exemption(&$validated, &$errors) {
        $validated['axepta_3ds_exemption'] = isset($_POST['axepta_3ds_exemption']) ? '1' : '0';
        if ($validated['axepta_3ds_exemption'] === '1' && isset($_POST['axepta_3ds_exemption_max'])) {
            if (absint($_POST['axepta_3ds_exemption_max']) <= 0) {
                $errors[] = __("Le montant d'exemption 3DS est invalide.", 'axepta-bnp-paribas');
            } else {
                $validated['axepta_3ds_exemption_max'] = absint($_POST['axepta_3ds_exemption_max']);
            }
        }
    }

    private function validate_capture_mode(&$validated, &$errors) {
        if (!isset($_POST['axepta_capture_mode']) || !in_array($_POST['axepta_capture_mode'], ['auto', 'manuel', 'deferred'])) {
            $errors[] = __('Mode de capture invalide.', 'axepta-bnp-paribas');
        } else {
            $validated['axepta_capture_mode'] = sanitize_text_field($_POST['axepta_capture_mode']);

            $this->validate_manual_capture_notify($validated, $errors);

            $this->validate_capture_hours($validated, $errors);
        }
    }

    private function validate_manual_capture_notify(&$validated, &$errors) {
        $validated['axepta_manual_capture_notify'] = isset($_POST['axepta_manual_capture_notify']) ? '1' : '0';
        if ($validated['axepta_manual_capture_notify'] === '1') {
            if (!is_email(sanitize_email($_POST['axepta_manual_capture_email'])) || empty($_POST['axepta_manual_capture_email'])) {
                $errors[] = __("Veuillez fournir une adresse email valide pour les notifications de capture manuelle.", 'axepta-bnp-paribas');
            } else {
                $validated['axepta_manual_capture_email'] = sanitize_email($_POST['axepta_manual_capture_email']);
            }
        }
    }

    private function validate_capture_hours(&$validated, &$errors) {
        if ($_POST['axepta_capture_mode'] === "deferred" && isset($_POST['axepta_capture_hours'])) {
            if ($_POST['axepta_capture_hours'] >= 1 && $_POST['axepta_capture_hours'] <= 696) {
                $validated['axepta_capture_hours'] = $_POST['axepta_capture_hours'];
            } else {
                $errors[] = __("La durée de capture doit être comprise entre 1 et 696 heures.", 'axepta-bnp-paribas');
            }
        }
    }

    private function validate_subscription(&$validated) {
        $validated['axepta_subscription_enabled'] = isset($_POST['axepta_subscription_enabled']) ? '1' : '0';
        $validated['axepta_subscription_label'] = isset($_POST['axepta_subscription_label']) ? sanitize_text_field($_POST['axepta_subscription_label']) : '';
        $validated['axepta_subscription_customer_can_suspend'] = isset($_POST['axepta_subscription_customer_can_suspend']) ? '1' : '0';
    }

    private function validate_smtp(&$validated, &$errors) {
        $this->validate_field('axepta_smtp_host', "L'hôte SMTP est obligatoire.", $validated, $errors);
        $this->validate_field('axepta_smtp_password', "Le mot de passe SMTP est obligatoire.", $validated, $errors);
        $this->validate_field('axepta_smtp_user', "Le nom d'utilisateur SMTP est obligatoire en mode production.", $validated, $errors);
    }

    public function persis_smtp(&$validated) {
        $this->persist_smtp_field('axepta_smtp_host', $validated);
        $this->persist_smtp_field('axepta_smtp_password', $validated);
        $this->persist_smtp_field('axepta_smtp_user', $validated);
    }

    public function persist_smtp_field($field, &$validated) {
        if (isset($_POST[$field]) && !empty($_POST[$field])) {
            $validated[$field] = sanitize_text_field($_POST[$field]);
        } else {
            $settings = get_option('axepta_settings', []);
            $validated[$field] = $settings[$field] ?? '';
        }
    }

    private function validate_field($field, $message, &$validated, &$errors) {
        if (empty($_POST[$field])) {
            $errors[] = __($message, 'axepta-bnp-paribas');
        } else {
            $validated[$field] = sanitize_text_field($_POST[$field]);
        }
    }

    private function handle_switches(&$validated, ...$switches) {
        foreach ($switches as $key) {
            $field_id = "axepta_display_$key";
            $validated[$field_id] = !isset($_POST[$field_id]) ? '0' : '1';
        }
    }

    private function handle_custom_fields(&$validated, &$errors) {
        $custom_fields = [
            'logo'  => 'axepta_custom_logo_url',
            'title' => 'axepta_custom_title',
            'text'  => 'axepta_custom_text',
        ];

        foreach ($custom_fields as $key => $custom_field) {
            $switch_id = "axepta_display_$key";
            $custom_value = isset($_POST[$custom_field]) ? stripslashes(sanitize_text_field($_POST[$custom_field])) : '';

            if (!empty($custom_value)) {
                $validated[$custom_field] = $custom_value;
                $validated[$switch_id] = '1';
            } else {
                $validated[$switch_id] = '0';
            }
        }
    }


    public function enqueue_assets($hook)
    {
        $screen = get_current_screen();
        $isWooAxeptaTab = $screen && $screen->id === 'woocommerce_page_wc-settings' && isset($_GET['tab']) && $_GET['tab'] === 'axepta_bnpp';

        if ($hook !== 'toplevel_page_axepta-settings' && !$isWooAxeptaTab) {
            return;
        }

        wp_enqueue_style('axepta-admin-style', plugin_dir_url(__DIR__) . 'assets/css/style.css');
        wp_enqueue_script('axepta-admin-js', plugin_dir_url(__DIR__) . 'assets/js/admin.js', ['jquery'], null, true);
    }

    public function render_settings_page()
    {
        include plugin_dir_path(__DIR__) . 'views/html-landing-page.php';
    }

    public function handle_support_form()
    {
        $errors = [];
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $message = stripslashes(sanitize_textarea_field($_POST['message'] ?? ''));

        if (empty($name)) {
            $errors[] = __('Le nom est requis.', 'axepta-bnp-paribas');
        }
        if (empty($email) || !is_email($email)) {
            $errors[] = __('Un email valide est requis.', 'axepta-bnp-paribas');
        }
        if (empty($message)) {
            $errors[] = __('Le message est requis.', 'axepta-bnp-paribas');
        }

        $file_url = '';
        if (!empty($_FILES['fichier']['name'])) {
            $allowed_types = ['image/png', 'image/jpeg', 'application/pdf', 
                'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            ];
            $uploaded = wp_handle_upload($_FILES['fichier'], ['test_form' => false]);
            if (isset($uploaded['error'])) {
                wp_send_json_error(__('L\'envoi a échoué car ', 'axepta-bnp-paribas') . esc_html($uploaded['error']));
                $errors[] = __('Erreur lors de l\'upload du fichier : ', 'axepta-bnp-paribas') . esc_html($uploaded['error']);
            } elseif (!in_array($_FILES['fichier']['type'], $allowed_types)) {
                wp_send_json_error(__('Type de fichier non autorisé.', 'axepta-bnp-paribas'));
                $errors[] = __('Type de fichier non autorisé.', 'axepta-bnp-paribas');
            } else {
                $file_url = $uploaded['url'];
            }
        }

        if (empty($errors)) {
            $to = "assistance.ecommerce@bnpparibas.com";
            $subject = __('Support Axepta BNP Paribas - ', 'axepta-bnp-paribas') . $name;
            $body = $this->render_support_email_body($name, $email, $message, $file_url);

            $headers = [
                "Reply-To: {$name} <{$email}>",
                "Content-Type: text/html; charset=UTF-8"
            ];

            // join file
            $attachments = [];
            if ($file_url) {
                $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $file_url);
                if (file_exists($file_path)) {
                    $attachments[] = $file_path;
                } else {
                    wp_send_json_error(__('L\'attachement du fichier a échoué', 'axepta-bnp-paribas'));
                }
            }

            wp_mail($to, $subject, $body, $headers, $attachments);
            wp_send_json_success();
        } else {
            foreach ($errors as $err) {
                WC_Admin_Settings::add_error(__($err, 'axepta-bnp-paribas'));
            }
            wp_send_json_error(__('L\'envoi a échoué', 'axepta-bnp-paribas'));
        }
    }

    public function render_support_email_body(string $name, string $email, string $message, ?string $file_url=null)
    {
        $merchant_id = Axepta_BNPP_Helper::getMerchantId();
        $api_key = Axepta_BNPP_Helper::getApiKey();
        $mode = Axepta_BNPP_Helper::getPaymentMode();
        $key_status = $this->getToken()['success'] ? "OK" : "KO";
        $current_version = AXEPTA_BNPP_VERSION;
        
        $body = "
            <div>
                <h3>Demande de support Axepta</h3>
                <p><strong>Boutique :</strong> " . get_bloginfo('name') . "</p>
                <p><strong>ID Marchand :</strong> {$merchant_id}</p>
                <p><strong>URL de la boutique :</strong> " . get_site_url() . "</p><br>

                <p><strong>Nom :</strong> {$name}</p>
                <p><strong>Email :</strong> {$email}</p>
                <p><strong>Problème rencontré :</strong><br>{$message}</p><br>

                <p><strong>Module :</strong> Axepta BNP Paribas</p>
                <p><strong>Version Module :</strong> {$current_version}</p>
                <p><strong>CMS :</strong> WooCommerce</p>
                <p><strong>Version CMS :</strong> " . get_bloginfo('version') . "</p>
                <p><strong>Version PHP :</strong> " . phpversion() . "</p>
                <p><strong>Format clé API :</strong> {$key_status}</p><br>";
        $body .= $file_url ? "<p><strong>Fichier attaché :</strong> Oui (voir PJ) </p>" : "<p><strong>Fichier attaché :</strong> Non </p>";
        $body .= "</div>";
        return $body;
    }

    public function handle_delete_tokens() {
        Axepta_BNPP_OneClick::delete_all_cards();
        $tokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id(), 'axepta_bnpp_gateway');
        foreach ($tokens as $token) {
            $token->delete();
        }

        wp_send_json_success(__('Tous les jetons ont été supprimés avec succès.', 'axepta-bnp-paribas'));
    }

    public function handle_verify_merchant_setup() {
        $result = $this->getToken();
        $result['success'] ? wp_send_json_success($result['data']) 
            : wp_send_json_error(__('Erreur lors de la récupération du token : ', 'axepta-bnp-paribas') . $result['data']);
    }

    public function handle_download_logs() {
        check_ajax_referer('axepta_download_logs', 'nonce');

        $logs_directory = defined('WC_LOG_DIR') ? WC_LOG_DIR : WP_CONTENT_DIR . '/wc-logs/';
        $log_files = glob($logs_directory . 'axepta-bnpp-*.log');

        if (empty($log_files)) {
            wp_send_json_error([
                'notice' => $this->get_wp_notice(
                    __('Aucun fichier de log trouvé.', 'axepta-bnp-paribas'),
                    'error'
                )
            ]);
        }

        $current_month = date('Y-m');
        $month_files = array_filter($log_files, function($file) use ($current_month) {
            return strpos(basename($file), $current_month) !== false;
        });

        if (empty($month_files)) {
            $month_files = $log_files;
        }

        usort($month_files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });

        $combined_content = "";
        foreach ($month_files as $file) {
            if (is_readable($file)) {
                $content = @file_get_contents($file);
                if ($content !== false) {
                    $combined_content .= "\n=== " . basename($file) . " ===\n";
                    $combined_content .= $content . "\n\n";
                }
            }
        }

        if (empty($combined_content)) {
            wp_send_json_error([
                'notice' => $this->get_wp_notice(
                    __('Impossible de lire les fichiers de log.', 'axepta-bnp-paribas'),
                    'warning'
                )
            ]);
        }

        wp_send_json_success([
            'filename' => 'axepta-bnpp-logs-' . date('Y-m') . '.log',
            'content'  => base64_encode($combined_content),
            'notice'   => $this->get_wp_notice(
                __('Fichier de log téléchargé avec succès.', 'axepta-bnp-paribas'),
                'success'
            )
        ]);
    }

    private function get_wp_notice($message, $type = 'success') {
        $classes = 'notice notice-' . $type . ' is-dismissible';
        return '<div class="' . esc_attr($classes) . '">
            <p>' . wp_kses_post($message) . '</p>
            <button type="button" class="notice-dismiss">
                <span class="screen-reader-text">' . __('Ignorer cette notice.', 'axepta-bnp-paribas') . '</span>
            </button>
        </div>';
    }

    public function maybe_display_notice()
    {
        if (get_option('axepta_success_notice')) {
            echo '<div class="notice notice-success is-dismissible">
                    <p>' . esc_html__('Les paramètres ont été enregistrés avec succès.', 'axepta-bnp-paribas') . '</p>
                </div>';

            delete_option('axepta_success_notice');
        }
    }

    private function getToken() {
        $merchantId = Axepta_BNPP_Helper::getMerchantId();
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $mode = Axepta_BNPP_Helper::getPaymentMode();
        try {
            $tokenData = AxeptaPaygate::getAccessToken($merchantId, $apiKey, $mode);
            return ['success' => true, 'data' => $tokenData];
        } catch (ApiCallException $e) {
            return ['success' => false, 'data' => $e->getMessage()];
        }
    }
}

new Axepta_BNPP_Config();