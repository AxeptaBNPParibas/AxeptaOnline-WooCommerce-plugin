<?php

if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Order_Cleaner {

    const CRON_HOOK = 'axepta_bnpp_clean_pending_orders';
    const CHECK_CAPTURE_STATUS_CRON_HOOK = 'axepta_bnpp_cron_check_capture_status';
    const PENDING_ORDER_EXPIRY_HOURS = 24;
    
    public function __construct() {
        add_action('init', [$this, 'schedule_cron']);
        add_action(self::CRON_HOOK, [$this, 'clean_pending_orders']);
        add_action(self::CHECK_CAPTURE_STATUS_CRON_HOOK, [$this, 'axepta_check_capture_status']);
        register_deactivation_hook(plugin_basename(dirname(__DIR__) . '/axepta-bnp-paribas.php'), [$this, 'clear_schedule']);
    }

    # Schedule custom cron hook
    public function schedule_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
            Axepta_Bnpp_Log::info(__('Planification du cron pour nettoyer les commandes en attente', 'axepta-bnp-paribas'));
        }

        if (!wp_next_scheduled(self::CHECK_CAPTURE_STATUS_CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CHECK_CAPTURE_STATUS_CRON_HOOK);
            Axepta_Bnpp_Log::info(__('Notification cron planification', 'axepta-bnp-paribas'));
        }
    }
    
    # Clean up custom cron hook on plugin deactivation
    public function clear_schedule() {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }

        $timestamp = wp_next_scheduled(self::CHECK_CAPTURE_STATUS_CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CHECK_CAPTURE_STATUS_CRON_HOOK);
        }
    }
    
    # Clean pending orders older than 24h
    public function clean_pending_orders() {
        global $wpdb;
        
        $expiry_date = date('Y-m-d H:i:s', strtotime('-' . self::PENDING_ORDER_EXPIRY_HOURS . ' hours'));
        
        $orders = wc_get_orders([
            'status'        => 'wc-pending',
            'payment_method' => 'axepta_bnpp_gateway',
            'date_modified' => '<' . $expiry_date,
            'limit'         => 50,
            'return'        => 'ids',
        ]);
        
        if (empty($orders)) {
            Axepta_Bnpp_Log::info(__('Aucune commande en attente à nettoyer', 'axepta-bnp-paribas'));
            return;
        }
        
        $cancelled_count = 0;
        
        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            
            if (!$order) {
                continue;
            }
            
            try {
                $order_date = $order->get_date_modified() ? $order->get_date_modified()->date('Y-m-d H:i:s') : $order->get_date_created()->date('Y-m-d H:i:s');
                
                if (strtotime($order_date) < strtotime($expiry_date)) {
                    $order->update_status('cancelled', __('Commande annulée automatiquement - Paiement non reçu au-delà du délai', 'axepta-bnp-paribas'));
                    
                    $order->add_order_note(
                        sprintf(
                            __('Commande annulée automatiquement après %d heures sans confirmation du paiement.', 'axepta-bnp-paribas'),
                            self::PENDING_ORDER_EXPIRY_HOURS
                        )
                    );
                    
                    # Restore stock if necessary
                    if (get_option('woocommerce_manage_stock') === 'yes') {
                        wc_increase_stock_levels($order_id);
                    }
                    
                    $cancelled_count++;
                    
                    Axepta_Bnpp_Log::info(__('Commande #$order_id annulée automatiquement (en attente depuis plus de ' . self::PENDING_ORDER_EXPIRY_HOURS . 'h)', 'axepta-bnp-paribas'), [
                        'order_id' => $order_id,
                        'order_date' => $order_date,
                        'expiry_date' => $expiry_date
                    ]);
                }
            } catch (Exception $e) {
                Axepta_Bnpp_Log::error(__('Erreur lors de l\'annulation automatique de la commande #$order_id', 'axepta-bnp-paribas'), [
                    'error' => $e->getMessage(),
                    'order_id' => $order_id
                ]);
            }
        }
        
        if ($cancelled_count > 0) {
            Axepta_Bnpp_Log::info(__('Commande annulée automatiquement', 'axepta-bnp-paribas'), [
                'cancelled_count' => $cancelled_count
            ]);
        }
    }

    public function axepta_check_capture_status() {
        $args = [
            'status' => ['wc-pending', 'wc-processing', Axepta_BNPP_Constant::full(Axepta_BNPP_Constant::CAPTURE_PENDING)],
            'payment_method' => 'axepta_bnpp_gateway',
            'meta_key' => '_capture_status',
            'meta_value' => 'Non capturé',
        ];
        $orders = wc_get_orders($args);

        foreach ($orders as $order) {
            $order_date = strtotime($order->get_date_created());
            $days_since_order = (time() - $order_date) / (60 * 60 * 24);

            if ($days_since_order >= 7 && !get_post_meta($order->get_id(), '_axepta_notification_7_days_sent', true)) {
                $this->axepta_send_email($order, 7);
            }

            if ($days_since_order >= 28 && !get_post_meta($order->get_id(), '_axepta_notification_28_days_sent', true)) {
                $this->axepta_send_email($order, 28);
            }
        }
    }

    // Sending a notification email (7 days or 28 days)
    private function axepta_send_email($order, $days_since_order) {
        $subject = '';
        $message = '';
        $emails_to_notify = get_option('axepta_settings', [])['axepta_manual_capture_email'] ?? '';

        if ($days_since_order == 6) {
            $subject = __('Capture manuelle expirée pour la commande', 'axepta-bnp-paribas');
            $message = sprintf(__('La commande #%s a dépassé 7 jours sans capture manuelle. L\'authentification expire.', 'axepta-bnp-paribas'), $order->get_order_number());
        }

        if ($days_since_order == 28) {
            $subject = __('Autorisation expirée pour la commande', 'axepta-bnp-paribas');
            $message = sprintf(__('La commande #%s a dépassé 28 jours sans capture manuelle. L\'autorisation expire.', 'axepta-bnp-paribas'), $order->get_order_number());
        }

        // send
        if (!empty($emails_to_notify)) {
            $emails = array_map('trim', explode(',', $emails_to_notify));

            wp_mail($emails, $subject, $message);
            update_post_meta($order->get_id(), '_axepta_notification_' . $days_since_order . '_days_sent', true);
        }
    }
}

new Axepta_BNPP_Order_Cleaner();
