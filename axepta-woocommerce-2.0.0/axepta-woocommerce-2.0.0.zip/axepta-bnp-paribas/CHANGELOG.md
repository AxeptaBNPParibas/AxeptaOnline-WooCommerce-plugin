# CHANGELOG

## [2.0.0] - 2025-11-06
### Added
- Refonte complète du plugin Axepta BNP Paribas...
- Support des paiements par carte bancaire, PayPal, Apple Pay, Google Pay.
- Mode de paiement (demo, test, prod).
- Système de traduction intégré.

### Changed
- Nouvelle gestion des API pour les transactions réelles.
- Optimisation de la page de configuration.

## [1.0.0] - 2024-06-01
### Added
- Première version du plugin Axepta BNP Paribas.
- Paiement par carte (CB, Visa, MasterCard, Amex).
- Configuration de base avec mode test et production.
