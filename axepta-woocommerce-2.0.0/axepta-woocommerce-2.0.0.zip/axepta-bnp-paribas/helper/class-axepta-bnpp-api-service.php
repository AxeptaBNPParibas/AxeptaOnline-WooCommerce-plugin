<?php

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Exception\ApiCallException;
use AxeptaPaygate\Exception\AxeptaPaygateException;

class Axepta_Bnpp_Api_Service
{
    public function buildOperation($isRecurringPaymentInit, $trigram, $merchantId, $apiKey, $paymentData, $paymentMode = 'REDIRECT', $idOrder = 0)
    {
        [$prefilledConfiguration, $missingConfigurationKeys] = $this->getParamsByTrigram($trigram, $paymentMode, isset($paymentData['axeptaMethodData']) ? $paymentData['axeptaMethodData']['isOneClick'] : 0, isset($paymentData['axeptaMethodData']) && isset($paymentData['axeptaMethodData']['recurringSchedule']) ? $paymentData['axeptaMethodData']['recurringSchedule'] : 0);

        foreach ($missingConfigurationKeys as $key) {
            switch ($key) {
                case 'amount.currency':
                    $prefilledConfiguration[$key] = $paymentData['amount.currency'];
                    break;
                case 'amount.value':
                    $prefilledConfiguration[$key] = $paymentData['amount.value'];
                    break;
                case 'api_access_token':
                    $prefilledConfiguration[$key] = $this->getToken($merchantId, $apiKey, $paymentData['paymentMode']);
                    break;
                case 'billingAddress.streetName':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.streetName'];
                    break;
                case 'billingAddress.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.streetNumber'];
                    break;
                case 'billingAddress.city':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.city'];
                    break;
                case 'billingAddress.country':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.country'];
                    break;
                case 'billingAddress.country.countryA2':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.country'] ?? "FR";
                    break;
                case 'billingAddress.country.countryA3':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.countryA3'] ?? "FRA";
                    break;
                case 'billingAddress.postalCode':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.postalCode'];
                    break;
                case 'billingAddress.addressLine1.street':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.addressLine1.street'] ?? 'ddd';
                    break;
                case 'billing.consumer.firstName':
                    $prefilledConfiguration[$key] = $paymentData['billing.consumer.firstName'];
                    break;
                case 'customerInfo.firstName':
                    $prefilledConfiguration[$key] = $paymentData['customerInfo.firstName'];
                    break;
                case 'customerInfo.lastName':
                    $prefilledConfiguration[$key] = $paymentData['customerInfo.lastName'];
                    break;
                case 'billing.consumer.lastName':
                    $prefilledConfiguration[$key] = $paymentData['billing.consumer.lastName'];
                    break;
                case 'captureMethod':
                    $prefilledConfiguration[$key] = $paymentData['capture'] ?? CaptureMode::AUTO;
                    break;
                case 'capture':
                    $prefilledConfiguration[$key] = $paymentData['capture'] ?? CaptureMode::AUTO;
                    break;
                case 'cardHolder.city':
                    $prefilledConfiguration[$key] = $paymentData['cardHolder.city'];
                    break;
                case 'cardHolder.name':
                    $prefilledConfiguration[$key] = $paymentData['cardHolder.name'];
                    break;
                case 'cartId':
                    $prefilledConfiguration[$key] = $paymentData['cartId'];
                    break;
                case 'customFields.customField2':
                    $prefilledConfiguration[$key] = $paymentData['customFields.customField2'];
                    break;
                case 'customFields.customField3':
                    $prefilledConfiguration[$key] = $paymentData['customFields.customField3'];
                    break;
                case 'customFields.customField4':
                    $prefilledConfiguration[$key] = $paymentData['customFields.customField4'];
                    break;
                case 'customFields.customField5':
                    $prefilledConfiguration[$key] = $paymentData['customFields.customField5'];
                    break;
                case 'customFields.customField6':
                    $prefilledConfiguration[$key] = $paymentData['customFields.customField6'];
                    break;
                case 'orderId':
                    $prefilledConfiguration[$key] = $paymentData['orderId'];
                    break;
                case 'orderReference':
                    $prefilledConfiguration[$key] = $paymentData['orderReference'];
                    break;
                case 'paymentId':
                    $prefilledConfiguration[$key] = $paymentData['paymentId'];
                    break;
                case 'paymentMode':
                    $prefilledConfiguration[$key] = $paymentData['paymentMode'];
                    break;
                case 'shipping.address.streetName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.streetName'];
                    break;
                case 'shipping.address.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.streetNumber'];
                    break;
                case 'shipping.address.city':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.city'] ?? 'Lille';
                    break;
                case 'shipping.address.country':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.country'];
                    break;
                case 'shipping.address.country.countryA2':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.country'] ?? "FR";
                    break;
                case 'shipping.address.country.countryA3':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.countryA3'] ?? "FRA";
                    break;
                case 'shipping.address.addressLine1.street':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.addressLine1.street'] ?? '';
                    break;
                case 'shipping.address.postalCode':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.postalCode'];
                    break;
                case 'shipping.consumer.firstName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.consumer.firstName'];
                    break;
                case 'shipping.consumer.lastName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.consumer.lastName'];
                    break;
                case 'shopName':
                    $prefilledConfiguration[$key] = $paymentData['shopName'];
                    break;
                case 'transId':
                    $prefilledConfiguration[$key] = $paymentData['transactionId'];
                    break;
                case 'transactionId':
                    $prefilledConfiguration[$key] = $paymentData['transactionId'];
                    break;
                case 'urlCancel':
                    $prefilledConfiguration[$key] = $paymentData['urlCancel'];
                    break;
                case 'urlFailure':
                    $prefilledConfiguration[$key] = $paymentData['urlFailure'];
                    break;
                case 'urlNotify':
                    $prefilledConfiguration[$key] = $paymentData['urlNotify'];
                    break;
                case 'urlWebhook':
                    $prefilledConfiguration[$key] = $paymentData['urlWebhook'];
                    break;
                case 'urlSuccess':
                    $prefilledConfiguration[$key] = $paymentData['urlSuccess'];
                    break;
                case 'urlReturn':
                    $prefilledConfiguration[$key] = $paymentData['urlReturn'];
                    break;
                case 'wirecardConnection.receiver.firstName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.receiver.firstName'];
                    break;
                case 'wirecardConnection.receiver.lastName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.receiver.lastName'];
                    break;
                case 'wirecardConnection.refundType':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.refundType'];
                    break;
                case 'wirecardConnection.sender.accountNumber':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.accountNumber'];
                    break;
                case 'wirecardConnection.sender.city':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.city'];
                    break;
                case 'wirecardConnection.sender.country':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.country'];
                    break;
                case 'wirecardConnection.sender.firstName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.firstName'];
                    break;
                case 'wirecardConnection.sender.lastName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.lastName'];
                    break;
                case 'wirecardConnection.sender.street':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.street'];
                    break;
                case 'wirecardConnection.sender.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.streetNumber'];
                    break;
                case 'language':
                    $prefilledConfiguration[$key] = $paymentData['language'];
                    break;
                default:
                    Axepta_Bnpp_Log::debug('Missing configuration key: ' . $key);
            }
        }

        $prefilledConfiguration['customFields.customField1'] = $paymentData['customFields.customField1'] ?? number_format((($paymentData['amount.value'] ?? 0) / 100), 2, ',', '') . ' ' . $paymentData['amount.currency'];
        $prefilledConfiguration['statementDescriptor'] = 'Woocommerce Axepta';
        $prefilledConfiguration['externalIntegrationId'] = 'WC-' . AXEPTA_BNPP_VERSION;
        $prefilledConfiguration['orderDesc'] = 'Woocommerce';
        $prefilledConfiguration['iso2CountryCode'] = "FR";
        $prefilledConfiguration['paymentRenderingMode'] = $paymentData['paymentRenderingMode'];
        $prefilledConfiguration['paysafeCard.accountHolder'] = $paymentData['paysafeCard.accountHolder'];
        $prefilledConfiguration['paysafeCard.customerId'] = $paymentData['paysafeCard.customerId'];
        $prefilledConfiguration['initializeSubscription'] = $isRecurringPaymentInit ? true : false;

        $prefilledConfiguration['metadata.userData'] = 'idOrder|' . $idOrder;

        $prefilledConfiguration['saveCard'] = isset($paymentData['axeptaMethodData']) && $paymentData['axeptaMethodData']['oneClickRegister'] ? true : false;

        if (isset($paymentData['axeptaMethodData']['isOneClick']) && $paymentData['axeptaMethodData']['isOneClick']) {
            $prefilledConfiguration['payment.card.card.brand'] = $paymentData['axeptaMethodData']['ccbrand'];
            $prefilledConfiguration['payment.card.card.expiryDate'] = $paymentData['axeptaMethodData']['ccexpiry'];
            $prefilledConfiguration['payment.card.card.number'] = $paymentData['axeptaMethodData']['pcnr'];

            $prefilledConfiguration['operationType'] = OperationType::ONE_CLICK_PAYMENT;
        } elseif (isset($paymentData['axeptaMethodData']['recurringSchedule']) && $paymentData['axeptaMethodData']['recurringSchedule']) {
            $prefilledConfiguration['payment.card.card.brand'] = $paymentData['axeptaMethodData']['card']['brand'];
            $prefilledConfiguration['payment.card.card.expiryDate'] = $paymentData['axeptaMethodData']['card']['expiryDate'];
            $prefilledConfiguration['payment.card.card.number'] = $paymentData['axeptaMethodData']['card']['number'];

            $prefilledConfiguration['operationType'] = OperationType::RECURRING_PAYMENT_SUBSCRIPTION;
        }
        $prefilledConfiguration['transactionId'] = (string) $paymentData['transactionId'];

        AxeptaPaygate::init($prefilledConfiguration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors de build operation : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
            return $e->getMessage();
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors de request call : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
        }

        return $response;
    }

    public function getParamsByTrigram($trigram, $paymentMode = 'REDIRECT', $isOneClick = false, $isRecurringSubsequent = false)
    {
        $operationType = $isOneClick ? OperationType::ONE_CLICK_PAYMENT : OperationType::SIMPLE_PAYMENT;
        $operationType = $isRecurringSubsequent ? OperationType::RECURRING_PAYMENT_SUBSCRIPTION : OperationType::SIMPLE_PAYMENT;
        [$prefilledConfiguration, $missingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys($trigram, $operationType, $paymentMode);

        return [$prefilledConfiguration, $missingConfigurationKeys];
    }

    public function getToken($merchantId, $apiKey, $mode = PaymentMode::PRODUCTION)
    {
        $tokenData = [];
        try {
            $tokenData = AxeptaPaygate::getAccessToken($merchantId, $apiKey, $mode);
        } catch (ApiCallException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors de génération de token : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
        }

        return $tokenData['access_token'];
    }

    public function getPaymentDetails($paymentId, $paymentMode, $merchantId, $apiKey, $paymentType = 'REDIRECT')
    {
        $paymentDetails = [];
        try {
            $configuration['paymentMode'] = $paymentMode;
            $configuration['paymentRenderingMode'] = $paymentType;
            AxeptaPaygate::init($configuration);

            $paymentDetails = AxeptaPaygate::getPaymentDetails($this->getToken($merchantId, $apiKey, $paymentMode), $paymentId);
        } catch (ApiCallException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors de la récupération de détails de paiement : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
        }

        return $paymentDetails;
    }

    public function capturePayment($merchantId, $apiKey, $paymentId, $paymentMode, $amount, $currency, $country, $transactionId)
    {
        $configuration = [
            'amount.value' => $amount,
            'amount.currency' => $currency,
            'api_access_token' => $this->getToken($merchantId, $apiKey, $paymentMode),
            'iso2CountryCode' => $country,
            'operationType' => OperationType::CAPTURE_PAYMENT,
            'paymentId' => $paymentId,
            'paymentMode' => $paymentMode,
            'transId' => (string) $transactionId,
        ];

        AxeptaPaygate::init($configuration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            Axepta_BNPP_Log::error('Capture mode : '.  $e->getMessage(), ['exception' => $e]);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            Axepta_BNPP_Log::error('Capture mode request: '.  $e->getMessage(), ['exception' => $e]);
        }

        return $response;
    }

    public function refundPayment($merchantId, $apiKey, $paymentId, $paymentMode, $amount, $currency, $country, $transactionId, $trigram, $orderReference, $cartId, $shopName, $name, $city, $operation_type)
    {
        // @TODO Add wirecardConnection
        $configuration = [
            'amount.value' => $amount,
            'amount.currency' => $currency,
            'api_access_token' => $this->getToken($merchantId, $apiKey, $paymentMode),
            'iso2CountryCode' => $country,
            'operationType' => $operation_type,
            'paymentId' => $paymentId,
            'paymentMode' => $paymentMode,
            'transactionId' => $transactionId,
            'transId' => $transactionId,
            'trigram' => $trigram,
            'orderReference' => $orderReference,
            'cartId' => $cartId,
            'shopName' => $shopName,
            'cardHolder.name' => $name,
            'cardHolder.city' => $city,
            'wirecardConnection.refundType' => 'P2P',
            'wirecardConnection.receiver.firstName' => 'John',
            'wirecardConnection.receiver.lastName' => 'Doe',
            'wirecardConnection.sender.accountNumber' => '123',
            'wirecardConnection.sender.city' => 'Madrid',
            'wirecardConnection.sender.country' => 'ES',
            'wirecardConnection.sender.firstName' => 'Jane',
            'wirecardConnection.sender.lastName' => 'Doe',
            'wirecardConnection.sender.street' => 'Some street',
            'wirecardConnection.sender.streetNumber' => '123',
        ];

        AxeptaPaygate::init($configuration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors du remboursement : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            Axepta_BNPP_Log::error(__('Erreur lors du remboursement après buildOperation : ', 'axepta-bnp-paribas').  $e->getMessage(), ['exception' => $e]);
        }

        return $response;
    }
}
