<?php

if (!defined('ABSPATH')) {
    exit;
}

use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\PaymentRenderingMode;

class Axepta_BNPP_Helper
{
    public static $account_settings = [];

    public function __construct() 
    {
        self::$account_settings = get_option('axepta_settings', []);
    }

    public static function getMerchantId()
    {
        switch (self::$account_settings['axepta_mode']) {
            case 'production':
                return self::$account_settings['axepta_merchant_id'] ?? Axepta_BNPP_Constant::DEMO_ID;
            case 'test':
                return self::$account_settings['axepta_test_merchant_id'] ?? Axepta_BNPP_Constant::DEMO_ID;
            default:
                return "BNP_AXE_STD_DEMO";
        }
    }

    public static function getApiKey() 
    {
        switch (self::$account_settings['axepta_mode']) {
            case 'production':
                return self::$account_settings['axepta_private_key'] ?? Axepta_BNPP_Constant::DEMO_KEY;
            case 'test':
                return self::$account_settings['axepta_test_key'] ?? Axepta_BNPP_Constant::DEMO_KEY;
            default:
                return "a831e0b6-1342-4449-b030-1126dc1afc4d";
        }
    }

    public static function getPaymentMode()
    {
        switch (self::$account_settings['axepta_mode']) {
            case 'production':
                return PaymentMode::PRODUCTION;
            case 'test':
                return PaymentMode::TEST;
            default:
                return PaymentMode::DEMO;
        }
    }

    public static function getCaptureMode()
    {
        switch (self::$account_settings['axepta_capture_mode']) {
            case 'deferred':
                return self::$account_settings['axepta_capture_hours'] ?? 24;
            case 'manuel':
                return CaptureMode::MANUAL;
            default:
                return CaptureMode::AUTO;
        }
    }

    public static function getRenderingMode($trigram)
    {
        if (self::$account_settings['axepta_payment_layout'] === 'hpp') {
            return PaymentRenderingMode::HPP;
        }

        return PaymentRenderingMode::REDIRECT;
    }

	public static function getTransactionStatus($status, $responseCode) 
	{
		if (self::$account_settings['axepta_mode'] === 'production') {
        	return ($status === 'OK' && $responseCode === '00000000') ? Axepta_BNPP_Constant::STATUS_SUCCESS : Axepta_BNPP_Constant::STATUS_FAILED;
		}
		
		if (self::$account_settings['axepta_mode'] === 'test') {
			return ($status === 'OK' && $responseCode === '00000000') ? Axepta_BNPP_Constant::TRANSACTION_TEST_SUCCESS : Axepta_BNPP_Constant::TRANSACTION_TEST_FAIL;
		}

		return ($status === 'OK' && $responseCode === '00000000') ? Axepta_BNPP_Constant::TRANSACTION_DEMO_SUCCESS : Axepta_BNPP_Constant::TRANSACTION_DEMO_FAIL;
	}

    public static function getIsoCountry3($country_code) {
        $countries = [
            'FR' => 'FRA', 'US' => 'USA', 'GB' => 'GBR', 'DE' => 'DEU', 'IT' => 'ITA',
            'ES' => 'ESP', 'CA' => 'CAN', 'AU' => 'AUS', 'JP' => 'JPN', 'IN' => 'IND',
        ];

        $countryCodeUpper = strtoupper($country_code);
		return $countries[$countryCodeUpper] ?? $countryCodeUpper;
    }

    public static function get_releases() {
        $changelog_path = plugin_dir_path(dirname(__FILE__)) . 'CHANGELOG.md';
        if (!file_exists($changelog_path)) {
            return [];
        }

        $content = file_get_contents($changelog_path);
        $releases = [];
        
        // Parse le contenu du changelog
        preg_match_all('/## \[(.*?)\] - (\d{4}-\d{2}-\d{2})\n(.*?)(?=\n## |\n---|\z)/s', $content, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $version = $match[1];
            $date = $match[2];
            $content = trim($match[3]);
            
            // Extrait le premier élément comme titre
            $lines = array_filter(array_map('trim', explode("\n", $content)));
            $title = "";
            $description = "";
            
            foreach ($lines as $line) {
                if (strpos($line, '- ') === 0) {
                    if (empty($title)) {
                        $title = trim(substr($line, 2));
                    } else {
                        $description .= trim(substr($line, 2)) . "\n";
                    }
                }
            }
            
            $releases[] = [
                'name' => $title,
                'version' => $version,
                'created_at' => $date,
                'tag_name' => $version,
                'description' => trim($description)
            ];
        }
        
        return $releases;
    }
}

new Axepta_BNPP_Helper();