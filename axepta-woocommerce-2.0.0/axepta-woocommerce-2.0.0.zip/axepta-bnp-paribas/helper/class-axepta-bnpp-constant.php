<?php

if (!defined('ABSPATH')) {
    exit;
}

final class Axepta_BNPP_Constant
{
    public const AXEPTA_BNPP_PLUGIN_NAME = 'Axepta BNP Paribas';
    public const AXEPTA_BNPP_PLUGIN_SLUG = 'axepta-bnp-paribas';
    public const CAPTURE_PAYMENT = 'CAPTURE_PAYMENT';
    public const ONE_CLICK_PAYMENT = 'ONE_CLICK_PAYMENT';
    public const PAYMENT_REFUND = 'PAYMENT_REFUND';
    public const PAYMENT_REVERSAL = 'PAYMENT_REVERSAL';
    public const RECURRING_PAYMENT_SUBSCRIPTION = 'RECURRING_PAYMENT_SUBSCRIPTION';
    public const SIMPLE_PAYMENT = 'SIMPLE_PAYMENT';

    public const STATUS_CREATED = 'CREATED';
    public const STATUS_CANCELED = 'CANCELED';
    public const STATUS_CAPTURED = 'CAPTURED';
    public const STATUS_DECLINED = 'DECLINED';
    public const STATUS_EXPIRED = 'EXPIRED';
    public const STATUS_FAILED = 'FAILED';
    public const STATUS_PENDING = 'PENDING';
    public const STATUS_REFUNDED = 'REFUNDED';
    public const STATUS_REVERSED = 'REVERSED';
    public const STATUS_SUCCESS = 'SUCCESS';
    public const STATUS_VOIDED = 'VOIDED';
    public const TRANSACTION_DEMO_SUCCESS = 'AXEPTA DEMO OK';
    public const TRANSACTION_DEMO_FAIL = 'AXEPTA DEMO ERREUR';
    public const TRANSACTION_TEST_SUCCESS = 'AXEPTA TEST OK';
    public const TRANSACTION_TEST_FAIL = 'AXEPTA TEST ERREUR';

    public const DEMO_OK = 'axepta-demo-ok';
    public const CAPTURE_PENDING = 'capture-pending';
    public const TEST_OK = 'axepta-test-ok';
    public const TEST_FAIL = 'axepta-test-fail';

    public static function full($status) {
        return 'wc-' . $status;
    }
    
    public const SMTP_HOST = "smtp://weplus-interne-001.francecentral.cloudapp.azure.com";
    public const SMTP_PORT = 1025;
    public const SMTP_USERNAME = "";
    public const SMTP_PASSWORD = "";
    public const SMTP_FROMEMAIL = "test@gmail.com";
    public const SMTP_FROMNAME = "Axepta BNP Paribas";
    
    const LOG_AUTHORIZED_PARAMS = [
        'MerchantID', 'URLSuccess', 'URLFailure', 'URLNotify', 'EtiId', 'Amount', 'Amount3D', 'Currency', 'OrderDesc', 'TransID', 'Status', 'Type', 'CCBrand', 'TrxTime', 
        'RefNr', 'ReqID', 'mid', 'PayID', 'status', 'refnr', 'msgver', 'is_recurring', 'trigram', 'ApprovalCode', 'schemeReferenceID', 'Description', 'Code', 'XID', 'midName', 'order_id'
    ];

    const MOCK_TRANSACTION = [
        'merchant_code' => 'Axepta001',
        'transaction_reference' => 'TRX123456',
        'order_id' => 1234,
        'pay_id' => 'PAY123456',
        'bid' => 'BID001',
        'xid' => 'XID001',
        'amount' => 99.99,
        'transaction_type' => 'Sale',
        'payment_mean_brand' => 'Visa',
        'payment_mean_type' => 'Credit Card',
        'response_code' => '00',
        'pcnr' => 'PCNR12345',
        'ccexpiry' => '12/23',
        'status' => 'Approved',
        'description' => 'Transaction description',
        'raw_data' => array('response' => 'success', 'details' => 'Transaction successful'),
    ];
}