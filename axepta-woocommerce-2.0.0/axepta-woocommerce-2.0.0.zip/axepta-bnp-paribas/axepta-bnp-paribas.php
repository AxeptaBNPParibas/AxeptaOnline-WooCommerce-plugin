<?php

use Automattic\WooCommerce\Utilities\OrderUtil;
/*
 * Plugin Name: Axepta BNP Paribas 2.0
 * Description: Axepta BNP Paribas offre une solution de paiement en ligne sécurisée, permettant aux commerçants d'accepter facilement les paiements par carte via leur site e-commerce, avec des technologies avancées pour une expérience utilisateur fluide et sécurisée.
 * Version: 2.0.0
 * Author: We+
 * Author URI: https://we-plus.com/
 */

if (!defined('ABSPATH')) {
	exit;
}

define('AXEPTA_BNPP_VERSION', get_file_data(__FILE__, array('Version'))[0]);
define('AXEPTA_BNPP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AXEPTA_BNPP_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once AXEPTA_BNPP_PLUGIN_PATH . 'includes/class-axepta-bnpp-log.php';
require_once AXEPTA_BNPP_PLUGIN_PATH . 'axepta-bnp-install.php';

register_activation_hook(__FILE__, [Axepta_BNP_Install::class, 'install']);
register_deactivation_hook(__FILE__, [Axepta_BNP_Install::class, 'deactivation']);
register_uninstall_hook(__FILE__, [Axepta_BNP_Install::class, 'uninstall']);

class Axepta_BNP_Paribas
{
	public function __construct() {
		add_action('plugins_loaded', [$this, 'init'], 11);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
		add_action('woocommerce_blocks_loaded', [$this, 'block_loaded']);
		
        add_action('phpmailer_init', [$this, 'custom_mailtrap_smtp']);
		add_action('in_admin_header', [$this, 'notice_message_demo'], 10);
		
		add_action('init', [$this, 'load_textdomain']);
	}

	# Load translations (compatible with WordPress 6.7+)
	public function load_textdomain() {
		$locale = get_locale();
		$textdomain = 'axepta-bnp-paribas';
		$plugin_path = AXEPTA_BNPP_PLUGIN_PATH . 'languages/' . $textdomain . '-' . $locale . '.mo';
		$global_path = WP_LANG_DIR . '/plugins/' . $textdomain . '-' . $locale . '.mo';

		load_plugin_textdomain($textdomain, false, dirname(plugin_basename(__FILE__)) . '/languages');

		if (file_exists($plugin_path) && is_readable($plugin_path)) {
			load_textdomain($textdomain, $plugin_path);
		} elseif (file_exists($global_path) && is_readable($global_path)) {
			load_textdomain($textdomain, $global_path);
		}
	}

	# load plugin files
	public function init() {
        if (!is_plugin_active('woocommerce/woocommerce.php')) {
            add_action('admin_notices', [$this, 'notice_if_woocommerce_not_active']);
            return;
        }

		$this->init_files();

		if (is_admin() && class_exists('Axepta_BNPP_Admin_Subscription')) {
			new Axepta_BNPP_Admin_Subscription();
		}

		add_action('add_meta_boxes', [$this, 'add_meta_boxes']);

		if (class_exists('WC_Payment_Gateway')) {
		    add_filter('woocommerce_payment_gateways', [$this, 'add_gateway']);
		}

		# send settings to blocks
		add_action('rest_api_init', [$this, 'register_rest_api']);
	}

	# load plugin files
	public function init_files() {
		$files = [
			'includes/class-axepta-bnpp-config.php',
			'includes/class-axepta-bnpp-one-click.php',
			'includes/class-axepta-bnpp-transaction.php',
			'includes/class-axepta-bnpp-order-status.php',
			'includes/class-axepta-bnpp-transaction-alert.php',
			'includes/class-axepta-bnpp-admin-order-cleaner.php',
			'includes/class-axepta-bnpp-order-payment-details.php',
			'vendor/axepta-paygate/lib/init.php',
			'helper/class-axepta-bnpp-helper.php',
			'helper/class-axepta-bnpp-constant.php',
			'helper/class-axepta-bnpp-api-service.php',
			'gateways/class-wc-gateway-axepta-bnpp.php',
			'gateways/helper/class-axepta-bnpp-handle-return.php',
			'gateways/helper/class-axepta-bnpp-handle-capture.php',
			'gateways/helper/class-axepta-bnpp-refund-process.php',
			'gateways/helper/class-axepta-bnpp-payment-process.php'
		];

		if (is_admin()) {
			$files[] = 'includes/backoffice/class-axepta-bnpp-admin-transaction.php';
			$files[] = 'includes/backoffice/class-axepta-bnpp-transaction-table.php';
		}

		if (get_option('axepta_settings')['axepta_subscription_enabled'] === '1') {
			if (is_admin()) {
				$files[] = 'includes/backoffice/class-axepta-bnpp-admin-subscription.php';
				$files[] = 'includes/backoffice/class-axepta-bnpp-subscription-table.php';
			}
			$files[] = 'includes/class-axepta-bnpp-subscription.php';
			$files[] = 'includes/front/class-axepta-bnpp-customer-account.php';
			$files[] = 'includes/front/class-axepta-bnpp-customer-subscription.php';
		}

		foreach ($files as $file) {
			require_once AXEPTA_BNPP_PLUGIN_PATH . $file;
		}
	}


	# register rest api
	public function register_rest_api() {
		# get payment methods
		register_rest_route('axepta/v1', '/settings', [
			'methods' => 'GET',
			'callback' => function () {
				$settings = get_option('axepta_settings', []);

				return [
					'payment_methods' => $settings['axepta_payment_methods'] ?? []
				];
			},
			'permission_callback' => '__return_true',
		]);

		# return user saved cards
		register_rest_route('axepta/v1', '/saved-cards', [
			'methods' => 'GET',
			'callback' => function () {
				$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : '-1';
				$saved_cards = Axepta_BNPP_OneClick::get_user_cards($user_id);
				return [
					'cards' => $saved_cards
				];
			},
			'permission_callback' => '__return_true',
		]);
	}

    # activate gateway by default
    public function axepta_activate_gateway_by_default() {
        $settings = get_option('woocommerce_axepta_bnpp_settings', []);
        $settings['enabled'] = 'yes';
        update_option('woocommerce_axepta_bnpp_settings', $settings);
    }

	# add meta boxes
	public function add_meta_boxes() {
		$screen = 'shop_order';
        if (OrderUtil::custom_orders_table_usage_is_enabled()) {
            $screen = wc_get_page_screen_id('shop-order');
        }
		add_meta_box('woocommerce-axepta-bnpp-order-transactions', __('Axepta BNP Paribas - Historique des transactions', 'axepta-bnp-paribas'), 'Axepta_BNPP_Transaction::output', $screen, 'normal', 'low');
		add_meta_box('woocommerce-axepta-bnpp-order-payment-details', __('Axepta BNP Paribas - Détails de paiement', 'axepta-bnp-paribas'), 'Axepta_BNPP_Order_Payment_Details::display_payment_details', $screen, 'normal', 'high');
	}

	# add gateway
	public function add_gateway($gateways) {
		$gateways[] = 'WC_Gateway_Axepta_BNPP';
		return $gateways;
	}

	# register rewrite rule
	public function register_rewrite_rule() {
		add_rewrite_rule('^axepta-return/?', 'index.php?wc-api=axepta_cb_return', 'top');
	}

    # notice if woocommerce not active
    public function notice_if_woocommerce_not_active() {
        ?>
        <div class="error">
            <p><?php _e('Axepta BNP Paribas nécessite que WooCommerce soit installé et activé.', 'axepta-bnp-paribas'); ?></p>
        </div>
        <?php
    }

	# enqueue assets (js/css)
	public function enqueue_assets($hook) {
		$screen = get_current_screen();
		$isWooAxeptaTab = $screen && $screen->id === 'woocommerce_page_wc-settings' && isset($_GET['tab']) && $_GET['tab'] === 'axepta_bnpp';
		$isAxeptaPages = $isWooAxeptaTab || (isset($_GET['page']) && in_array($_GET['page'], ['axepta-bnpp-transactions', 'wc-orders', 'axepta-bnpp-subscriptions']));

		if ($hook !== 'toplevel_page_axepta-settings' && !$isWooAxeptaTab) {
			return;
		}

		wp_enqueue_style('axepta-admin-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
		wp_enqueue_script('axepta-admin-js', plugin_dir_url(__FILE__) . 'assets/js/admin.js', ['jquery', 'wp-i18n'], null, true);
		wp_set_script_translations('axepta-admin-js', 'axepta-bnp-paribas', AXEPTA_BNPP_PLUGIN_PATH . 'languages');

	}

	# display demo message in demo mode 
	public function notice_message_demo() {
		$is_axepta_settings = isset($_GET['tab']) && $_GET['tab'] === 'axepta_bnpp';
		$is_axepta_pages = isset($_GET['page']) && in_array($_GET['page'], ['axepta-bnpp-transactions', 'wc-orders']);
		$is_not_prod = isset(get_option('axepta_settings', [])['axepta_mode']) && get_option('axepta_settings', [])['axepta_mode'] !== 'production';

		if (($is_axepta_settings || $is_axepta_pages) && $is_not_prod) {
			echo sprintf(
				'<div id="axepta-banner-demo" class="notice notice-warning" 
					style="background-color: #FF9330; color: #505050; padding: 10px; font-weight: bold; text-align: center; font-family: Montserrat, sans-serif; font-size: 32px; line-height: 1; letter-spacing: 13%%; margin: 20px 0;">%s</div>',
				mb_strtoupper(esc_html__('Vous êtes en mode ' . get_option('axepta_settings', [])['axepta_mode'], 'axepta-bnp-paribas'))
			);
		}
	}
	
	# register blocks
	public function block_loaded() {
		if (class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
			require_once AXEPTA_BNPP_PLUGIN_PATH . 'gateways/blocks/class-wc-axepta-bnpp-blocks.php';
			add_action(
				'woocommerce_blocks_payment_method_type_registration',
				function ($payment_method_registry) {
					$payment_method_registry->register(new WC_Gateway_Axepta_Bnpp_Blocks());
				}
			);
		}
	}

	public function custom_mailtrap_smtp($phpmailer)
    {
        $phpmailer->isSMTP();
        $phpmailer->Host = get_option('axepta_settings')['axepta_smtp_host'];
        $phpmailer->Port = Axepta_BNPP_Constant::SMTP_PORT;
        $phpmailer->Username = get_option('axepta_settings')['axepta_smtp_user'];
        $phpmailer->Password = get_option('axepta_settings')['axepta_smtp_password'];
		$phpmailer->SMTPAuth = true; 
        $phpmailer->SMTPSecure = 'tls';
        $phpmailer->From = Axepta_BNPP_Constant::SMTP_FROMEMAIL;
        $phpmailer->FromName = Axepta_BNPP_Constant::SMTP_FROMNAME;
    }
}

new Axepta_BNP_Paribas();
