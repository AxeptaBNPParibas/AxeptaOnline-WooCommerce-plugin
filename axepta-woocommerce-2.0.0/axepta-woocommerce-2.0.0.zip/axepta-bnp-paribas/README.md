# BNP Paribas - Module Mercanet pour Wordpress

<!-- TABLE OF CONTENTS -->
## Tables des matières

* [Description Générale](#description-générale)
* [Technologies](#technologies)
* [Documentation](#documentation)
* [License](#license)
* [À Propos](#à-propos)

## Description Générale

Le module de paiement officiel MERCANET BNP Paribas permet d'accepter facilement et rapidement vos paiements en ligne en toute sécurité.

## Technologies

Liste des technologies utilisées dans le projet :

* [x]  [Wordpress](https://fr.wordpress.org/download/releases/) : Version x à 6.0
* [x]  [Woocommerce](https://developer.woocommerce.com/releases/) : Version 3.7 à 6.0


## Documentation

* Veuillez trouver le lien à notre site de documentation en ligne Axepta BNP Paribas et à notre guide d’installation du module Axepta BNP Paribas pour Wordpress : https://docs.axepta.bnpparibas/pages/viewpage.action?pageId=15073293#WooCommerce(de5.3%C3%A06.6)-Installationdumodule

## Développement

Avant de commencer, allez dans le répertoire du module et lancez les commandes suivantes :

```text
nvm use
npm install
```

N'oubliez pas de build vos sources lorsque vous les modifiez :

```text
npm run build
//
npm start
```

## License

    BNP Paribas

    @author    We+ <modules@we-plus.fr>
    @copyright Since 1961 BNP Paribas
    @license   All Rights Reserved


## À propos

Le développement de ce module est dirigé par [We+](https://we-plus.fr/)

## Informations supplémentaires

Dans le cas de la mise en place du paiement par abonnement
Ajouter la ligne suivante dans le fichier de configuration du wordpress à la racine du site (wp-config.php) :

    define('DISABLE_WP_CRON', false);
