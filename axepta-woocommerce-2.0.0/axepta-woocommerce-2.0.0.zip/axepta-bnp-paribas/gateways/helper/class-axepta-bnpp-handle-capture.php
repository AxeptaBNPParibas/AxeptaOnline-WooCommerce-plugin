<?php

if (!defined('ABSPATH')) {
    exit;
}

use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;

class Axepta_BNPP_Handle_Capture
{   
    public static function capture_payment(object $transaction, string $currency = "EUR", string $country = "FR") {
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $merchantId = Axepta_BNPP_Helper::getMerchantId();

        if (get_option('axepta_settings', [])['axepta_mode'] !== 'production') {
            return [
                'status'  => 'failed',
                'message' => __("La capture n’est pas disponible en mode test/demo.", 'axepta-bnp-paribas'),
            ];
        }

        $service = new Axepta_Bnpp_Api_Service();
        $paymentDetail = $service->getPaymentDetails($transaction->pay_id, OperationType::SIMPLE_PAYMENT, $merchantId, $apiKey);
        
        if (!empty($paymentDetail['amount']['capturedValue']) && $paymentDetail['amount']['capturedValue'] > 0) {
            return [
                'status'  => 'failed',
                'message' => __("La transaction a déjà été capturée", 'axepta-bnp-paribas'),
            ];
        }

        $captureAmount = (int) round($transaction->amount * 100);
        $resp = $service->capturePayment($merchantId, $apiKey, $transaction->pay_id, 'REDIRECT', $captureAmount, $currency, $country, (string) $transaction->transaction_id);
        $resp = json_decode($resp, true);

        if (isset($resp['status']) && $resp['status'] === 'OK') {
            $updated = Axepta_BNPP_Transaction::update_transaction_captured_mode($transaction->transaction_id, "manuel", 'yes', $transaction->amount);

            if ($updated) {
                $transaction->captured = null;
                Axepta_BNPP_Transaction::add_transaction($transaction, OperationType::CAPTURE_PAYMENT);
                return [
                    'status'  => 'success',
                    'message' => __("Paiement capturé avec succès !", 'axepta-bnp-paribas'),
                ];
            }

            return [
                'status'  => 'failed',
                'message' => __("La transaction a été capturée mais la mise à jour en base des données a échoué.", 'axepta-bnp-paribas'),
            ];
        }

        return [
            'status'  => 'failed',
            'message' => __("La capture a échoué. Merci de réessayer.", 'axepta-bnp-paribas'),
        ];
    }

    public static function cancel_capture(object $transaction) {
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $merchantId = Axepta_BNPP_Helper::getMerchantId();
        $order = wc_get_order($transaction->order_id);

        if($transaction && $transaction->transaction_type === Axepta_BNPP_Constant::SIMPLE_PAYMENT && $transaction->pay_id) {
            $refund_amount = $transaction->amount;
            $payment_id = $transaction->pay_id;
            $payment_mode = mb_strtoupper(get_option('axepta_settings')['axepta_mode']);
            $name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $trigram = 'cvm';

            $service = new Axepta_Bnpp_Api_Service();
            $paymentDetail = $service->getPaymentDetails($payment_id, $payment_mode, $merchantId, $apiKey);

            if(isset($paymentDetail['status']) && $paymentDetail['status'] === 'failled') {
                return [
                    'status'  => 'failed',
                    'message' => __("La récupération de la transaction distante a échoué", 'axepta-bnp-paribas'),
                ];
            }

            $response = $service->refundPayment(
                $merchantId, 
                $apiKey, 
                $transaction->pay_id, 
                $payment_mode, 
                $transaction->amount*100, 
                $order->get_currency(), 
                $order->get_billing_country(), 
                $order->get_transaction_id(), 
                $trigram, 
                $order->get_id(), 
                $order->get_id(), 
                get_bloginfo('name'), 
                $name, 
                $order->get_billing_city(), 
                OperationType::PAYMENT_REVERSAL
            );
            $response = json_decode($response, true);

            if (isset($response['status']) && $response['status'] === 'OK' && isset($response['payId']) && $response['payId'] !== '00000000000000000000000000000000' && !empty($response['transId'])) {
                $transaction->raw_data = json_encode($response);
                $transaction->captured = null;
                $transaction->amount = $refund_amount;

                $order->add_order_note(sprintf(__('Remboursement de %s effectué via Axepta BNP Paribas.', 'axepta-bnp-paribas'), wc_price($refund_amount)));
                $order->update_status('wc-cancelled');
                $order->save();

                $result = Axepta_BNPP_Transaction::add_transaction($transaction, OperationType::PAYMENT_REVERSAL);
                $message = __("L'annulation de la capture a réussi", 'axepta-bnp-paribas');
                if ($result === false) {
                    $message = __("L'annulation a réussi mais le stockage dans la bdd a échoué", 'axepta-bnp-paribas');
                }

                $updated = Axepta_BNPP_Transaction::update_transaction_captured_mode($transaction->transaction_id, null, null, $paymentDetail['amount']['capturedValue']);
                if(!$updated) {
                    $message = __("L'annulation a réussi mais le changement de statut de la transaction non capturé a échoué", 'axepta-bnp-paribas');
                }
                return [
                    'status'  => 'success',
                    'message' => $message,
                ];
            } else {
                return [
                    'status'  => 'failed',
                    'message' => __("L'annulation a échoué", 'axepta-bnp-paribas') . (isset($response['description']) ? $response['description'] : ''),
                ];
            }
        } else {
            return [
                'status'  => 'failed',
                'message' => __('Transaction invalide', 'axepta-bnp-paribas'),
            ];
        }
    }
}