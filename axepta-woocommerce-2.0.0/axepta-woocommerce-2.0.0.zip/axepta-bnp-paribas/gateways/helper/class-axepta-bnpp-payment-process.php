<?php

if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Payment_Process
{
    public static function register_rewrite_rule() {
		add_rewrite_rule('^axepta-iframe/?$', 'index.php?axepta_iframe=1', 'top');
		add_rewrite_rule('^axepta-test-page/?$', 'index.php?axepta_test_page=1', 'top');
	}

	public static function register_query_vars($vars) {
		$vars[] = 'axepta_iframe';
		$vars[] = 'axepta_test_page';
		return $vars;
	}

	/**
	 * Initiates a payment request to Axepta via Server-to-Server API.
	 *
	 * @param WC_Order $order
	 * @return array|WP_Error
	 */
	public static function create_payment_request(WC_Order $order, array $post) {
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $merchantId = Axepta_BNPP_Helper::getMerchantId();
        
        // Init transaction with "pending" status
        $transaction = self::create_transaction($order, $merchantId, Axepta_BNPP_Constant::STATUS_PENDING, $post);

        $order->set_transaction_id($transaction);
        $order->update_status('pending', __('En attente de paiement externe', 'axepta-bnp-paribas'));

        if (!empty($post['save_card']) && $post['save_card'] === 'on') {
            update_user_meta($order->get_user_id(), '_axepta_save_card', 'yes');
        }

        $trigram = self::get_trigram($post['axepta_bnpp_selected_gateway']);
        $paymentData = self::create_payment_data($order, $trigram);
        $paymentMode = Axepta_BNPP_Helper::getRenderingMode($trigram);
        
        $service = new Axepta_Bnpp_Api_Service();
        $resp = $service->buildOperation(false, $trigram, $merchantId, $apiKey, $paymentData, $paymentMode, false);
        $resp = json_decode($resp, true);

        if (!empty($resp['_links']['redirect']['href'])) {
            $url = self::axepta_get_payment_url($order, $resp['_links']['redirect']['href'], get_option('axepta_settings')['axepta_display_mode']);
            return [
                'result' => 'success',
                'redirect' => $url,
            ];
        }

        return [
            'result' => 'failure',
            'redirect' => null,
        ];

	}
    
    # create transaction
    public static function create_transaction(WC_Order $order, string $merchantId, string $status = Axepta_BNPP_Constant::STATUS_PENDING) 
    {
        $transaction_type = self::has_subscription_product($order) ? Axepta_BNPP_Constant::RECURRING_PAYMENT_SUBSCRIPTION : Axepta_BNPP_Constant::SIMPLE_PAYMENT;
        $data = (object) [
            'order_id' => $order->get_id(),
            'amount' => $order->get_total(),
            'merchant_code' => $merchantId,
            'status' => $status . '(' . mb_strtoupper(get_option('axepta_settings')['axepta_mode']) . ')',
            'transaction_reference' => null,
            'capture_mode' => get_option('axepta_settings')['axepta_capture_mode'] ?? 'auto',
        ];

        $transaction = Axepta_BNPP_Transaction::get_order_pending_transaction($order->get_id());
        if(!$transaction || $transaction['status'] !== $status) {
            $transaction = Axepta_BNPP_Transaction::add_transaction($data,$transaction_type);
        }
        return isset($transaction->transaction_id) ? $transaction->transaction_id : (is_array($transaction) ? $transaction['transaction_id'] : $transaction);
    }

    public static function has_subscription_product(WC_Order $order): bool
    {
        /** @var WC_Order_Item_Product $item */
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            
            if ('subscription' === get_post_meta($product->get_id(), '_axepta_product_type', true)) {
                return true;
            }
        }

        return false;
    }

    public static function axepta_get_payment_url(WC_Order $order, string $redirect_href, string $display_mode): string {
        if ($display_mode === 'iframe') {
            $args = [
                'order_id'   => $order->get_id(),
                'iframe_src' => $redirect_href,
            ];

            if (get_option('permalink_structure')) {
                return add_query_arg($args, home_url('/axepta-iframe'));
            }

            $args['axepta_iframe'] = 1;
            return add_query_arg($args, home_url('/'));
        }

        return add_query_arg(['order_id' => $order->get_id()], $redirect_href);
    }

	public static function handle_iframe_page() {
		if (get_query_var('axepta_iframe') == 1 || get_query_var('axepta_test_page') == 1) {
			status_header(200);
			nocache_headers();
	
			$order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
			$iframe_src = isset($_GET['iframe_src']) ? esc_url_raw($_GET['iframe_src']) : '';
			$order = wc_get_order($order_id);

	
			if (!$order) {
				echo 'Commande introuvable.';
				exit;
			}
	
			$order_total = $order->get_total();
            $order_date = $order->get_date_created()->format('d/m/Y H:i:s');
	
			$product_names = [];
			foreach ($order->get_items() as $item) {
				$product_names[] = $item->get_name();
			}
			$product_name = implode(', ', $product_names);
	
			$billing_first_name = $order->get_billing_first_name();
			$billing_last_name  = $order->get_billing_last_name();
			$customer_name = trim($billing_first_name . ' ' . $billing_last_name);
	
			$shipping_address = $order->get_formatted_shipping_address();
			if (empty($shipping_address)) {
				$shipping_address .= " - " . $order->get_formatted_billing_address();
			}

	
			$product_lines = [];
			foreach ($order->get_items() as $item) {
				$name = $item->get_name();
				$qty  = $item->get_quantity();
				$product_lines[] = "$qty × $name";
			}
			$product_summary = implode('<br>', $product_lines);

			include AXEPTA_BNPP_PLUGIN_PATH . 'views/mock/html-payment-page.php';
			exit;
		}
	}

    public static function get_trigram(string $paygate) 
    {
        if (is_numeric($paygate)) {
            $card = Axepta_BNPP_OneClick::get_card_by_id($paygate);
            return $card ? $card->trigram : 'AMX';
        } else {
            return $paygate === 'amex' ? 'AMX' :
            ($paygate === 'payPal' ? 'PAL' :
            ($paygate === 'pay' ? 'PAY' :
            ($paygate === 'sof' ? 'SOF' :
            ($paygate === 'sdd' ? 'SDD' :
            'VIM'))));
        }
    }

    public static function create_payment_data($order, $trigram) 
    {
        $settings = get_option('axepta_settings');
        $capture = Axepta_BNPP_Helper::getCaptureMode();
        $renderingMode = Axepta_BNPP_Helper::getRenderingMode($trigram);
        
        return [
            'amount.currency' => $order->get_currency(),
            'amount.value' => (int) round($order->get_total() * 100),
            'customer.email' => $order->get_billing_email(),
            'customerInfo.firstName' => $order->get_billing_first_name(),
            'customerInfo.lastName' => $order->get_billing_last_name(),
            'customer.ip' => $order->get_customer_ip_address(),

            'billingAddress.streetName' => $order->get_billing_address_1(),
            'billingAddress.streetNumber' => $order->get_billing_address_2(),
            'billingAddress.city' => $order->get_billing_city(),
            'billingAddress.postalCode' => $order->get_billing_postcode(),
            'billingAddress.country' => Axepta_BNPP_Helper::getIsoCountry3($order->get_billing_country()),

            'shipping.address.streetName' => $order->get_shipping_address_1(),
            'shipping.address.streetNumber' => $order->get_shipping_address_2(),
            'shipping.address.city' => $order->get_shipping_city(),
            'shipping.address.postalCode' => $order->get_shipping_postcode(),
            'shipping.address.country' => Axepta_BNPP_Helper::getIsoCountry3($order->get_shipping_country()),

            'orderId' => (string) $order->get_id(),
            'paymentId' => '',
            'orderReference' => $order->get_order_number(),
            'shopName' => get_bloginfo('name'),
            'cartId' => $order->get_id(),
            'capture' => $capture,
            'transactionId' => (string) $order->get_transaction_id(),
            'paymentMode' => Axepta_BNPP_Helper::getPaymentMode(),

            'billing.consumer.firstName' => $order->get_billing_first_name(),
            'billing.consumer.lastName' => $order->get_billing_last_name(),
            'customFields.customField2' => $order->get_total() . ' ' . $order->get_currency(),
            'customFields.customField3' => $settings['axepta_custom_logo_url'] ?? '',
            'customFields.customField4' => $settings['axepta_custom_title'] ?? 'Custom Title',
            'customFields.customField5' => $settings['axepta_custom_text'] ?? 'Custom text',
            'customFields.customField6' => "Custom texte",

            'shipping.consumer.firstName' => $order->get_shipping_first_name(),
            'shipping.consumer.lastName' => $order->get_shipping_last_name(),

            'urlCancel' => $order->get_cancel_order_url(),
            'urlFailure' => esc_url(add_query_arg('axepta-action', 'failure', WC()->api_request_url(strtolower(WC_Gateway_Axepta_BNPP::class)))),
            'urlWebhook' => esc_url(add_query_arg('axepta-action', 'webhook', WC()->api_request_url(strtolower(WC_Gateway_Axepta_BNPP::class)))),
            'urlReturn' => esc_url(add_query_arg('axepta-action', 'success', WC()->api_request_url(strtolower(WC_Gateway_Axepta_BNPP::class)))),

            'paymentRenderingMode' => $renderingMode,
            'paysafeCard.accountHolder' => "",
            'paysafeCard.customerId' => "Test",
            'language' => substr(get_locale(), 0, 2),
        ];
    }
}