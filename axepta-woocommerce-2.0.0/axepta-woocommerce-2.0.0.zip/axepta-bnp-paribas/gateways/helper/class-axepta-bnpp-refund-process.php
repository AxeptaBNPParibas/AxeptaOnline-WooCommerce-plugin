<?php

use AxeptaPaygate\Core\OperationType;

if (!defined('ABSPATH')) {
    exit;
}

class Axepta_BNPP_Refund_Process
{
    public static function handle_refund($order_id, $amount = null) {
        $order = wc_get_order($order_id);
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $merchantId = Axepta_BNPP_Helper::getMerchantId();

        if (!$order) {
            return new WP_Error('order_not_found', 'Commande introuvable');
        }

        if($amount <= 0) {
            return new WP_Error('invalid_amount', __('Veuillez renseigner le montant à rembourser', 'axepta-bnp-paribas'));
        }

        if($order->get_status() === Axepta_BNPP_Constant::CAPTURE_PENDING && $order->get_total() > $amount) {
            return new WP_Error('invalid_amount', __("Le remboursement partiel de cette commande n'est pa possible, seul un remboursement total est autorisé", 'axepta-bnp-paribas'));
        }

        if($order->get_status() === 'cancelled' || (float) $order->get_total_refunded() > $order->get_total()) {
            return new WP_Error('order_cancelled', __('La commande a déjà été annulée ', 'axepta-bnp-paribas'));
        }

        if($order->get_status() === 'refunded' || (float) $order->get_total_refunded() > $order->get_total()) {
            return new WP_Error('order_fully_refunded', __('La commande a déjà été entièrement remboursée ', 'axepta-bnp-paribas'));
        }

        $transaction = Axepta_BNPP_Transaction::get_by_trans_id($order->get_transaction_id());
        if($transaction && $transaction->transaction_type === Axepta_BNPP_Constant::SIMPLE_PAYMENT && $transaction->pay_id) {
            $refund_amount = $amount > 0 ? $amount : $order->get_total();
            $payment_id = $transaction->pay_id;
            $payment_mode = mb_strtoupper(get_option('axepta_settings')['axepta_mode']);
            $name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $trigram = 'cvm';

            $service = new Axepta_Bnpp_Api_Service();
            $paymentDetail = $service->getPaymentDetails($payment_id, $payment_mode, $merchantId, $apiKey);
            if(isset($paymentDetail['status']) && $paymentDetail['status'] === 'failled') {
                return new WP_Error('invalid_transaction', __('La transaction n\a pas eu lieu', 'axepta-bnp-paribas'));
            }

            $transaction_type = OperationType::PAYMENT_REFUND;
            $new_amount = $transaction->amount;
            $order_status = 'refunded';
            if($transaction->capture_mode === 'manuel' && isset($paymentDetail['amount']['capturedValue']) && $paymentDetail['amount']['capturedValue'] <= 0) {
                $transaction_type = OperationType::PAYMENT_REVERSAL;
                $new_amount = $transaction->amount - $amount;
                $order_status = 'cancelled';
            }

            if($transaction_type === OperationType::PAYMENT_REVERSAL && $amount < $order->get_total()) {
                return new WP_Error('invalid_amount', __("Le remboursement partiel de cette commande n'est pa possible, seul un remboursement total est autorisé", 'axepta-bnp-paribas'));
            }
                
            $response = $service->refundPayment(
                $merchantId, 
                $apiKey, 
                $transaction->pay_id, 
                $payment_mode, 
                $refund_amount*100, 
                $order->get_currency(), 
                $order->get_billing_country(), 
                $order->get_transaction_id(), 
                $trigram, 
                $order->get_id(), 
                $order->get_id(), 
                get_bloginfo('name'), 
                $name, 
                $order->get_billing_city(), 
                $transaction_type
            );
            $response = json_decode($response, true);

            if (isset($response['status']) && $response['status'] === 'OK' && isset($response['payId']) && $response['payId'] !== '00000000000000000000000000000000' && !empty($response['transId'])) {
                $transaction->raw_data = json_encode($response);
                $transaction->captured = null;
                $transaction->amount = $refund_amount;

                $order->add_order_note(sprintf(__('Remboursement de %s effectué via Axepta BNP Paribas.', 'axepta-bnp-paribas'), wc_price($refund_amount)));
                if((float) $order->get_total_refunded() >= $order->get_total()) {
                    $order->update_status($order_status);
                } else {
                    $order->update_status('processing');
                }
                $order->save();

                $result = Axepta_BNPP_Transaction::add_transaction($transaction, $transaction_type);
                if ($result === false) {
                    return new WP_Error('refund_failed', __('Le remboursement a réussi mais le stockage dans la bdd a échoué', 'axepta-bnp-paribas'));
                }

                if($transaction_type === OperationType::PAYMENT_REVERSAL) {
                    $capture_mode = $new_amount > 0 ? 'manuel' : '';
                    $updated = Axepta_BNPP_Transaction::update_transaction_captured_mode($transaction->transaction_id, $capture_mode, null, $new_amount);
                    if(!$updated) {
                        return new WP_Error('refund_failed', __('Le remboursement a réussi mais le changement de statut de la transaction non capturé a échoué', 'axepta-bnp-paribas'));
                    }
                }
                return true;
            } else {
                $error_message = __("Echec de remboursement", 'axepta-bnp-paribas') . (isset($response['description']) ? $response['description'] : '');
                return new WP_Error('refund_failed', $error_message);
            }
        } else {
            return new WP_Error('invalid_transaction', __('Transaction invalide', 'axepta-bnp-paribas'));
        }
    }
}