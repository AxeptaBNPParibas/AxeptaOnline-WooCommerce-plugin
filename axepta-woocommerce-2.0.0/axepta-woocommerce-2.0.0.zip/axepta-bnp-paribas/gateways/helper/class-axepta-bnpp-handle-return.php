<?php

if (!defined('ABSPATH')) exit;

use AxeptaPaygate\Core\OperationType;
class Axepta_BNPP_Handle_Return
{
    # Handle payment success/failure
    public static function handle_api_return($payId, $order_id=null) 
    {
        $apiKey = Axepta_BNPP_Helper::getApiKey();
        $merchantId = Axepta_BNPP_Helper::getMerchantId();
        $mode = get_option('axepta_settings')['axepta_mode'];
        
        $service = new Axepta_Bnpp_Api_Service();
        $response = $service->getPaymentDetails($payId, Axepta_BNPP_Helper::getPaymentMode(), $merchantId, $apiKey);
        
        if(empty($response) || !isset($response['transId'])) {
            wc_add_notice(__('Erreur lors de la récupération des détails du paiement.', 'axepta-bnp-paribas'), 'error');
            return;
        }

        // update transaction with api response data
        $transaction = Axepta_BNPP_Transaction::update_transaction_from_api_response($response);
        if(!$transaction || $transaction === false) {
            wc_add_notice(__('Erreur lors du mise à jour de la transaction', 'axepta-bnp-paribas'), 'error');
            return;
        }

        $order = wc_get_order($order_id ?? (isset($transaction->order_id) ? (int) $transaction->order_id : 0));
        self::handle_order($order, $response['transId'], $response['responseCode'] ?? '', $mode, $transaction->capture_mode ?? null);

        // Save card
        self::save_user_card($order, $response['paymentMethods']);

        self::handle_redirect($order);
        
        return [
            'order' => $order, 
            'payId' => $payId, 
            'transaction' => $transaction 
        ];
    }

    # handle order
    public static function handle_order(WC_Order $order, string $transactionId, string $responseCode, string $mode = 'demo', ?string $capture_mode=null) {
        if(!$order) {
            wc_add_notice(__('Commande non trouvée.', 'axepta-bnp-paribas'), 'error');
            return;
        }

        $order->set_transaction_id($transactionId);
        if ($responseCode === '00000000') {
            $order_status = $mode === 'production' && $capture_mode === 'manuel' ? Axepta_BNPP_Constant::CAPTURE_PENDING
                : ($mode === 'demo' ? Axepta_BNPP_Constant::DEMO_OK : ($mode === 'test' ? Axepta_BNPP_Constant::TEST_OK : 'processing'));
            
            $update_status_note = $mode === 'production' && $capture_mode !== 'auto' ? 'Capture paiement en attente' 
                : ($mode === 'demo' ? 'Paiement accepté en mode DEMO' : ($mode !== 'auto' ? 'Paiement accepté en mode TEST' : 'Statut de la commande mis à jour'));

            $order->payment_complete($transactionId);
            $order->update_status($order_status, $update_status_note);
            $order->add_order_note(__('Paiement réussi avec succès via Axepta BNP Paribas', 'axepta-bnp-paribas'));
            $order->update_meta_data( '_capture_status', $capture_mode === 'auto' ? 'Capturé' : 'Non Capturé');
            $order->save();

            wc_add_notice(__('Votre paiement a été effectué avec succès et la commande est validée.', 'axepta-bnp-paribas'), 'success');
        } else {
            if ($mode === 'test') {
                $order->update_status(Axepta_BNPP_Constant::TEST_FAIL, __('Paiement échoué en mode TEST', 'axepta-bnp-paribas'));
            } else {
                $order->update_status('failed', __('Echec de paiement', 'axepta-bnp-paribas'));
            }
            
            wc_add_notice(__('Le paiement a échoué et la commande est rejetée', 'axepta-bnp-paribas'), 'error');
        }
    }

    public static function has_subscription_product(WC_Order $order): bool
    {
        /** @var WC_Order_Item_Product $item */
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            
            if ('subscription' === get_post_meta($product->get_id(), '_axepta_product_type', true)) {
                return true;
            }
        }

        return false;
    }

    public static function save_user_card(WC_order $order, array $response) {
        if(get_user_meta($order->get_user_id(), '_axepta_save_card', true) !== 'yes' ) return false;
        
        $trigram = $response['CCBrand'] === 'AMEX' ? 'AMX' : ($response['CCBrand'] === 'PAYPAL' ? 'PAL' : 'VIM');
        $data_card = [
            'customer_id' => $order->get_user_id(),
            'ccexpiry' => $response['expiryDate'],
            'ccbrand' => $response['brand'],
            'pcnr' => $response['PCNr'],
            'number' => $response['card']['number'],
            'trigram' => $trigram,
        ];

        $insert_result = Axepta_BNPP_OneClick::insert_card($data_card);
        if($insert_result) {
            wc_add_notice(__('Carte enregistrée avec succès', 'axepta-bnp-paribas'), 'success');
        } else {
            wc_add_notice(__('Échec de l\'enregistrement de la carte', 'axepta-bnp-paribas'), 'error');
        }
        return $insert_result;
    }

    public static function handle_redirect(WC_Order $order, $url = null) {
        $account = get_option('axepta_settings', []);

        if ($account['axepta_display_mode'] === 'iframe') {
            $redirect_url = $url ?? $order->get_checkout_order_received_url();
            echo '<script type="text/javascript">';
            echo 'if (window.top.location.href !== "' . esc_url($redirect_url) . '") {';
            echo '  window.top.location.href = "' . esc_url($redirect_url) . '";';
            echo '}';
            echo '</script>';
            echo '<p>' . __('Votre paiement a été effectué avec succès. Si vous n\'êtes pas redirigé automatiquement, <a href="' . esc_url($redirect_url) . '">cliquez ici</a>.', 'axepta-bnp-paribas') . '</p>';
            exit;
        }
    }
    
}
