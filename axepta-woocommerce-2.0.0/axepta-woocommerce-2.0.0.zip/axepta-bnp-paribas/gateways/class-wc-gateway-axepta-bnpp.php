<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Axepta BNP Paribas WooCommerce Payment Gateway
 *
 * Handles payments and tokenization via Axepta.
 */
class WC_Gateway_Axepta_BNPP extends WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'axepta_bnpp_gateway';
        $this->method_title = __('Axepta BNP Paribas', 'axepta-bnp-paribas');
        $this->method_description = __('Secure payments through Axepta BNP Paribas.', 'axepta-bnp-paribas');
        $this->has_fields = false;
        $this->icon = AXEPTA_BNPP_PLUGIN_URL . 'assets/img/icon-bnp.jpg';
        $this->supports = ['products', 'refunds', 'tokenization'];

        // Load settings
        $this->init_form_fields();
        $this->init_settings();

        // Load options from settings
        $this->title       = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled     = $this->get_option('enabled', 'yes');

        // Hooks
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('woocommerce_api_' . strtolower(get_class($this)), [$this, 'handle_return']);

		add_action('init', [Axepta_BNPP_Payment_Process::class, 'register_rewrite_rule']);
		add_filter('query_vars', [Axepta_BNPP_Payment_Process::class, 'register_query_vars']);
		add_action('template_redirect', [Axepta_BNPP_Payment_Process::class, 'handle_iframe_page']);

        add_action('woocommerce_before_thankyou', function () {
            wc_print_notices(); 
        }, 1);
    }

    /**
     * Define admin form fields for gateway settings
     */
    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable', 'axepta-bnp-paribas'),
                'type'    => 'checkbox',
                'label'   => __('Enable Axepta BNP Paribas gateway', 'axepta-bnp-paribas'),
                'default' => 'yes',
            ],
            'title' => [
                'title'       => __('Title', 'axepta-bnp-paribas'),
                'type'        => 'text',
                'description' => __('Title shown to the customer during checkout.', 'axepta-bnp-paribas'),
                'default'     => __('Pay with Axepta We+', 'axepta-bnp-paribas'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'axepta-bnp-paribas'),
                'type'        => 'textarea',
                'default'     => __('You will be redirected to Axepta to complete your payment.', 'axepta-bnp-paribas'),
            ],
        ];
    }

    /**
     * Check if the gateway is available
     */
    public function is_available()
    {
        if ('yes' !== $this->enabled) {
            return false;
        }

        return parent::is_available();
    }

    /**
     * Process the payment and redirect to external gateway
     *
     * @param int $order_id
     * @return array
     */
    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);

        if (!$order) {
            wc_add_notice(__('Commande non trouvée.', 'axepta-bnp-paribas'), 'error');
            return ['result' => 'failure'];
        }

        $response = Axepta_BNPP_Payment_Process::create_payment_request($order, $_POST);
        if($response['result'] === 'failure') {
            Axepta_Bnpp_Log::debug('Données envoyées => ', ['response' => $response]);
            wc_add_notice(__('Erreur serveur', 'axepta-bnp-paribas'), 'error');
            return ['result' => 'failure'];
        }
        return $response;
    }

    // Refund user
    public function process_refund($order_id, $amount = null, $reason = '') {
        return Axepta_BNPP_Refund_Process::handle_refund($order_id, $amount, $reason);
    }

    public function handle_return() {
        $data = array_merge($_POST, $_GET);
        $payId = isset($data['PayID']) ? sanitize_text_field($data['PayID']) : '';
        $order_id = isset($data['order_id']) ? sanitize_text_field($data['order_id']) : null;
        
        if(!$payId) {
            wc_add_notice(__('Erreur lors de la récupération des détails du paiement.', 'axepta-bnp-paribas'), 'error');
            wp_redirect(wc_get_cart_url());
            exit;
        }

        $response = Axepta_BNPP_Handle_Return::handle_api_return($payId, $order_id);
        if (!$response || !isset($response['order'])) {
            wc_add_notice(__('Erreur lors du traitement du paiement.', 'axepta-bnp-paribas'), 'error');
            wp_redirect(wc_get_cart_url());
            exit;
        }

        wp_redirect($this->get_return_url($response['order']));
        exit;
    }
	
	/**
	 * Handle the notification from the payment gateway
	 */
	public function handle_notification() {
		// TODO: handle notification
	}
}
new WC_Gateway_Axepta_BNPP();