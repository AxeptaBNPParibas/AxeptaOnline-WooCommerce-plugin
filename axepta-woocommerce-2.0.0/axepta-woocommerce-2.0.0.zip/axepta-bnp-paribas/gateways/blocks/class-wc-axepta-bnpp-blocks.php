<?php

if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class WC_Gateway_Axepta_Bnpp_Blocks extends AbstractPaymentMethodType
{
    protected $name = 'axepta_bnpp_gateway';

    # initialize blocks
    public function initialize() {
        $this->settings = get_option('woocommerce_axepta_bnpp_settings', []);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_block_scripts'], 100);
    }

    # enqueue block scripts
    public function get_payment_method_script_handles() {
        wp_register_script(
            'axepta-blocks-integration',
            AXEPTA_BNPP_PLUGIN_URL . 'assets/js/blocks.js',
            ['wp-element', 'wp-i18n', 'wp-html-entities', 'wc-blocks-registry'],
            '1.0.0',
            true
        );

        wp_localize_script('axepta-blocks-integration', 'axepta_blocks_params', $this->get_axepta_blocks_params());
		wp_set_script_translations('axepta-blocks-integration', 'axepta-bnp-paribas', AXEPTA_BNPP_PLUGIN_PATH . 'languages');

        return ['axepta-blocks-integration'];
    }

    # enqueue block styles
    public function enqueue_block_scripts() {
        wp_enqueue_style(
            'axepta-blocks-style',
            AXEPTA_BNPP_PLUGIN_URL . 'assets/css/blocks.css',
            [],
            '1.0.0'
        );
    }

    # return axepta blocks params for checkout
    public function get_axepta_blocks_params() {
        $axepta_settings = get_option('axepta_settings', []);
        return [
            'site_url' => get_site_url(),
            'rest_url' => esc_url_raw(get_rest_url(null, 'axepta/v1/')),
            'axepta_settings' => $axepta_settings,
            'current_user_id' => get_current_user_id(),
            'title' => $this->settings['title'] ?? __('Carte Bancaire (Axepta)', 'axepta-bnp-paribas'),
            'description' => $this->settings['description'] ?? __('Vous serez redirigé vers Axepta pour finaliser votre paiement.', 'axepta-bnp-paribas'),
            'demo_message' => __('Vous êtes en mode ' . strtoupper($axepta_settings['axepta_mode']), 'axepta-bnp-paribas'),
            'payment_methods' => $axepta_settings && isset( $axepta_settings['axepta_payment_methods']) ? $axepta_settings['axepta_payment_methods'] : [],
        ];
    }
}