<?php
global $wpdb;
$post_id = $post->ID;

// get subscription data
$subscription_data = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$wpdb->prefix}axepta_bnpp_subscription_product WHERE id_product = %d", $post_id)
);

// Set default values
$type = $subscription_data ? ($subscription_data->type == 2 ? 'subscription' : 'simple') : 'simple';
$period = $subscription_data ? $subscription_data->periodicity : 'month';
$amount = $subscription_data ? $subscription_data->recurring_amount : 0;
$frequency_text = $subscription_data && $subscription_data->number_periodicity > 0 ? $subscription_data->number_periodicity : 1;
$number_occurences = $subscription_data ? $subscription_data->number_occurences : 0;
$expires_after = $number_occurences == 0 ? 'never' : (in_array($number_occurences, [2, 3, 4]) ? $number_occurences : 'custom');
$custom_cycles = ($expires_after === 'custom') ? $number_occurences : 12;

$reassurance_message = '';
if ($type === 'subscription') {
    $period_label = $period === 'week' ? __('semaine(s)', 'axepta-bnp-paribas') : ($period === 'month' ? __('mois', 'axepta-bnp-paribas') : __('année(s)', 'axepta-bnp-paribas'));
    $cycles = ($expires_after === 'never') ? __('jamais', 'axepta-bnp-paribas') : ($expires_after === 'custom' ? $custom_cycles : $expires_after);
    $reassurance_message = sprintf(
        // translators: %1$s is the billing amount, %2$s is the billing period (e.g., month), %3$s is the number of billing cycles, %4$s is the expiration count, %5$s is the expiration period (e.g., months)
        __('Vos clients seront facturés %1$s par %2$s pendant %3$s cycle(s) de facturation. Leur abonnement expirera après %4$s %5$s.', 'axepta-bnp-paribas'),
        wc_price($amount ?: 0),
        $period_label,
        $cycles,
        $cycles,
        $period_label
    );
    $reassurance_message .= __("NB, si abonnement configuré sur 10 mois la première transaction est incluse, il reste 9 Cycles.", 'axepta-bnp-paribas');
}
?>

<style>
    .container {
        max-width: 90vw;
        margin: 0 3%;
    }
    .form-group {
        margin-bottom: 15px;
        display: flex;
        gap: 5rem;
    }
    .form-group label {
        width: 10%;
        padding: 6px;
        font-size: 14px;
        color: #212121;
        font-weight: 600;
        font-family: inter;
        text-align: end !important;
    }
    .form-group input,
    .form-group select {
        padding: 6px;
        width: 80%;
    }
    .hidden {
        display: none;
    }
    .reassurance {
        color: #555;
        padding: 10px;
        margin-top: 20px;
        font-weight: 600;
        border-radius: 5px;
        font-style: italic;
        background-color:rgb(175, 255, 237);
    }
</style>

<div class="container">
    <input type="hidden" name="post_ID" value="<?php echo esc_attr($post->ID); ?>">
    <div class="form-group" id="productType">
        <label for="axepta_subscription_type"><?php _e('Type de produit', 'axepta-bnp-paribas'); ?></label>
        <select name="axepta_subscription_type" id="axepta_subscription_type" required>
            <option value="simple" <?php selected($type, 'simple'); ?>><?php _e('Simple', 'axepta-bnp-paribas'); ?></option>
            <option value="subscription" <?php selected($type, 'subscription'); ?>><?php _e('Abonnement', 'axepta-bnp-paribas'); ?></option>
        </select>
    </div>

    <div class="subscription-field <?php echo $type !== 'subscription' ? 'hidden' : ''; ?>" id="subscriptionField">
        <div class="form-group">
            <label for="axepta_subscription_frequency_text"><?php _e('Se répète chaque', 'axepta-bnp-paribas'); ?></label>
            <input type="number" id="axepta_subscription_frequency_text" name="axepta_subscription_frequency_text" value="<?php echo esc_attr($frequency_text); ?>" min="0" max="50">
        </div>

        <div class="form-group">
            <label for="axepta_subscription_period"><?php _e('Périodicité', 'axepta-bnp-paribas'); ?></label>
            <select name="axepta_subscription_period" id="axepta_subscription_period" required>
                <option value="week" <?php selected($period, 'week'); ?>><?php _e('Semaines', 'axepta-bnp-paribas'); ?></option>
                <option value="month" <?php selected($period, 'month'); ?>><?php _e('Mois', 'axepta-bnp-paribas'); ?></option>
                <option value="year" <?php selected($period, 'year'); ?>><?php _e('Années', 'axepta-bnp-paribas'); ?></option>
            </select>
        </div>

        <div class="form-group">
            <label for="axepta_subscription_expires_after"><?php _e('Expire après', 'axepta-bnp-paribas'); ?></label>
            <select name="axepta_subscription_expires_after" id="axepta_subscription_expires_after" required>
                <option value="never" <?php selected($expires_after, 'never'); ?>><?php _e('N\'expire jamais', 'axepta-bnp-paribas'); ?></option>
                <option value="2" <?php selected($expires_after, '2'); ?>><?php _e('2 cycles de facturation', 'axepta-bnp-paribas'); ?></option>
                <option value="3" <?php selected($expires_after, '3'); ?>><?php _e('3 cycles de facturation', 'axepta-bnp-paribas'); ?></option>
                <option value="4" <?php selected($expires_after, '4'); ?>><?php _e('4 cycles de facturation', 'axepta-bnp-paribas'); ?></option>
                <option value="custom" <?php selected($expires_after, 'custom'); ?>><?php _e('Personnalisé', 'axepta-bnp-paribas'); ?></option>
            </select>
        </div>

        <div class="form-group <?php echo $expires_after !== 'custom' ? 'hidden' : ''; ?>" id="axepta_subscription_billing_cycle_group">
            <label for="axepta_subscription_billing_cycle"><?php _e('Cycle de facturation', 'axepta-bnp-paribas'); ?></label>
            <input type="number" id="axepta_subscription_billing_cycle" name="axepta_subscription_billing_cycle" value="<?php echo esc_attr($custom_cycles); ?>" min="1" max="999">
        </div>

        <div class="form-group">
            <label for="axepta_subscription_amount"><?php _e('Montant récurrent', 'axepta-bnp-paribas'); ?></label>
            <input type="number" step="0.01" id="axepta_subscription_amount" name="axepta_subscription_amount" value="<?php echo esc_attr($amount); ?>" min="0.00">
        </div>

        <?php if ($reassurance_message) : ?>
            <div class="reassurance"><?php echo wp_kses_post($reassurance_message ?: ''); ?></div>
        <?php endif; ?>
    </div>
    <?php wp_nonce_field('axepta_subscription_save_' . $post->ID, 'axepta_subscription_nonce'); ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const productType = document.getElementById('axepta_subscription_type');
    const subscriptionField = document.getElementById('subscriptionField');
    const expiresAfter = document.getElementById('axepta_subscription_expires_after');
    const billingCycleGroup = document.getElementById('axepta_subscription_billing_cycle_group');
    const frequencyInput = document.getElementById('axepta_subscription_frequency_text');
    const amountInput = document.getElementById('axepta_subscription_amount');
    const billingCycleInput = document.getElementById('axepta_subscription_billing_cycle');

    function toggleSubscriptionFields() {
        subscriptionField.classList.toggle('hidden', productType.value !== 'subscription');
    }

    function toggleBillingCycle() {
        billingCycleGroup.classList.toggle('hidden', expiresAfter.value !== 'custom');
    }

    function validateInputs() {
        if (productType.value === 'subscription') {
            frequencyInput.required = true;
            amountInput.required = true;
            if (frequencyInput.value < 1 || frequencyInput.value > 50) {
                frequencyInput.setCustomValidity('<?php _e('Saisissez un nombre entier entre 1 et 50', 'axepta-bnp-paribas'); ?>');
            } else {
                frequencyInput.setCustomValidity('');
            }

            if (amountInput.value <= 0) {
                amountInput.setCustomValidity('<?php _e('Le montant doit être supérieur à 0', 'axepta-bnp-paribas'); ?>');
            } else {
                amountInput.setCustomValidity('');
            }

            if (expiresAfter.value === 'custom') {
                billingCycleInput.required = true;
                if (billingCycleInput.value < 0 || billingCycleInput.value > 999) {
                    billingCycleInput.setCustomValidity('<?php _e('Les abonnements peuvent comporter jusqu’à 999 cycles', 'axepta-bnp-paribas'); ?>');
                } else {
                    billingCycleInput.setCustomValidity('');
                }
            } else {
                billingCycleInput.required = false;
                billingCycleInput.setCustomValidity('');
            }
        } else {
            frequencyInput.required = false;
            amountInput.required = false;
            billingCycleInput.required = false;
            frequencyInput.setCustomValidity('');
            amountInput.setCustomValidity('');
            billingCycleInput.setCustomValidity('');
        }
    }

    productType.addEventListener('change', function () {
        toggleSubscriptionFields();
        validateInputs();
    });
    expiresAfter.addEventListener('change', function () {
        toggleBillingCycle();
        validateInputs();
    });
    frequencyInput.addEventListener('input', validateInputs);
    amountInput.addEventListener('input', validateInputs);
    billingCycleInput.addEventListener('input', validateInputs);

    toggleSubscriptionFields();
    toggleBillingCycle();
    validateInputs();
});
</script>
