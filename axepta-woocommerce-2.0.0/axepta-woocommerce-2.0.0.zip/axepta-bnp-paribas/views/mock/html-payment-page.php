<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php esc_html_e('Paiement', 'axepta-bnp-paribas'); ?></title>
    
    <style>
        body {
            width: 100vw !important;
            margin: auto;
            padding: 20px;
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        }
        header { position: absolute; top: 0; left: 0; width: 100%; height: 100px; background: #f5f5f5; }
        .order-summary {
            width: 90%;
            margin: 20px auto;
        }
        header table {
            width: 100%;
            border-collapse: collapse;
        }
        header th, header td {
            border: 1px solid #ccc;
            padding: 5px;
        }
        header th {
            background-color: #f5f5f5;
            text-align: left;
        }
        .iframe {
            width: 90%;
            height: 100vh;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style> 
</head>
<body>
    <header>
        <div class="order-summary">
            <h3><?php esc_html_e('Résumé de la commande', 'axepta-bnp-paribas'); ?></h3>
            <table>
                <thead>
                    <tr>
                        <th><?php esc_html_e('ID commande', 'axepta-bnp-paribas'); ?></th>
                        <th><?php esc_html_e('Produits', 'axepta-bnp-paribas'); ?></th>
                        <th><?php esc_html_e('Date', 'axepta-bnp-paribas'); ?></th>
                        <th><?php esc_html_e('Client', 'axepta-bnp-paribas'); ?></th>
                        <th><?php esc_html_e('Total', 'axepta-bnp-paribas'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo sprintf(esc_html__('Commande #%s', 'axepta-bnp-paribas'), esc_html($order_id)); ?></td>
                        <td><?php echo $product_summary; ?></td>
                        <td><?php echo esc_html($order_date); ?></td>
                        <td><?php echo esc_html($customer_name); ?></td>
                        <td><?php echo esc_html($order_total); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </header>

    <div class="iframe">
        <iframe src="<?php echo esc_url($iframe_src); ?>" frameborder="0" style="width: 100%; height: 100%; margin: auto auto; border: none;" sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-orientation-lock allow-pointer-lock allow-presentation allow-top-navigation"></iframe>
    </div> 
</body>
</html>