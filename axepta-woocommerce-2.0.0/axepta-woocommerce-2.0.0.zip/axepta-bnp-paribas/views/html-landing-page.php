<?php
/**
 * Axepta BNP Paribas Admin Settings Page
 *
 * This file renders the admin settings page for the Axepta BNP Paribas plugin.
 */

$axepta_releases = Axepta_BNPP_Helper::get_releases();
$account = get_option('axepta_settings', []);

$custom_logo_id = get_theme_mod('custom_logo');
$logo_url = $custom_logo_id ? wp_get_attachment_image_url($custom_logo_id, 'full') : 'Url du logo';
?>

<script>
    window.siteLogo = '<?= $logo_url ?>';
    window.axeptaAccount = <?= json_encode($account); ?>;
    window.pluginPath = '<?= AXEPTA_BNPP_PLUGIN_URL; ?>';
    window.releases = <?= json_encode($axepta_releases); ?>; 
    window.axeptaConfig = {
        downloadLogsNonce: '<?= wp_create_nonce('axepta_download_logs'); ?>'
    };
</script>

<div class="wrap axepta-container" id="axepta-landing-page">
    <!-- Demo/Test Banner -->
    <div class="axepta-banner-demo" id="axepta-banner-demo"></div>

    <div class="axepta-header">
        <div class="axepta-header-left">
            <img src="<?= AXEPTA_BNPP_PLUGIN_URL . 'assets/img/bnp-axepta-logo.png'; ?>" alt="<?= esc_attr__('Logo Axepta', 'axepta-bnp-paribas'); ?>">
            <p class="version" id="open-versionning-modal"> <?= __('Version ', 'axepta-bnp-paribas') . AXEPTA_BNPP_VERSION; ?></p>
        </div>

        <div class="axepta-header-right">
            <p class="axepta-description"><?= __("Axepta BNP Paribas offre une solution de paiement en ligne sécurisée, permettant aux commerçants d'accepter facilement les paiements par carte via leur site e-commerce, avec des technologies avancées pour une expérience utilisateur fluide et sécurisée.", 'axepta-bnp-paribas'); ?></p>

            <div class="axepta-buttons">
                <a href="https://docs.axepta.bnpparibas/pages/viewpage.action?pageId=4653268" class="axepta-btn axepta-btn-1" target="_blank"><?= __('Documentation Axepta BNP Paribas', 'axepta-bnp-paribas'); ?></a>
                <button class="axepta-btn axepta-btn-2" id="open-config-modal"><?= __('Testez ma configuration', 'axepta-bnp-paribas'); ?></button>
                <a href="#open-support-form" class="axepta-btn axepta-btn-1" id="open-support-form"><?= __("Contactez l'assistance", 'axepta-bnp-paribas'); ?></a>
                <button class="axepta-btn axepta-btn-2" id="download-logs"><?= __('Téléchargez le fichier LOG', 'axepta-bnp-paribas'); ?></button>
            </div>
        </div>
    </div>

    <!-- LANDING PAGE CONTENT (ACCORDEON) -->
    <div class="axepta-accordion">
        <!-- Account Setup -->
        <div class="axepta-accordion-item">
            <div class="d-flex content-between">
                <h3 class="axepta-section axepta-accordion-header" id="axepta-account-configId" data-target="#axepta-account-config">
                    <span class="dashicons dashicons-arrow-right-alt2 toggle-icon" style="vertical-align:middle;margin-right:8px;"></span>
                    <?php echo __('Configuration du compte', 'axepta-bnp-paribas'); ?>
                </h3>
            </div>
            <div id="axepta-account-config" class="axepta-accordion-content" style="display: none;">
                <div>
                    <div class="axepta-config-mode-section">
                        <div>
                            <select name="axepta_mode" id="axepta_mode" class="axepta-select">
                                <option value="demo" <?php selected($account['axepta_mode'], 'demo'); ?>><?php echo __('Démo', 'axepta-bnp-paribas'); ?></option>
                                <option value="test" <?php selected($account['axepta_mode'], 'test'); ?>><?php echo __('Test', 'axepta-bnp-paribas'); ?></option>
                                <option value="production" <?php selected($account['axepta_mode'], 'production'); ?>><?php echo __('Production', 'axepta-bnp-paribas'); ?></option>
                            </select>
                        </div>
                        <div id="axepta-mode-test-field">
                            <p class="d-flex axepta-alert">
                                <span class="dashicons dashicons-info-outline"></span>
                                <span style="padding-left: 10px;"><?php echo __("Le mode démo du plugin Axepta BNP Paribas permet aux développeurs de tester l'intégration des paiements en ligne sans nécessiter un compte actif. En utilisant des cartes de test, on peut simuler des transactions pour vérifier le bon fonctionnement du système, assurant une mise en œuvre sécurisée et efficace avant le lancement.", 'axepta-bnp-paribas'); ?></span>
                            </p>
                        </div>
                    </div>

                    <!-- Dynamic fields (test, prod) -->
                    <div id="axepta-mode-fields"></div>

                    <label for="axepta_enabled" class="switch">
                        <span class="switch-text"><?php echo __('Activé', 'axepta-bnp-paribas'); ?></span>
                        <input type="checkbox" name="axepta_enabled" id="axepta_enabled" value="1" <?php checked($account['axepta_enabled'], '1'); ?>>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
        </div>

        <!-- Payment setup -->
        <div class="axepta-accordion-item">
            <h3 class="axepta-section axepta-accordion-header" data-target="#axepta-payment-methods">
                <span class="dashicons dashicons-arrow-right-alt2 toggle-icon" style="vertical-align:middle;margin-right:8px;"></span>
                <?php echo __('Configuration des moyens de paiement', 'axepta-bnp-paribas'); ?>
            </h3>
            <div id="axepta-payment-methods" class="axepta-accordion-content" style="display: none;">
                <div>
                    <fieldset class="axepta-payment-section">
                        <div class="d-flex content-between">
                            <div class="">
                                <label for="axepta_payment_layout" class="axepta-label"><?php echo __('Organisation des moyens de paiement', 'axepta-bnp-paribas'); ?></label>
                                <select name="axepta_payment_layout" id="axepta_payment_layout">
                                    <option value="hpp" <?php selected($account['axepta_payment_layout'], 'hpp'); ?>><?php echo __("Choix du moyen de paiement sur la page Axepta BNP Paribas", 'axepta-bnp-paribas'); ?></option>
                                    <option value="regroupe" <?php selected($account['axepta_payment_layout'], 'regroupe'); ?>><?php echo __("Choix du moyen de paiement sur le site du marchand", 'axepta-bnp-paribas'); ?></option>
                                </select>
                            </div>
                            <div id="axepta-payment-front-label"></div>
                        </div>

                        <div class="" id="axepta-payment-group-fields"></div>
                    </fieldset>

                    <fieldset class="axepta-payment-section">
                        <div class="axepta-subtitle"><?php echo __('Personnalisation', 'axepta-bnp-paribas'); ?></div>

                        <?php
                        $switches = [
                            'logo' => __('Afficher le logo sur la page de paiement', 'axepta-bnp-paribas'),
                            'cart' => __('Afficher le récap du panier', 'axepta-bnp-paribas'),
                            'saller' => __("Afficher le détail de l'acheteur", 'axepta-bnp-paribas'),
                            'delivery' => __("Afficher l'adresse de livraison", 'axepta-bnp-paribas'),
                            'billing' => __("Afficher l'adresse de facturation", 'axepta-bnp-paribas'),
                            'title' => __("Afficher un titre personnalisé", 'axepta-bnp-paribas'),
                            'text' => __("Afficher un texte personnalisé", 'axepta-bnp-paribas'),
                        ];

                        foreach ($switches as $key => $label) {
                            $id = "axepta_display_$key";
                            $val = !empty($account[$id]) ? $account[$id] : '0';
                            ?>
                            <div class="">
                                <label for="<?php echo $id; ?>" class="switch">
                                    <span class="switch-text"><?php echo $label; ?></span>
                                    <input type="checkbox" name="<?php echo $id; ?>" id="<?php echo $id; ?>" value="<?php echo $val; ?>" <?php checked($val, '1'); ?> onchange="axeptaToggleSwitch(this, '<?php echo $key; ?>')">
                                    <span class="slider"></span>
                                </label>
                                <?php
                                if ($key === 'logo') {
                                    echo '<div id="logo_url"></div>';
                                } elseif ($key === 'title') {
                                    echo '<div id="custom_title"></div>';
                                } elseif ($key === 'text') {
                                    echo '<div id="custom_text"></div>';
                                }
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <!-- features setup (1-click payment, 3D Secure, Subscription payment ) -->
        <div class="axepta-accordion-item">
            <h3 class="axepta-section axepta-accordion-header" data-target="#axepta-features">
                <span class="dashicons dashicons-arrow-right-alt2 toggle-icon" style="vertical-align:middle;margin-right:8px;"></span>
                <?php echo __('Configuration des fonctionnalités', 'axepta-bnp-paribas'); ?>
            </h3>
            
            <div id="axepta-features" class="axepta-accordion-content" style="display: none;">
                <div class="axepta-features-form">
                    <h3> <?php echo __('Les modes de capture', 'axepta-bnp-paribas'); ?> <span title="text" class="dashicons dashicons-info-outline"></span> </h3>
                    <fieldset>
                        <label class="switch-text"><?php echo __('Mode de capture', 'axepta-bnp-paribas'); ?></label>
                        <select name="axepta_capture_mode" id="axepta_capture_mode"
                            onchange="axeptaCaptureModeChanged(this.value);">
                            <option value="auto" <?php selected($account['axepta_capture_mode'], 'auto'); ?>><?php echo __('Automatique', 'axepta-bnp-paribas'); ?></option>
                            <option value="manuel" <?php selected($account['axepta_capture_mode'], 'manuel'); ?>><?php echo __('Manuelle', 'axepta-bnp-paribas'); ?></option>
                            <option value="deferred" <?php selected($account['axepta_capture_mode'], 'deferred'); ?>><?php echo __('Différée', 'axepta-bnp-paribas'); ?></option>
                        </select>

                        <div id="axepta_manual_capture_notice" style="display: <?php echo $account['axepta_capture_mode'] === 'manuel' ? 'block' : 'none'; ?>; margin-top: 10px;">
                            <div class="axepta-alert" style="margin-bottom: 10px;">
                                <span class="dashicons dashicons-bell"></span> <?php echo __('Important :', 'axepta-bnp-paribas'); ?>
                                <span><?php echo __('Perte de l\'authentification au bout de 7 jours et l\'autorisation au bout de 29 jours', 'axepta-bnp-paribas'); ?></span>
                            </div>
                            <label for="axepta_manual_capture_notify" class="switch" style="margin-bottom: 10px;">
                                <span class="switch-text"><?php echo __('Activer les notifications', 'axepta-bnp-paribas'); ?></span>
                                <input type="checkbox" name="axepta_manual_capture_notify" id="axepta_manual_capture_notify"
                                    value="1" <?php checked($account['axepta_manual_capture_notify'], '1'); ?>
                                    onchange="axeptaToggleManualCaptureEmail(this.checked);">
                                <span class="slider"></span>
                            </label>
                            <div id="axepta_manual_capture_email_wrap" style="margin-top: 10px; <?php echo get_option('axepta_manual_capture_notify') === '1' && $account['axepta_capture_mode'] === 'manuel' ? 'display:block;' : 'display:none;'; ?>">
                                <label for="axepta_manual_capture_email" class="switch-text"><?php echo __('Adresse e-mail à notifier', 'axepta-bnp-paribas'); ?></label>
                                <input type="email" name="axepta_manual_capture_email" id="axepta_manual_capture_email" placeholder="<?php echo esc_attr__('exemple@domaine.com', 'axepta-bnp-paribas'); ?>"
                                    value="<?php echo esc_attr($account['axepta_manual_capture_email'] ?? ''); ?>"
                                    pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                                    title="<?php echo esc_attr__('Veuillez saisir une adresse e-mail valide (exemple@domaine.com)', 'axepta-bnp-paribas'); ?>">
                                <p class="axepta-help"><?php echo __('Cette adresse recevra une notification au bout du 6ème et 28ème jour.', 'axepta-bnp-paribas'); ?></p>
                            </div>
                        </div>

                        <div id="axepta_capture_hours" style="display: <?php echo $account['axepta_capture_mode'] === 'deferred' ? 'block' : 'none'; ?>;">
                            <div class="d-flex" style="margin: 10px 0;">
                                <label class="switch-text">Nombre d'heures avant la demande de capture</label>
                                <input type="number" name="axepta_capture_hours" value="<?php echo esc_attr($account['axepta_capture_hours'] ?? 1); ?>" min="1" max="696" />
                            </div>
                            <div class="axepta-alert" style="margin-bottom: 10px;">
                                <span class="dashicons dashicons-bell"></span> Important :
                                <span>Perte de l’authentification au bout de 7 jours et l’autorisation au bout de 29 jours</span>
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>
        </div>

        <!-- SMTP Setup -->
        <div class="axepta-accordion-item">
            <h3 class="axepta-section axepta-accordion-header" data-target="#axepta-smtp-settings">
                <span class="dashicons dashicons-arrow-right-alt2 toggle-icon" style="vertical-align:middle;margin-right:8px;"></span>
                <?php echo __('Configuration SMTP', 'axepta-bnp-paribas'); ?>
            </h3>
            <div id="axepta-smtp-settings" class="axepta-accordion-content" style="display: none;">
                <h3><?php echo __('Paramètres SMTP', 'axepta-bnp-paribas'); ?>  <span title="<?= __('Veuillez renseigner ces informations pour activer l\'envoi d\'e-mails via SMTP', 'axepta-bnp-paribas'); ?>" class="dashicons dashicons-info-outline"></span> </h3>
                <fieldset class="axepta-payment-section">
                    <label for="axepta_smtp_host" class="axepta-label"><?php echo __('Serveur SMTP', 'axepta-bnp-paribas'); ?></label>
                    <input type="text" name="axepta_smtp_host" id="axepta_smtp_host"
                            value="<?php echo esc_attr($account['axepta_smtp_host'] ?? ''); ?>"
                            placeholder="<?php echo esc_attr__('smtp.exemple.com', 'axepta-bnp-paribas'); ?>">

                    <label for="axepta_smtp_user" class="axepta-label"><?php echo __('Utilisateur SMTP', 'axepta-bnp-paribas'); ?></label>
                    <input type="text" name="axepta_smtp_user" id="axepta_smtp_user"
                            value="<?php echo esc_attr($account['axepta_smtp_user'] ?? ''); ?>"
                            placeholder="<?php echo esc_attr__('utilisateur', 'axepta-bnp-paribas'); ?>">

                    <label for="axepta_smtp_password" class="axepta-label"><?php echo __('Mot de passe SMTP', 'axepta-bnp-paribas'); ?></label>
                    <input type="password" name="axepta_smtp_password" id="axepta_smtp_password">
                </fieldset>
            </div>
        </div>
        
        <input type="hidden" name="axepta_custom_form_submitted" value="1" />
        <?php wp_nonce_field('axepta_custom_settings_nonce', 'axepta_custom_settings_nonce'); ?>
    </div>

    <!-- Modal Versionning -->
    <div id="axepta-versionning-modal" class="axepta-modal">
        <div class="axepta-modal-content">
            <span class="axepta-close">&times;</span>
            <h3><?php echo __('Version Axepta', 'axepta-bnp-paribas'); ?></h3>
            
            <?php if($axepta_releases): ?>
                <a href="#" class="release-download-btn" id="axepta-download-all-releases"><?php echo __('Télécharger', 'axepta-bnp-paribas'); ?></a>
            <?php else: ?>
                <p><?php echo __('Aucune release disponible pour le moment.', 'axepta-bnp-paribas'); ?></p>
            <?php endif; ?>

            <div class="releases">
                <?php foreach ($axepta_releases as $index => $release): ?>
                    <div class="axepta-release <?php echo $index > 1 ? 'hidden-release' : ''; ?>" <?php echo $index > 1 ? 'style="display: none;"' : ''; ?>>
                        <div class="release-title">
                            <strong><?php echo esc_html__('Version', 'axepta-bnp-paribas') . ' ' . esc_html($release['tag_name']); ?></strong> - 
                            <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($release['created_at']))); ?>
                        </div>

                        <div class="release-info">
                            <h4><?php echo esc_html($release['name']); ?></h4>
                            <div class="release-description">
                                <?php echo nl2br(esc_html($release['description'])); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if (count($axepta_releases) > 2): ?>
                <a href="#" id="axepta-toggle-releases" class="release-readmore-btn"><?php echo __('Voir plus', 'axepta-bnp-paribas'); ?></a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal Contact Support Form -->
    <div id="axepta-contact-form" class="axepta-modal">
        <div class="axepta-modal-content">
            <span class="axepta-close">&times;</span>
            <h2><?php echo __('Contacter l\'assistance', 'axepta-bnp-paribas'); ?></h2>
            
            <div id="axepta-support-response"></div>
            <div id="axeptaSupportForm" data-is-form="true">
                <?php wp_nonce_field('axepta_send_support', 'axepta_support_nonce'); ?>
                <label for="name" class="axepta-label"><?php echo __('Nom Prénom *', 'axepta-bnp-paribas'); ?></label>
                <input type="text" id="name" name="name" data-required value="<?php echo esc_attr($_POST['name'] ?? ''); ?>">

                <label for="email" class="axepta-label"><?php echo __('Email *', 'axepta-bnp-paribas'); ?></label>
                <input type="email" id="email" name="email" data-required value="<?php echo esc_attr($_POST['email'] ?? ''); ?>">

                <label for="message" class="axepta-label"><?php echo __('Description *', 'axepta-bnp-paribas'); ?></label>
                <textarea id="message" name="message" rows="4" data-required><?php echo esc_textarea($_POST['message'] ?? __('', 'axepta-bnp-paribas')); ?></textarea>

                <label for="fichier" class="axepta-label"><?php echo __('Fichier (optionnel)', 'axepta-bnp-paribas'); ?></label>
                <input type="file" id="fichier" name="fichier">

                <button type="submit" id="submitBtn" class="button button-primary" style="width: 100%;">
                    <span class="spinner-icon dashicons dashicons-update spin-loader" style="display: none;"></span>
                    <span class="spinner-label"><?php echo __('Envoyer', 'axepta-bnp-paribas'); ?></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Modal ConfigTest -->
    <div id="axepta-config-modal" class="axepta-modal">
        <div class="axepta-modal-content">
            <span class="axepta-close">&times;</span>
            <h2><?php echo __('Configurations', 'axepta-bnp-paribas'); ?></h2>
            <div class="config-content">
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Version PHP', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> <?php echo phpversion(); ?> </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Version CMS', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> <?php echo get_bloginfo('version'); ?> </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Version Module', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> <?php echo AXEPTA_BNPP_VERSION; ?> </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Mode', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> <?php echo ucfirst($account['axepta_mode']); ?> </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Clés API valides', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value" id="axepta-valid-api-keys">
                        <span class="dashicons dashicons-update spin-loader" style="color: #212121; animation: spin 1s linear infinite;"></span>
                    </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Code source / Indice', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> --- </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Surcharge / Indice', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> --- </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Template / Indice', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> --- </div>
                </div>
                <div class="config-row">
                    <div class="config-row-key"><?php echo __('Environnement / Indice', 'axepta-bnp-paribas'); ?></div>
                    <div class="config-row-value"> --- </div>
                </div>
            </div>
        </div>
    </div>
</div>