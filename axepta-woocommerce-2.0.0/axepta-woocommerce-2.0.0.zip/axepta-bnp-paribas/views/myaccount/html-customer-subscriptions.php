<?php

if (!defined('ABSPATH')) {
    exit;
}

do_action('woocommerce_before_account_subscriptions', $has_subscriptions);

if ($has_subscriptions) : ?>
    <div class="woocommerce-account-subscriptions">
        <h2><?php esc_html_e('Mes abonnements', 'axepta-bnp-paribas'); ?></h2>

        <table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
            <thead>
                <tr>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number">
                        <span class="nobr"><?php esc_html_e('Abonnement', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-date">
                        <span class="nobr"><?php esc_html_e('Date de début', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status">
                        <span class="nobr"><?php esc_html_e('Prochain paiement', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total">
                        <span class="nobr"><?php esc_html_e('Montant', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status">
                        <span class="nobr"><?php esc_html_e('Statut', 'axepta-bnp-paribas'); ?></span>
                    </th>

                    <?php if(get_current_user_id() && $customer_can_suspend && $has_subscriptions) : ?>
                        <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-actions">
                            <span class="nobr"><?php esc_html_e('Actions', 'axepta-bnp-paribas'); ?></span>
                        </th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach ($subscriptions as $subscription) : 
                    # Extract subscription data with default values
                    $subscription = wp_parse_args($subscription, array(
                        'id_axepta_bnpp_customer_subscription_payment' => 0,
                        'product' => null,
                        'order' => null,
                        'status' => 0,
                        'status_label' => '',
                        'date_add_formatted' => '',
                        'next_payment_formatted' => '',
                        'amount_formatted' => wc_price(0)
                    ));
                    
                    $subscription_id = absint($subscription['id_axepta_bnpp_customer_subscription_payment']);
                    $status = absint($subscription['status']);
                    $product = $subscription['product'];
                    $order = $subscription['order'];
                ?>
                    <tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-<?php echo esc_attr($subscription['status']); ?> order">
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-number" data-title="<?php esc_attr_e('Abonnement', 'axepta-bnp-paribas'); ?>">
                            <?php if ($product) : ?>
                                <a href="<?php echo esc_url(get_permalink($product->get_id())); ?>">
                                    <?php echo esc_html($product->get_name()); ?>
                                </a>
                            <?php else : ?>
                                <?php echo sprintf(esc_html__(
                                    // translators: %s is the product ID
                                    'Produit #%s', 'axepta-bnp-paribas'),
                                    $subscription['id_product']); 
                                ?>
                            <?php endif; ?>
                            <br>
                            <small>
                                <?php 
                                printf(
                                    // translators: %s is the order ID
                                    esc_html__('Commande %s', 'axepta-bnp-paribas'), 
                                    $order ? '<a href="' . esc_url($order->get_view_order_url()) . '">' . esc_html($order->get_order_number()) . '</a>' : '#' . $subscription['id_order']
                                );
                                ?>
                            </small>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-date" data-title="<?php esc_attr_e('Date de début', 'axepta-bnp-paribas'); ?>">
                            <time datetime="<?php echo esc_attr($subscription['date_add']); ?>">
                                <?php echo esc_html($subscription['date_add_formatted']); ?>
                            </time>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-next-payment" data-title="<?php esc_attr_e('Prochain paiement', 'axepta-bnp-paribas'); ?>">
                            <?php if ($subscription['next_schedule']) : ?>
                                <time datetime="<?php echo esc_attr($subscription['next_schedule']); ?>">
                                    <?php echo esc_html($subscription['next_payment_formatted']); ?>
                                </time>
                                <small>
                                    <?php 
                                    printf(
                                        // translators: %1$d is the number of intervals, %2$s is the interval unit (e.g., days, weeks)
                                        esc_html__('Tous les %1$d %2$s', 'axepta-bnp-paribas'),
                                        absint($subscription['number_periodicity']),
                                        esc_html(Axepta_BNPP_Customer_Subscription::get_periodicity_label($subscription['periodicity']))
                                    );
                                    ?>
                                </small>
                            <?php else : ?>
                                - 
                            <?php endif; ?>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-total" data-title="<?php esc_attr_e('Montant', 'axepta-bnp-paribas'); ?>">
                            <?php echo wp_kses_post($subscription['amount_formatted']); ?>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-status" data-title="<?php esc_attr_e('Statut', 'axepta-bnp-paribas'); ?>">
                            <span class="woocommerce-orders-table__status status-<?php echo esc_attr($subscription['status']); ?>">
                                <?php echo esc_html($subscription['status_label']); ?>
                            </span>
                        </td>
                        
                        <?php if (get_current_user_id() && $customer_can_suspend && $has_subscriptions) : ?>
                            <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-subscription-actions" data-title="<?php esc_attr_e('Actions', 'axepta-bnp-paribas'); ?>">
                                <div class="subscription-actions">
                                    <?php if ($subscription_id > 0) : ?>
                                        <?php if ($status === 1) : ?>
                                            <form method="post" class="subscription-action-form">
                                                <input type="hidden" name="subscription_id" value="<?php echo esc_attr($subscription_id); ?>">
                                                <input type="hidden" name="action" value="pause_subscription">
                                                <?php wp_nonce_field('subscription_actions_nonce', 'subscription_nonce'); ?>
                                                <button type="submit" class="btn pause-subscription" onclick="return confirm('<?php echo esc_js(__('Êtes-vous sûr de vouloir mettre en pause cet abonnement ?', 'axepta-bnp-paribas')); ?>')">
                                                    <?php esc_html_e('Mettre en pause', 'axepta-bnp-paribas'); ?>
                                                </button>
                                            </form>
                                        <?php elseif ($status === 2) : ?>
                                            <form method="post" class="subscription-action-form">
                                                <input type="hidden" name="subscription_id" value="<?php echo esc_attr($subscription_id); ?>">
                                                <input type="hidden" name="action" value="resume_subscription">
                                                <?php wp_nonce_field('subscription_actions_nonce', 'subscription_nonce'); ?>
                                                <button type="submit" class="btn resume-subscription">
                                                    <?php esc_html_e('Reprendre', 'axepta-bnp-paribas'); ?>
                                                </button>
                                            </form>
                                        <?php else : ?>
                                            <span class="no-actions">-</span>
                                        <?php endif; ?>
                                    <?php else : ?>
                                        <span class="no-actions">-</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
        <?php esc_html_e('Aucun abonnement trouvé.', 'axepta-bnp-paribas'); ?>
    </div>
<?php endif; ?>

<?php do_action('woocommerce_after_account_subscriptions', $has_subscriptions); ?>
