<?php

if (!defined('ABSPATH')) {
    exit;
}

$user_id = get_current_user_id();
$cards = Axepta_BNPP_OneClick::get_user_cards($user_id);

$plugin_url = AXEPTA_BNPP_PLUGIN_URL;
?>

<div class="woocommerce-account-axepta-payment-methods">
    <h2><?= esc_html_e('Mes cartes de paiements', 'axepta-bnp-paribas'); ?></h2>
    
    <?php if (!empty($cards)) : ?>
        <table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
            <thead>
                <tr>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number">
                        <span class="nobr"><?= esc_html_e('Type de carte', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-date">
                        <span class="nobr"><?= esc_html_e('Numéro de carte', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status">
                        <span class="nobr"><?= esc_html_e('Date d\'expiration', 'axepta-bnp-paribas'); ?></span>
                    </th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-actions">
                        <span class="nobr"><?= esc_html_e('Actions', 'axepta-bnp-paribas'); ?></span>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cards as $card) : 
                    $icon = $card->ccbrand ? $plugin_url . 'assets/img/' . strtoupper($card->ccbrand) . '.png' : '';
                    $pcnr = $card->pcnr ? substr($card->pcnr, -4) : '';
                    $ccexpiry = $card->ccexpiry;
                ?>
                <tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
                    <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" style="padding:0 !important;" data-title="<?php esc_attr_e('Type de carte', 'axepta-bnp-paribas'); ?>">
                        <img style="display:block;margin:auto;width:50px;padding:0;" src="<?= esc_url($icon); ?>" title="<?= esc_attr($card->ccbrand); ?>" alt="<?= esc_attr($card->ccbrand); ?>"/>
                    </td>
                    <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date" data-title="<?php esc_attr_e('Numéro de carte', 'axepta-bnp-paribas'); ?>">
                        XXXX XXXX XXXX <?= esc_html($pcnr); ?>
                    </td>
                    <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="<?php esc_attr_e('Date d\'expiration', 'axepta-bnp-paribas'); ?>">
                        <?= esc_html($ccexpiry); ?>
                    </td>
                    <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions" data-title="<?php esc_attr_e('Actions', 'axepta-bnp-paribas'); ?>">
                        <form method="post" class="remove-card-form" onsubmit="return confirm('<?php esc_attr_e('Êtes vous sûr de vouloir supprimer cette carte ?', 'axepta-bnp-paribas'); ?>');">
                            <?php wp_nonce_field('remove_card_nonce', '_remove_card_nonce'); ?>
                            <input type="hidden" name="action" value="remove_card">
                            <input type="hidden" name="card_id" value="<?= esc_attr($card->id); ?>">
                            <button type="submit" class="woocommerce-button buttonn cancel">
                                <?php esc_html_e('Supprimer', 'axepta-bnp-paribas'); ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <div class="woocommerce-Message woocommerce-Message--info woocommerce-info">
            <?php esc_html_e("Aucune carte de paiement n'a été enregistrée.", 'axepta-bnp-paribas'); ?>
        </div>
    <?php endif; ?>
</div>
