<?php

if (!isset($_GET['transaction']) || empty($_GET['transaction'])) {
    echo '<p>' . esc_html__('Aucune transaction spécifiée.', 'axepta-bnp-paribas') . '</p>';
    return;
}

$transaction_id = intval($_GET['transaction']);

$transaction = Axepta_BNPP_Transaction::get_by_id($transaction_id);

if (empty($transaction)) {
    echo '<p>' . esc_html__('Transaction introuvable.', 'axepta-bnp-paribas') . '</p>';
    return;
}

?>
    <div class="wrap">
        <h1><?php esc_html_e('Détails de la transaction', 'axepta-bnp-paribas'); ?></h1>

        <table class="wp-list-table widefat fixed" style="width: 90%; margin: 20px auto; padding: 32px !important;">
            <tbody>
                <style>
                    .wp-list-table th {
                        font-weight: bold;
                        font-size: 16px;
                    }
                </style>
                <tr>
                    <th><?php esc_html_e('ID de transaction', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->transaction_reference); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('ID de commande', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->order_id); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Date de la transaction', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($transaction->transaction_date))); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Code marchand', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->merchant_id); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Montant', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo wc_price((float) $transaction->amount, ['currency' => get_woocommerce_currency()]); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Type de transaction', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->transaction_type); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Moyen de paiement', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->payment_mean_brand); ?></td>
                </tr>
                <!-- <tr>
                    <th><?php esc_html_e('Statut', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->status); ?></td>
                </tr> -->

                <tr>
                    <th><?php esc_html_e('captured', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->captured); ?></td>
                </tr>

                <tr>
                    <th><?php esc_html_e('Code de réponse', 'axepta-bnp-paribas'); ?></th>
                    <td><?php echo esc_html($transaction->response_code); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Données brutes', 'axepta-bnp-paribas'); ?></th>
                    <td><pre><?php echo esc_html($transaction->raw_data); ?></pre></td>
                </tr>
                <tr style="margin-top: 20px !important;">
                    <th colspan="2" style="font-size: 16px;"><a href="<?php echo esc_url(admin_url('admin.php?page=axepta_bnpp_transactions')); ?>"><?php echo esc_html__('Retour à la liste des transactions', 'axepta-bnp-paribas'); ?></a></th>
                </tr>
            </tbody>
        </table>
    </div>
<?php
