<?php 

use Automattic\WooCommerce\Utilities\OrderUtil; ?>

<div class="wrap">
    <h2><?php echo esc_html__('Liste des transactions', 'axepta-bnp-paribas'); ?></h2>

    <?php if (empty($transactions)) { ?>
        <p><?php echo esc_html__('Aucune transaction pour cette commande.', 'axepta-bnp-paribas'); ?></p>
    <?php } else { ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php echo esc_html__('Date', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Marque', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('ID de transaction', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('ID de commande', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Code marchand', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Montant', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Type', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Statut', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Réponse', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Capture', 'axepta-bnp-paribas'); ?></th>
                    <th><?php echo esc_html__('Détails', 'axepta-bnp-paribas'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction) { ?>
                    <?php
                        $logo_path = plugin_dir_url(__DIR__) . 'assets/img/' . strtoupper($transaction->payment_mean_brand ?? '') . '.png';
                        $logo = '<img src="' . esc_url($logo_path) . '" width="32" alt="' . esc_attr($transaction->payment_mean_brand ?? '-') . '">';
                    ?>
                    <tr>
                        <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($transaction->transaction_date))); ?></td>
                        <td><?php echo $logo; ?></td>
                        <td><?php echo esc_html($transaction->transaction_reference); ?></td>
                        <td><?php echo esc_html($transaction->order_id); ?></td>
                        <td><?php echo esc_html($transaction->merchant_id); ?></td>
                        <td><?php echo esc_html($transaction->amount); ?></td>
                        <td><?php echo esc_html($transaction->transaction_type); ?></td>
                        <td><?php echo strtoupper(esc_html($transaction->status)); ?></td>
                        <td><?php echo strtoupper(esc_html($transaction->description)); ?></td>
                        <td><?php echo $transaction->captured === 'yes' ? 'oui' : 'non'; ?></td>
                        <td>
                            <a href="<?php echo esc_url(admin_url(path: 'admin.php?page=axepta_bnpp_transactions&transaction=' . $transaction->transaction_id)); ?>"><?php echo esc_html__('Détails', 'axepta-bnp-paribas'); ?></a>
                            <?php if ($transaction->transaction_reference && $transaction->transaction_type === 'SIMPLE_PAYMENT' && $transaction->capture_mode === 'manuel' && $transaction->captured !== 'yes' && $transaction->transaction_type === 'SIMPLE_PAYMENT') { 
                                $capture_url = wp_nonce_url(
                                    admin_url('admin.php?page=axepta_bnpp_transactions&transaction=' . $transaction->transaction_id . '&action=capture'),
                                    'axepta_capture_' . $transaction->transaction_id
                                ); ?>
                                <a href="<?php echo esc_url($capture_url); ?>">
                                    <?php echo esc_html__('Capturer', 'axepta-bnp-paribas'); ?>
                                </a>
                            <?php } ?>

                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } ?>
</div>
