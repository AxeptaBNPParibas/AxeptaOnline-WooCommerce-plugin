<?php

/**
 * Axepta BNP Install
 */
class Axepta_BNP_Install {

    public static function deactivation() 
    {
        delete_option('woocommerce_axepta_cb_settings');
    }

    public static function uninstall() 
    {
        delete_option('axepta_settings');
        delete_option('woocommerce_axepta_cb_settings');
        delete_option('woocommerce_axepta_bnpp_settings');
        
        self::deleteTables();
    }

    public static function query($sql, $log_msg = null)
    {
        global $wpdb;

        if($log_msg) {
            Axepta_Bnpp_Log::log('info', __($log_msg, 'axepta-bnp-paribas'));
        }

        $result = $wpdb->query($sql);
        if ($wpdb->last_error) {
            Axepta_Bnpp_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }

        return $result;
    }

    public static function install() 
    {
        global $wpdb;

        self::initSettings();

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_transactions` (
                `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
                `merchant_id` varchar(255) NULL,
                `transaction_reference` varchar(255) NULL,
                `transaction_date` datetime NULL,
                `order_id` int(11) NULL,
                `pay_id` varchar(255) NULL,
                `bid` varchar(255) NULL,
                `xid` varchar(255) NULL,
                `amount` decimal(20,2) NULL,
                `transaction_type` varchar(255) NULL,
                `scheme_reference_id` varchar(255) NULL,
                `payment_mean_brand` varchar(255) NULL,
                `payment_mean_type` varchar(255) NULL,
                `response_code` varchar(255) NULL,
                `pcnr` varchar(255) NULL,
                `ccexpiry` varchar(255) NULL,
                `status` varchar(255) NULL,
                `description` varchar(255) NULL,
                `raw_data` text NULL,
                `ref_nr` varchar(32) NULL,
                `holder_name` varchar(128) NULL,
                `capture_mode` varchar(32) NULL,
                `captured` varchar(5) NULL,
                PRIMARY KEY (`transaction_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_transactions', 'axepta-bnp-paribas')
        );
        self::add_missing_transactions_columns();

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_subscriptions` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `subscription_status` varchar(255) NOT NULL,
                `subscription_start` datetime NOT NULL,
                `subscription_end` datetime NOT NULL,
                `subscription_duration` int(11) NOT NULL,
                `subscription_frequency` varchar(255) NOT NULL,
                `subscription_amount` decimal(10,2) NOT NULL,
                `subscription_currency` varchar(255) NOT NULL,
                `subscription_repeating` tinyint(1) NOT NULL,
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_subscriptions', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_customer_saved_card` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `customer_id` int(11) NULL,
                `pcnr` varchar(255) NULL,
                `ccexpiry` varchar(255) NULL,
                `ccbrand` varchar(255) NULL,
                `number` varchar(255) NULL DEFAULT '',
                `trigram` varchar(5) NULL DEFAULT 'VIM',
                `last4digits` varchar(5) NULL DEFAULT '',
                `expiry_date` varchar(5) NULL DEFAULT '',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_customer_saved_card', 'axepta-bnp-paribas')
        );
        self::add_missing_card_columns();

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_subscription_product` (
                `id_axepta_bnpp_subscription_product` int(10) NOT NULL AUTO_INCREMENT,
                `id_product` int(10) NOT NULL,
                `type` int(10) DEFAULT NULL,
                `number_periodicity` int(10) NOT NULL,
                `periodicity` varchar(10) NOT NULL,
                `number_occurences` int(10) NOT NULL,
                `recurring_amount` float DEFAULT NULL,
                PRIMARY KEY (`id_axepta_bnpp_subscription_product`),
                KEY `id_product` (`id_product`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_subscription_product', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_customer_subscription_payment` (
                `id_axepta_bnpp_customer_subscription_payment` int(10) NOT NULL AUTO_INCREMENT,
                `id_order` int(10) NOT NULL,
                `id_customer` int(10) NOT NULL,
                `id_product` int(10) NOT NULL,
                `transaction_id` int(10) NOT NULL,
                `id_tax_rules_group` int(10) NOT NULL,
                `bid` varchar(255) NULL,
                `pcnr` varchar(255) NULL,
                `ccexpiry` varchar(255) NULL,
                `ccbrand` varchar(255) NULL,
                `status` int(10) NOT NULL,
                `amount_tax_exclude` float NOT NULL,
                `number_periodicity` int(10) NOT NULL,
                `periodicity` varchar(10) NOT NULL,
                `number_occurences` int(10) NOT NULL,
                `current_occurence` int(10) NOT NULL DEFAULT '0',
                `date_add` datetime DEFAULT NULL,
                `last_schedule` datetime DEFAULT NULL,
                `next_schedule` datetime DEFAULT NULL,
                `current_specific_price` decimal(5,2) NOT NULL DEFAULT '0',
                `scheme_reference_id` varchar(128) NULL,
                `shipping_specific_price` decimal(5,2) NOT NULL DEFAULT '0',
                `id_cart_paused_currency` int(10) NOT NULL DEFAULT '1',
                `nb_fail` int(10) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id_axepta_bnpp_customer_subscription_payment`),
                KEY `id_product` (`id_order`, `id_customer`, `id_product`, `transaction_id`, `id_tax_rules_group`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_customer_subscription_payment', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_subscription_notes` (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                id_axepta_bnpp_customer_subscription_payment bigint(20) NOT NULL,
                note text NOT NULL,
                created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                PRIMARY KEY  (id),
                KEY id_axepta_bnpp_customer_subscription_payment (id_axepta_bnpp_customer_subscription_payment)
            )  ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_subscription_notes', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_xml_method` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `trigram` varchar(255) NOT NULL,
                `code` varchar(255) NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_xml_method', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_xml_allow_countries` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `method_id` int(11) NULL,
                `currency` varchar(255) NULL,
                `country` varchar(255) NULL,
                FOREIGN KEY (`method_id`) REFERENCES `{$wpdb->prefix}axepta_bnpp_xml_method`(`id`),
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_xml_allow_countries', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_xml_parameter_set` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `operation` varchar(255) NULL,
                `parameter_set_id` int(11) NOT NULL,
                `url` varchar(255) NULL,
                `url_test` varchar(255) NULL,
                `method_id` int(11) NOT NULL,
                FOREIGN KEY (`method_id`) REFERENCES `{$wpdb->prefix}axepta_bnpp_xml_method`(`id`),
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_xml_parameter_set', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_xml_parameter` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(255) NULL,
                `format` varchar(255) NULL,
                `required` varchar(255) NULL,
                `parameter_set_id` int(11) NOT NULL,
                FOREIGN KEY (`parameter_set_id`) REFERENCES `{$wpdb->prefix}axepta_bnpp_xml_parameter_set`(`id`),
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_xml_parameter', 'axepta-bnp-paribas')
        );

        self::query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}axepta_bnpp_xml_method_lang` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `method_id` int(11) NOT NULL,
                `iso` varchar(255) NULL,
                `label` varchar(255) NULL,
                FOREIGN KEY (`method_id`) REFERENCES `{$wpdb->prefix}axepta_bnpp_xml_method`(`id`),
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8",
            __('Création de la table axepta_bnpp_xml_method_lang', 'axepta-bnp-paribas')
        );
    }

    public static function initSettings()
    {
        if (false === get_option('axepta_settings')) {
            add_option('axepta_settings', [
                'axepta_mode' => "demo",
                'axepta_test_key' => "",
                'axepta_merchant_id' => "",
                'axepta_private_key' => "",
                'axepta_enabled' => "1",
                'axepta_payment_layout' => "hpp",
                'axepta_payment_label' => __('Paiement par carte bancaire', 'axepta-bnp-paribas'),
                'axepta_display_mode' => "iframe",
                'axepta_oneclick_enabled' => "0",
                'axepta_3ds_exemption' => "0",
                'axepta_subscription_enabled' => "0",
                'axepta_capture_mode' => "auto",
                'axepta_payment_methods' => [],
            ]);
        }
    }

    public static function add_missing_transactions_columns() {
        global $wpdb;

        $columns_to_check = [
            'captured' => "varchar(5) NULL",
            'capture_mode' => "varchar(32) NULL",
        ];

        $existing_columns = $wpdb->get_col("SHOW COLUMNS FROM `{$wpdb->prefix}axepta_bnpp_transactions`");

        $columns_to_add = [];
        foreach ($columns_to_check as $column => $definition) {
            if (!in_array($column, $existing_columns)) {
                $columns_to_add[] = "ADD COLUMN `$column` $definition";
            }
        }

        if (!empty($columns_to_add)) {
            $alter_sql = "ALTER TABLE `{$wpdb->prefix}axepta_bnpp_transactions` " . implode(', ', $columns_to_add);
            self::query($alter_sql, __('Ajout des colonnes manquantes à la table axepta_bnpp_transactions', 'axepta-bnp-paribas'));
        }
    }

    public static function add_missing_card_columns() {
        global $wpdb;

        $columns_to_check = [
            'trigram' => "varchar(5) NULL DEFAULT 'VIM'",
            'last4digits' => "varchar(5) NULL DEFAULT ''",
            'number' => "varchar(255) NULL DEFAULT ''"
        ];

        $existing_columns = $wpdb->get_col("SHOW COLUMNS FROM `{$wpdb->prefix}axepta_bnpp_customer_saved_card`");

        $columns_to_add = [];
        foreach ($columns_to_check as $column => $definition) {
            if (!in_array($column, $existing_columns)) {
                $columns_to_add[] = "ADD COLUMN `$column` $definition";
            }
        }

        if (!empty($columns_to_add)) {
            $alter_sql = "ALTER TABLE `{$wpdb->prefix}axepta_bnpp_customer_saved_card` " . implode(', ', $columns_to_add);
            self::query($alter_sql, __('Ajout des colonnes manquantes à la table axepta_bnpp_customer_saved_card', 'axepta-bnp-paribas'));
        }
    }

    public static function deleteTables() 
    {
        global $wpdb;

        $tables = [
            $wpdb->prefix . 'axepta_bnpp_xml_method_lang',
            $wpdb->prefix . 'axepta_bnpp_xml_parameter',
            $wpdb->prefix . 'axepta_bnpp_xml_parameter_set',
            $wpdb->prefix . 'axepta_bnpp_xml_allow_countries',
            $wpdb->prefix . 'axepta_bnpp_xml_method',
            $wpdb->prefix . 'axepta_bnpp_customer_subscription_payment',
            $wpdb->prefix . 'axepta_bnpp_subscription_product',
            $wpdb->prefix . 'axepta_bnpp_customer_saved_card',
            $wpdb->prefix . 'axepta_bnpp_subscriptions',
            $wpdb->prefix . 'axepta_bnpp_transactions',
            $wpdb->prefix . 'axepta_bnpp_subscription_notes',
        ];

        foreach ($tables as $table) {
            try {
                self::query("DROP TABLE IF EXISTS `$table`");
            } catch (Exception $e) {
                Axepta_Bnpp_Log::error(__('Erreur lors de la suppression de la table : ', 'axepta-bnp-paribas') . $e->getMessage());
            }
        }

        // delete foreign keys
        foreach ($wpdb->get_results("SELECT TABLE_NAME FROM information_schema.table_constraints WHERE CONSTRAINT_TYPE = 'FOREIGN KEY'", ARRAY_A) as $row) {
            $table = $row['TABLE_NAME'];

            if (strpos($table, $wpdb->prefix . 'axepta_bnpp_') === 0) {
                self::query("ALTER TABLE `$table` DROP FOREIGN KEY " . $wpdb->get_results("SELECT CONSTRAINT_NAME FROM information_schema.table_constraints WHERE TABLE_NAME = '$table' AND CONSTRAINT_TYPE = 'FOREIGN KEY'", ARRAY_A)[0]['CONSTRAINT_NAME']);
            }
        }
    }
}